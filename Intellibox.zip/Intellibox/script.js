const kpis=[
  {value:'128',label:'Email received',sub:'↑ 18% vs previous day',tone:'neutral',color:'var(--metric-purple-chart)',points:'0,58 14,42 28,30 42,38 56,60 70,52 84,17 98,7 112,13 126,29 140,34 154,26 168,25 184,14'},
  {value:'24',label:'Email sent',sub:'↑ 9% vs previous day',tone:'neutral',color:'var(--metric-purple-chart)',points:'0,61 18,36 36,23 54,35 72,45 90,38 108,20 126,7 144,14 162,17 180,3 194,12'},
  {value:'92',label:'Cases completed',sub:'↑ 14% vs previous day',tone:'green',color:'#38D200',points:'0,62 32,56 58,54 76,44 96,25 120,35 140,21 160,4'},
  {value:'12',label:'Bounced',sub:'↑ 3% vs previous day',tone:'red',color:'#E3232C',points:'0,38 28,25 52,21 75,14 96,12 124,4 152,18 176,25'},
  {value:'27',label:'Pending actions',sub:'↑ 11% vs previous day',tone:'amber',color:'#F4A909',tooltip:'Includes pending verification and pending manual resolution.',points:'0,43 25,22 52,17 75,8 100,6 124,1 140,12 152,37 166,43 182,77'},
  {value:'6',label:'Exceptions',sub:'↑ 5% vs previous day',tone:'red',color:'#E3232C',tooltip:'Includes rejected, escalated, and expired cases.',points:'0,37 30,24 60,19 85,12 110,11 135,3 160,17 184,24'}
];
const embeddedMode=new URLSearchParams(location.search).get('embedded')==='1';
if(embeddedMode)document.body.classList.add('embedded-mode');
const caseDetailKpis=[
  {value:'15',label:'Pending verification',sub:'↑ 8% vs previous day',tone:'amber',color:'#F4A909',points:kpis[4].points},
  {value:'12',label:'Pending manual resolution',sub:'↑ 15% vs previous day',tone:'amber',color:'#F4A909',points:kpis[4].points}
];
const exceptionDetailKpis=[
  {value:'3',label:'Rejected',sub:'↑ 3% vs previous day',tone:'red',color:'#E3232C',points:kpis[5].points},
  {value:'2',label:'Escalated',sub:'↑ 7% vs previous day',tone:'red',color:'#E3232C',points:kpis[5].points},
  {value:'1',label:'Expired',sub:'↑ 2% vs previous day',tone:'red',color:'#E3232C',points:kpis[5].points}
];
const smoothSparkline=points=>{
  const values=points.split(' ').map(pair=>pair.split(',').map(Number));
  let path=`M ${values[0][0]} ${values[0][1]}`;
  for(let i=1;i<values.length-1;i++){
    const [x,y]=values[i];
    const [nextX,nextY]=values[i+1];
    path+=` Q ${x} ${y} ${(x+nextX)/2} ${(y+nextY)/2}`;
  }
  const last=values.at(-1);
  path+=` T ${last[0]} ${last[1]}`;
  return {path,last};
};

const kpiGrid=document.querySelector('#kpiGrid');
function caseCardMarkup(k,i){
  const {path,last}=smoothSparkline(k.points);
  const info=k.tooltip?`<span class="metric-tip-wrap"><button class="info-dot" aria-label="More about ${k.label}" data-tooltip="${k.tooltip}"><img src="Icon/info i tooltip circle.svg" alt=""></button></span>`:'';
  return `<article class="kpi-card" role="link" tabindex="0" data-case-category="${k.label}"><strong>${k.value}</strong><span class="label">${k.label}${info}</span><span class="sub tone-${k.tone}">${k.sub}</span><svg class="trend" viewBox="0 0 190 80" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="g${i}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${k.color}" stop-opacity=".22"/><stop offset=".68" stop-color="${k.color}" stop-opacity=".05"/><stop offset="1" stop-color="${k.color}" stop-opacity="0"/></linearGradient></defs><path class="area" d="${path} L ${last[0]} 80 L 0 80 Z" fill="url(#g${i})"/><path class="sparkline" d="${path}" fill="none" stroke="${k.color}" stroke-width="1.65" vector-effect="non-scaling-stroke"/></svg></article>`;
}
function renderCaseKpis(){
  const coreCards=[kpis[0],kpis[1],kpis[2],kpis[4],kpis[5]];
  const cards=caseExpanded?[kpis[0],kpis[1],kpis[2],kpis[3],...caseDetailKpis,...exceptionDetailKpis]:coreCards;
  kpiGrid.className=`kpi-grid ${caseExpanded?'case-expanded':'case-summary'}`;
  kpiGrid.innerHTML=cards.map(caseCardMarkup).join('');
}
const metricFloatingTip=document.createElement('div');
metricFloatingTip.className='metric-floating-tip';
metricFloatingTip.hidden=true;
document.body.append(metricFloatingTip);
function showMetricTip(button){
  const rect=button.getBoundingClientRect();
  metricFloatingTip.textContent=button.dataset.tooltip;
  metricFloatingTip.hidden=false;
  metricFloatingTip.style.left=`${Math.min(Math.max(rect.left+rect.width/2,130),innerWidth-130)}px`;
  metricFloatingTip.style.top=`${rect.top-10}px`;
}
function hideMetricTip(){metricFloatingTip.hidden=true}
kpiGrid.addEventListener('pointerover',event=>{const button=event.target.closest('.info-dot');if(button)showMetricTip(button)});
kpiGrid.addEventListener('pointerout',event=>{if(event.target.closest('.info-dot'))hideMetricTip()});
kpiGrid.addEventListener('focusin',event=>{const button=event.target.closest('.info-dot');if(button)showMetricTip(button)});
kpiGrid.addEventListener('focusout',event=>{if(event.target.closest('.info-dot'))hideMetricTip()});
kpiGrid.addEventListener('click',event=>{const button=event.target.closest('.info-dot');if(button){event.stopPropagation();showMetricTip(button)}});
kpiGrid.addEventListener('click',event=>{
  const card=event.target.closest('.kpi-card[data-case-category]');
  if(card&&!event.target.closest('.info-dot'))openCasebox(card.dataset.caseCategory);
});
kpiGrid.addEventListener('keydown',event=>{
  const card=event.target.closest('.kpi-card[data-case-category]');
  if(card&&(event.key==='Enter'||event.key===' ')){
    event.preventDefault();
    openCasebox(card.dataset.caseCategory);
  }
});
document.addEventListener('click',event=>{if(!event.target.closest('.info-dot'))hideMetricTip()});

const systems=[
  ['Temporal Workflow Engine','26ms','up'],['EBBS CIV API','266ms','up'],['Atlas Transaction API','365ms','up'],['Email Channel (M365)','3840ms','down'],['AI Factory (LLM endpoints)','365ms','up'],
  ['Customer Profile Service','42ms','up'],['Document Intelligence','318ms','up'],['Policy Rules Engine','91ms','up'],['Notification Gateway','740ms','down'],['Case Routing Service','58ms','up'],
  ['Audit & Compliance Store','126ms','up'],['Knowledge Retrieval API','284ms','up']
];
let analysisMode='case';
let systemExpanded=false;
let caseExpanded=false;
function renderSystemCards(){
  const visible=systemExpanded?systems:systems.slice(0,5);
  kpiGrid.className='kpi-grid system-grid';
  kpiGrid.innerHTML=visible.map(([name,latency,status],index)=>`<article class="system-card" data-system-index="${index}" style="animation-delay:${Math.min(index,7)*.035}s"><h3>${name}</h3><strong>${latency}</strong><span class="system-status ${status}">${status==='up'?'Up':'Down'}</span></article>`).join('');
}
renderCaseKpis();

const statuses=[
  {color:'#209400',label:'Completed',value:92,percent:'63.4%'},
  {color:'#078CAF',label:'Sent to client',value:20,percent:'13.8%'},
  {color:'#C77D00',label:'Pending verification',value:15,percent:'10.3%'},
  {color:'#F4A909',label:'Pending manual resolution',value:12,percent:'8.3%'},
  {color:'#B4232D',label:'Rejected',value:3,percent:'2.1%'},
  {color:'#E3232C',label:'Escalated',value:2,percent:'1.4%'},
  {color:'#EF6670',label:'Expired',value:1,percent:'0.7%'}
];
const statusLegend=document.querySelector('#statusLegend');
statusLegend.innerHTML=statuses.map(item=>`<li class="status-legend-item" role="link" tabindex="0" data-case-category="${item.label}"><i class="dot" style="--dot:${item.color}"></i><span>${item.label}</span><b>${item.value} · ${item.percent}</b></li>`).join('');
function renderInteractiveDonut(svgSelector,tooltipSelector,items,segmentClass,{navigate=true,showCount=true}={}){
  const svg=document.querySelector(svgSelector);
  const tooltip=document.querySelector(tooltipSelector);
  const values=items.map(item=>item.value);
  const sum=values.reduce((total,value)=>total+value,0);
  let offset=0;
  svg.innerHTML=`<g transform="rotate(-90 110 110)">${items.map((item,index)=>{
    const length=values[index]/sum*100;
    const detail=showCount?`${item.value} cases · ${item.percent}`:item.percent;
    const circle=`<circle class="${segmentClass}" cx="110" cy="110" r="90" pathLength="100" fill="none" stroke="${item.color}" stroke-width="36" stroke-dasharray="${length} ${100-length}" stroke-dashoffset="${-offset}" data-label="${item.label}" data-value="${detail}" data-category="${item.label}" role="${navigate?'link':'img'}" tabindex="0" aria-label="${item.label}: ${detail}"/>`;
    offset+=length;
    return circle;
  }).join('')}</g>`;
  svg.querySelectorAll(`.${segmentClass}`).forEach(segment=>{
    segment.addEventListener('pointerenter',()=>{tooltip.innerHTML=`<strong>${segment.dataset.label}</strong><span>${segment.dataset.value}</span>`;tooltip.hidden=false});
    segment.addEventListener('pointermove',event=>{const box=svg.getBoundingClientRect();tooltip.style.left=`${event.clientX-box.left+10}px`;tooltip.style.top=`${event.clientY-box.top-34}px`});
    segment.addEventListener('pointerleave',()=>tooltip.hidden=true);
    segment.addEventListener('focus',()=>{tooltip.innerHTML=`<strong>${segment.dataset.label}</strong><span>${segment.dataset.value}</span>`;tooltip.style.left='95px';tooltip.style.top='32px';tooltip.hidden=false});
    segment.addEventListener('blur',()=>tooltip.hidden=true);
    if(!navigate)return;
    segment.addEventListener('click',()=>openCasebox(segment.dataset.category));
    segment.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();openCasebox(segment.dataset.category)}});
  });
}
renderInteractiveDonut('#statusDonut','#statusChartTooltip',statuses,'status-segment');
statusLegend.addEventListener('click',event=>{const item=event.target.closest('[data-case-category]');if(item)openCasebox(item.dataset.caseCategory)});
statusLegend.addEventListener('keydown',event=>{const item=event.target.closest('[data-case-category]');if(item&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openCasebox(item.dataset.caseCategory)}});

function renderDeliveryGauge(){
  const svg=document.querySelector('#deliveryGauge');
  const percentLabel=document.querySelector('#deliveryPercent');
  const tickCount=32;
  const successRate=100*125/127;
  const activeTicks=Math.min(tickCount-1,Math.round(tickCount*successRate/100));
  const cx=130,cy=84,inner=68,outer=79;
  svg.innerHTML=Array.from({length:tickCount},(_,index)=>{
    const angle=(150+240*index/(tickCount-1))*Math.PI/180;
    const x1=cx+Math.cos(angle)*inner;
    const y1=cy+Math.sin(angle)*inner;
    const x2=cx+Math.cos(angle)*outer;
    const y2=cy+Math.sin(angle)*outer;
    const active=index<activeTicks?' delivery-tick-active':'';
    return `<line class="delivery-tick${active}" style="--tick-delay:${index*28}ms" x1="${x1.toFixed(2)}" y1="${y1.toFixed(2)}" x2="${x2.toFixed(2)}" y2="${y2.toFixed(2)}"/>`;
  }).join('');
  if(matchMedia('(prefers-reduced-motion: reduce)').matches){percentLabel.textContent=`${successRate.toFixed(1)}%`;return}
  const start=performance.now();
  const duration=1100;
  const count=now=>{
    const progress=Math.min(1,(now-start)/duration);
    const eased=1-Math.pow(1-progress,3);
    percentLabel.textContent=`${(successRate*eased).toFixed(1)}%`;
    if(progress<1)requestAnimationFrame(count);
  };
  requestAnimationFrame(count);
}
renderDeliveryGauge();

const approvals=[
  ['FSS-2026-9','Confirm the cancellation',1442],
  ['FSS-2026-8','Review policy exception',1420],
  ['FSS-2026-7','Approve manual resolution',1458],
  ['FSS-2026-6','Redirect to a human',1380],
  ['FSS-2026-5','Verify client response',1320],
  ['FSS-2026-4','Confirm the cancellation',1500],
  ['FSS-2026-3','Asked for more information',1200],
  ['FSS-2026-2','Approve deadline extension',1560],
  ['FSS-2026-1','Escalate compliance review',1620]
];
const approvalSlaMs=24*60*60*1000;
const approvalSnapshotTime=Date.now();
const approvalQueuedAt=waitingMinutes=>approvalSnapshotTime-waitingMinutes*60000;
const approvalDeadline=waitingMinutes=>approvalQueuedAt(waitingMinutes)+approvalSlaMs;
const exceedsApprovalSla=approval=>Date.now()>approvalDeadline(approval[2]);
const approvalStatus=waitingMinutes=>{
  const elapsed=Math.floor((Date.now()-approvalDeadline(waitingMinutes))/60000);
  if(elapsed<0)return `Waiting for ${Math.floor(waitingMinutes/60)} hr`;
  return elapsed>=60?`Overdue by ${Math.floor(elapsed/60)} hr`:`Overdue by ${elapsed} min`;
};
const overdueApprovalCount=approvals.filter(exceedsApprovalSla).length;
const approvalAttention=document.querySelector('#approvalAttention');
approvalAttention.hidden=overdueApprovalCount===0;
approvalAttention.querySelector('span').textContent=`${overdueApprovalCount} approvals have been waiting for more than 24 hours.`;
const approvalList=document.querySelector('#approvalList');
approvalList.innerHTML=approvals.map(a=>`<div class="approval-row${exceedsApprovalSla(a)?' is-overdue':''}" role="link" tabindex="0" data-case-category="${a[0]}" aria-label="Open ${a[0]} in Case box"><span>${a[0]}</span><strong>${a[1]}</strong><small>${approvalStatus(a[2])}</small><b><img src="Icon/arrow chevron nav right forward.svg" alt=""></b></div>`).join('');
approvalList.addEventListener('click',event=>{const row=event.target.closest('.approval-row');if(row)openCasebox(row.dataset.caseCategory)});
approvalList.addEventListener('keydown',event=>{const row=event.target.closest('.approval-row');if(row&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openCasebox(row.dataset.caseCategory)}});

const rows=[
  {label:'Confirmed cancellation',volume:20,delivered:[12,20],average:'6m',sent:12,pending:6,rejected:2,sla:1},
  {label:'Asked for more information',volume:4,delivered:[3,4],average:'9m',sent:3,pending:1,rejected:0,sla:1},
  {label:'Asked ops to cancel',volume:4,delivered:[3,4],average:'12m',sent:3,pending:0,rejected:1,sla:0},
  {label:'Case closure notify',volume:1,delivered:[1,1],average:'2m',sent:1,pending:0,rejected:0,sla:0},
  {label:'Asked for human intervention',volume:18,delivered:[4,18],average:'39.4h',sent:4,pending:12,rejected:2,sla:8}
];

const responseColors=[
  '#0473EA',
  '#38D200',
  '#35DF93',
  '#078CAF',
  '#10BEE8'
];
function renderAgentResponses(days=7){
  const factor=days===7?1:days===30?3.4:9.1;
  const scaled=value=>Math.round(value*factor);
  const total=rows.reduce((sum,row)=>sum+scaled(row.volume),0);
  const responseTypes=rows.map((row,index)=>({
    label:row.label,value:scaled(row.volume),color:responseColors[index]
  }));
  const share=item=>(item.value/total*100).toLocaleString('en',{maximumFractionDigits:1});
  document.querySelector('#agentResponseTotal').textContent=total.toLocaleString();
  document.querySelector('#responseLegend').innerHTML=responseTypes.map(item=>`<li><i class="dot" style="--dot:${item.color}"></i><span>${item.label}</span><b>${share(item)}%</b></li>`).join('');
  document.querySelector('#responseRows').innerHTML=rows.map((r,i)=>{
    const delivered=scaled(r.delivered[0]),deliveryTotal=scaled(r.delivered[1]);
    const progress=deliveryTotal?delivered/deliveryTotal*100:0;
    const rate=scaled(r.sent)/scaled(r.volume)*100;
    const rateClass=rate>=90?'good':rate>=50?'warn':'neutral';
    return `<tr><td><span class="response-type-cell"><i class="response-type-dot" style="--response-color:${responseTypes[i].color}"></i><span>${r.label}</span></span></td><td>${scaled(r.volume)}</td><td><i class="tiny-bar" style="--progress:${progress}%"></i><span class="tone-blue">${delivered}/${deliveryTotal}</span></td><td><span class="rate rate-${rateClass}">${rate.toFixed(1)}%</span></td><td>${r.average}</td><td>${scaled(r.sent)}</td><td>${scaled(r.pending)}</td><td>${scaled(r.rejected)}</td><td>${scaled(r.sla)}</td></tr>`;
  }).join('');
  const sum=responseTypes.reduce((n,item)=>n+item.value,0);
  let offset=0;
  const circles=responseTypes.map(item=>{
    const length=item.value/sum*100;
    const circle=`<circle class="agent-segment" cx="110" cy="110" r="90" pathLength="100" fill="none" stroke="${item.color}" stroke-width="36" stroke-dasharray="${length} ${100-length}" stroke-dashoffset="${-offset}" data-label="${item.label}" data-value="${share(item)}%"/>`;
    offset+=length;
    return circle;
  }).join('');
  const svg=document.querySelector('#agentResponseDonut');
  svg.innerHTML=`<g transform="rotate(-90 110 110)">${circles}</g>`;
  const tooltip=document.querySelector('#agentChartTooltip');
  svg.querySelectorAll('.agent-segment').forEach(segment=>{
    segment.addEventListener('pointerenter',()=>{tooltip.innerHTML=`<strong>${segment.dataset.label}</strong><span>${segment.dataset.value}</span>`;tooltip.hidden=false});
    segment.addEventListener('pointermove',event=>{const box=svg.getBoundingClientRect();tooltip.style.left=`${event.clientX-box.left+10}px`;tooltip.style.top=`${event.clientY-box.top-34}px`});
    segment.addEventListener('pointerleave',()=>tooltip.hidden=true);
  });
}

const activitySeries={
  7:{labels:['12 Jun','13 Jun','14 Jun','15 Jun','16 Jun','17 Jun','18 Jun'],sent:[6,7,6,4,1,10,12],received:[2,5,4,7,6,3,6]},
  30:{labels:['10 Jun','12 Jun','14 Jun','16 Jun','18 Jun','20 Jun','22 Jun','24 Jun'],sent:[5,7,6,4,1,10,12,8],received:[2,5,4,7,6,3,2,6]},
  90:{labels:['Apr','May 1','May 15','Jun 1','Jun 8','Jun 15','Jun 22','Jun 30'],sent:[5,8,7,10,6,13,11,15],received:[3,6,5,9,7,8,5,10]}
};
let currentActivityDays=30;
let selectedActivityIndex=null;
function renderActivityChart(days=30){
  if(days!==currentActivityDays)selectedActivityIndex=null;
  currentActivityDays=days;
  const data=activitySeries[days];
  const svg=document.querySelector('#activityChart');
  const width=Math.max(320,Math.round(svg.clientWidth||720));
  const height=Math.max(220,Math.round(svg.clientHeight||260));
  svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
  const left=36,right=16,top=18,bottom=42,max=Math.max(...data.sent,...data.received)+2;
  const x=i=>left+i*(width-left-right)/(data.labels.length-1);
  const y=v=>top+(max-v)*(height-top-bottom)/max;
  const points=values=>values.map((v,i)=>`${x(i)},${y(v)}`).join(' ');
  const grids=[0,.25,.5,.75,1].map(n=>{const gy=top+n*(height-top-bottom);return `<line x1="${left}" y1="${gy}" x2="${width-right}" y2="${gy}"/><text x="4" y="${gy+4}">${Math.round(max*(1-n))}</text>`}).join('');
  const labels=data.labels.map((label,i)=>`<text class="x-label" x="${x(i)}" y="${height-12}">${label}</text>`).join('');
  svg.innerHTML=`<g class="chart-grid">${grids}</g>${labels}<polyline class="sent-line" points="${points(data.sent)}" fill="none" stroke="#35DF93" stroke-width="2.25" stroke-linejoin="round" stroke-linecap="round"/><polyline class="received-line" points="${points(data.received)}" fill="none" stroke="#0473EA" stroke-width="2.25" stroke-linejoin="round" stroke-linecap="round"/><line class="activity-guide" x1="${left}" y1="${top}" x2="${left}" y2="${height-bottom}" hidden/><circle class="activity-focus-point sent" r="4.5" hidden/><circle class="activity-focus-point received" r="4.5" hidden/><rect class="activity-overlay" x="${left}" y="${top}" width="${width-left-right}" height="${height-top-bottom}"/>`;
  const tooltip=document.querySelector('#activityTooltip');
  const guide=svg.querySelector('.activity-guide');
  const sentPoint=svg.querySelector('.activity-focus-point.sent');
  const receivedPoint=svg.querySelector('.activity-focus-point.received');
  const overlay=svg.querySelector('.activity-overlay');
  const setVisible=(element,visible)=>visible?element.removeAttribute('hidden'):element.setAttribute('hidden','');
  const showIndex=index=>{
    const i=Math.max(0,Math.min(data.labels.length-1,index));
    const gx=x(i);
    guide.setAttribute('x1',gx);guide.setAttribute('x2',gx);setVisible(guide,true);
    sentPoint.setAttribute('cx',gx);sentPoint.setAttribute('cy',y(data.sent[i]));setVisible(sentPoint,true);
    receivedPoint.setAttribute('cx',gx);receivedPoint.setAttribute('cy',y(data.received[i]));setVisible(receivedPoint,true);
    tooltip.innerHTML=`<strong>${data.labels[i]}</strong><span>${data.received[i]} received</span><span>${data.sent[i]} sent</span>`;
    const box=svg.getBoundingClientRect();
    const screenX=gx/width*box.width;
    tooltip.style.left=`${Math.min(Math.max(screenX+10,4),box.width-130)}px`;
    tooltip.style.top=`${Math.max(top/height*box.height+8,4)}px`;
    tooltip.hidden=false;
  };
  const indexFromPointer=event=>{
    const box=svg.getBoundingClientRect();
    const svgX=(event.clientX-box.left)/box.width*width;
    return Math.round((svgX-left)/(width-left-right)*(data.labels.length-1));
  };
  overlay.addEventListener('pointermove',event=>showIndex(indexFromPointer(event)));
  overlay.addEventListener('pointerleave',()=>{
    if(selectedActivityIndex===null){setVisible(guide,false);setVisible(sentPoint,false);setVisible(receivedPoint,false);tooltip.hidden=true}
    else showIndex(selectedActivityIndex);
  });
  overlay.addEventListener('click',event=>{selectedActivityIndex=Math.max(0,Math.min(data.labels.length-1,indexFromPointer(event)));showIndex(selectedActivityIndex)});
  if(selectedActivityIndex!==null)showIndex(selectedActivityIndex);
}
function setupPeriodMenu(id,onChange,parseValue=Number){
  const root=document.querySelector(`#${id}`);
  const trigger=root.firstElementChild;
  const label=trigger.querySelector('span');
  const options=root.querySelector('.analysis-options');
  const close=()=>{options.hidden=true;trigger.setAttribute('aria-expanded','false')};
  const select=value=>{
    root.dataset.value=value;
    options.querySelectorAll('[data-value]').forEach(item=>{
      const selected=item.dataset.value===value;
      item.setAttribute('aria-checked',String(selected));
      if(selected)label.textContent=item.querySelector('span').textContent;
    });
  };
  trigger.addEventListener('click',event=>{
    event.stopPropagation();
    const open=options.hidden;
    document.querySelectorAll('.period-menu .analysis-options').forEach(menu=>menu.hidden=true);
    options.hidden=!open;
    trigger.setAttribute('aria-expanded',String(open));
  });
  options.addEventListener('click',event=>{
    const option=event.target.closest('[data-value]');
    if(!option)return;
    select(option.dataset.value);
    close();
    onChange(parseValue(option.dataset.value));
    trigger.focus();
  });
  document.addEventListener('click',event=>{if(!root.contains(event.target))close()});
  root.addEventListener('keydown',event=>{if(event.key==='Escape'&&!options.hidden){close();trigger.focus()}});
  return select;
}
setupPeriodMenu('activityRange',renderActivityChart);
setupPeriodMenu('responseRange',renderAgentResponses);
let pendingDiagnosticsDays=7;
setupPeriodMenu('diagnosticsRange',days=>{pendingDiagnosticsDays=days});
renderActivityChart(30);
renderAgentResponses(7);
const dispatchInfo=document.querySelector('.dispatch-info');
dispatchInfo.addEventListener('pointerenter',()=>showMetricTip(dispatchInfo));
dispatchInfo.addEventListener('pointerleave',hideMetricTip);
dispatchInfo.addEventListener('focus',()=>showMetricTip(dispatchInfo));
dispatchInfo.addEventListener('blur',hideMetricTip);
dispatchInfo.addEventListener('click',event=>{event.stopPropagation();showMetricTip(dispatchInfo)});
let activityResizeFrame;
window.addEventListener('resize',()=>{
  cancelAnimationFrame(activityResizeFrame);
  activityResizeFrame=requestAnimationFrame(()=>renderActivityChart(currentActivityDays));
});

document.querySelectorAll('a,button').forEach(el=>el.addEventListener('click',e=>{if(el.getAttribute('href')==='#')e.preventDefault()}));

const analysisMenu=document.querySelector('#analysisMenu');
const analysisMenuButton=document.querySelector('#analysisMenuButton');
const analysisMenuLabel=document.querySelector('#analysisMenuLabel');
const analysisOptions=document.querySelector('#analysisOptions');
const caseAction=document.querySelector('#caseAction');
const systemAction=document.querySelector('#systemAction');
const metricToggle=document.querySelector('#metricToggle');
const refreshSystems=document.querySelector('#refreshSystems');
const refreshTime=document.querySelector('#refreshTime');
let systemLastUpdated=Date.now()-180000;
let systemRefreshInFlight=false;

function updateRefreshLabel(){
  const seconds=Math.max(0,Math.floor((Date.now()-systemLastUpdated)/1000));
  refreshTime.textContent=seconds<5?'just now':seconds<60?`${seconds}s ago`:`${Math.floor(seconds/60)} min${seconds<120?'':'s'} ago`;
}

function updateSystemMetrics({allowStatusChange=true}={}){
  systems.forEach((system,index)=>{
    const current=Math.max(1,Number.parseInt(system[1],10)||50);
    const volatility=current>1000?.055:current>300?.08:.12;
    const next=Math.max(8,Math.round(current*(1+(Math.random()-.5)*volatility)));
    system[1]=`${next}ms`;
    if(allowStatusChange){
      if(system[2]==='down'&&Math.random()<.08)system[2]='up';
      else if(system[2]==='up'&&Math.random()<.012)system[2]='down';
    }
    const card=kpiGrid.querySelector(`[data-system-index="${index}"]`);
    if(!card)return;
    const value=card.querySelector('strong');
    const status=card.querySelector('.system-status');
    value.textContent=system[1];
    value.classList.remove('system-value-updated');
    void value.offsetWidth;
    value.classList.add('system-value-updated');
    status.className=`system-status ${system[2]}`;
    status.textContent=system[2]==='up'?'Up':'Down';
  });
  systemLastUpdated=Date.now();
  updateRefreshLabel();
}

function openCasebox(category='all'){
  if(embeddedMode&&parent!==window){
    parent.postMessage({type:'intellibox:navigate',page:'casebox',category},location.origin);
    return;
  }
  caseboxView.dataset.category=category;
  selectGlobalPage('casebox');
}

caseAction.querySelector('a').addEventListener('click',event=>{
  event.preventDefault();
  openCasebox('all');
});

function syncMetricToggle(){
  const expanded=analysisMode==='system'?systemExpanded:caseExpanded;
  metricToggle.classList.toggle('expanded',expanded);
  metricToggle.setAttribute('aria-expanded',String(expanded));
  metricToggle.setAttribute('aria-label',analysisMode==='system'?(systemExpanded?'Show fewer systems':'Show more systems'):(caseExpanded?'Show summary metrics':'Show detailed metrics'));
}

function selectAnalysisMode(mode){
  analysisMode=mode;
  analysisMenuLabel.textContent=mode==='system'?'System analysis':'Case analysis';
  analysisOptions.querySelectorAll('[data-mode]').forEach(option=>option.setAttribute('aria-checked',String(option.dataset.mode===mode)));
  analysisOptions.hidden=true;
  analysisMenuButton.setAttribute('aria-expanded','false');
  caseAction.hidden=analysisMode!=='case';
  systemAction.hidden=analysisMode!=='system';
  kpiGrid.hidden=false;
  caseExpanded=false;
  systemExpanded=false;
  if(analysisMode==='system')renderSystemCards();else renderCaseKpis();
  syncMetricToggle();
}

analysisMenuButton.addEventListener('click',()=>{
  const opening=analysisOptions.hidden;
  analysisOptions.hidden=!opening;
  analysisMenuButton.setAttribute('aria-expanded',String(opening));
  if(opening)analysisOptions.querySelector(`[data-mode="${analysisMode}"]`).focus();
});
analysisOptions.addEventListener('click',event=>{
  const option=event.target.closest('[data-mode]');
  if(option)selectAnalysisMode(option.dataset.mode);
});
analysisMenu.addEventListener('keydown',event=>{
  const options=[...analysisOptions.querySelectorAll('[data-mode]')];
  const index=options.indexOf(document.activeElement);
  if(event.key==='Escape'){
    analysisOptions.hidden=true;
    analysisMenuButton.setAttribute('aria-expanded','false');
    analysisMenuButton.focus();
  }else if(!analysisOptions.hidden&&(event.key==='ArrowDown'||event.key==='ArrowUp')){
    event.preventDefault();
    const direction=event.key==='ArrowDown'?1:-1;
    options[(index+direction+options.length)%options.length].focus();
  }else if(!analysisOptions.hidden&&(event.key==='Enter'||event.key===' ')){
    const option=event.target.closest('[data-mode]');
    if(option){event.preventDefault();selectAnalysisMode(option.dataset.mode)}
  }
});
document.addEventListener('click',event=>{
  if(!analysisMenu.contains(event.target)){
    analysisOptions.hidden=true;
    analysisMenuButton.setAttribute('aria-expanded','false');
  }
});

let metricTransitionTimer;
function finishMetricTransition(){
  clearTimeout(metricTransitionTimer);
  kpiGrid.style.height='';
  kpiGrid.style.overflow='';
  kpiGrid.classList.remove('metric-grid-animating');
  metricToggle.disabled=false;
}
function animateMetricCards(expanding,render,baseCount){
  if(matchMedia('(prefers-reduced-motion: reduce)').matches){render();return}
  clearTimeout(metricTransitionTimer);
  metricToggle.disabled=true;
  const oldHeight=kpiGrid.getBoundingClientRect().height;
  const animateHeight=newHeight=>{
    kpiGrid.style.height=`${oldHeight}px`;
    kpiGrid.style.overflow='hidden';
    kpiGrid.classList.add('metric-grid-animating');
    void kpiGrid.offsetHeight;
    requestAnimationFrame(()=>{kpiGrid.style.height=`${newHeight}px`});
  };
  if(expanding){
    render();
    const cards=[...kpiGrid.querySelectorAll('.kpi-card,.system-card')];
    const enteringCards=cards.slice(baseCount);
    const newHeight=kpiGrid.getBoundingClientRect().height;
    animateHeight(newHeight);
    enteringCards.forEach((card,index)=>{
      card.classList.add('metric-card-enter');
      card.style.setProperty('--metric-delay',`${index*48}ms`);
    });
    metricTransitionTimer=setTimeout(finishMetricTransition,Math.max(460,enteringCards.length*48+300));
    return;
  }
  const extra=[...kpiGrid.querySelectorAll('.kpi-card,.system-card')].slice(baseCount);
  extra.forEach(card=>card.remove());
  let enteringCards=[];
  if(analysisMode==='case'){
    kpiGrid.classList.remove('case-expanded');
    kpiGrid.classList.add('case-summary');
    kpiGrid.insertAdjacentHTML('beforeend',caseCardMarkup(kpis[4],3)+caseCardMarkup(kpis[5],4));
    enteringCards=[...kpiGrid.querySelectorAll('.kpi-card')].slice(3);
    enteringCards.forEach((card,index)=>{
      card.classList.add('metric-card-enter');
      card.style.setProperty('--metric-delay',`${index*45}ms`);
    });
  }
  const newHeight=kpiGrid.getBoundingClientRect().height;
  animateHeight(newHeight);
  metricTransitionTimer=setTimeout(finishMetricTransition,Math.max(420,enteringCards.length*45+280));
}

metricToggle.addEventListener('click',()=>{
  if(analysisMode==='system'){
    systemExpanded=!systemExpanded;
    animateMetricCards(systemExpanded,renderSystemCards,5);
  }else{
    caseExpanded=!caseExpanded;
    animateMetricCards(caseExpanded,renderCaseKpis,3);
  }
  syncMetricToggle();
});

refreshSystems.addEventListener('click',()=>{
  if(systemRefreshInFlight)return;
  systemRefreshInFlight=true;
  refreshSystems.classList.add('refreshing');
  refreshSystems.disabled=true;
  kpiGrid.classList.add('is-loading');
  kpiGrid.setAttribute('aria-busy','true');
  setTimeout(()=>{
    updateSystemMetrics();
    kpiGrid.classList.remove('is-loading');
    kpiGrid.removeAttribute('aria-busy');
    refreshSystems.classList.remove('refreshing');
    refreshSystems.disabled=false;
    systemRefreshInFlight=false;
  },900+Math.round(Math.random()*500));
});

updateRefreshLabel();
setInterval(updateRefreshLabel,1000);
setInterval(()=>{
  if(analysisMode==='system'&&!systemRefreshInFlight)updateSystemMetrics();
},7000);

const diagnosticData=[
  {icon:'Icon/flash lighting bolt filled.svg',value:'128',empty:'0',label:'cases analysed',change:'↑12% vs previous period',tone:'neutral',color:'#0473EA',tint:'#EAF4FF',path:'M0 56 L22 30 L42 43 L62 34 L88 10 L110 18 L128 2 L145 14'},
  {icon:'Icon/alert triangle ! exclamation filled.svg',value:'28',empty:'–',label:'SLA breaches',change:'↓5% vs previous period',tone:'positive',color:'#E3232C',tint:'#FDE9EA',path:'M0 27 L25 18 L52 14 L78 6 L95 48 L116 58 L135 50 L145 56'},
  {icon:'Icon/timer clock filled.svg',value:'12m 40s',empty:'–',label:'average duration',change:'↓18% vs previous period',tone:'positive',color:'#0473EA',tint:'#EAF4FF',path:'M0 5 L14 22 L38 25 L58 34 L72 10 L86 5 L104 40 L117 69 L130 66 L145 82'},
  {icon:'Icon/user profile person filled.svg',value:'18.7%',empty:'–',label:'human intervention',change:'↑13% vs previous period',tone:'warning',color:'#C77D00',tint:'#FFF5DF',path:'M0 62 L24 56 L50 54 L68 45 L86 27 L104 34 L124 17 L145 0'}
];
const diagnosticKpis=document.querySelector('#diagnosticKpis');
diagnosticKpis.innerHTML=diagnosticData.map((item,index)=>`<article class="diagnostic-kpi" style="--color:${item.color};--tint:${item.tint}"><div class="diag-kpi-copy"><strong data-empty="${item.empty}" data-value="${item.value}">${item.empty}</strong><span>${item.label}</span><small class="diag-change" data-value="${item.change}">– vs previous period</small></div><svg class="diag-spark" viewBox="0 0 145 84" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="diagGradient${index}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${item.color}" stop-opacity=".22"/><stop offset=".68" stop-color="${item.color}" stop-opacity=".05"/><stop offset="1" stop-color="${item.color}" stop-opacity="0"/></linearGradient></defs><path class="diag-fill" d="M0 64 L145 64 L145 84 L0 84 Z" fill="url(#diagGradient${index})"/><path class="line" d="M0 64 L145 64" data-loaded-path="${smoothSparkline(item.path.replace(/^M/,'').replaceAll(' L',' ').replace(/(\d+) (\d+)/g,'$1,$2')).path}"/></svg></article>`).join('');

const stageTimeData=[
  {stage:'Intake & de-duplication',owner:'Agent',cases:128,p50:'12s',p90:'28s',share:3,tone:'normal'},
  {stage:'Classify & extract',owner:'Agent',cases:128,p50:'34s',p90:'1m 12s',share:7,tone:'normal'},
  {stage:'Policy & identity checks',owner:'Agent',cases:116,p50:'48s',p90:'2m 10s',share:9,tone:'normal'},
  {stage:'Order status lookup',owner:'Agent',cases:104,p50:'22s',p90:'58s',share:5,tone:'normal'},
  {stage:'Cancellation execution',owner:'Agent',cases:92,p50:'38s',p90:'1m 46s',share:8,tone:'normal'},
  {stage:'Draft the reply',owner:'Agent',cases:104,p50:'46s',p90:'2m 05s',share:9,tone:'normal'},
  {stage:'Waiting for human review',owner:'Client service team',cases:32,p50:'4m 20s',p90:'18m 40s',share:54,tone:'warning'},
  {stage:'Send to client',owner:'Email service',cases:102,p50:'18s',p90:'1m 30s',share:5,tone:'normal'}
];
const stageTimeRows=document.querySelector('#stageTimeRows');
// Demo step outcomes. Columns after the name: reached, held, errors, skipped, pending, P50, P90.
const caseStopSteps=[
  ['Check incoming message',128,0,0,0,0,'2s','5s'],
  ['Check for duplicates',128,0,0,4,0,'4s','9s'],
  ['Identify the request type',124,0,0,0,0,'18s','40s'],
  ['Create the case',124,0,1,0,0,'5s','12s'],
  ['Link the email to the case',123,0,0,0,0,'3s','8s'],
  ['Check the sender’s email domain',123,2,0,0,0,'3s','8s'],
  ['Check if the team can handle the request',121,3,0,0,0,'7s','18s'],
  ['Check for missing information',118,10,0,0,2,'18s','48s'],
  ['Verify the customer’s identity',106,2,1,0,1,'25s','1m 8s'],
  ['Look up the order status',102,0,2,0,1,'22s','58s'],
  ['Cancel the order',99,0,1,10,0,'38s','1m 46s'],
  ['Notify the operations team',88,0,0,0,0,'5s','14s'],
  ['Draft the reply',98,0,0,0,0,'46s','2m 5s'],
  ['Queue the reply for approval',32,0,0,0,7,'4m 20s','18m 40s'],
  ['Send to the team for manual processing',0,0,0,0,0,'—','—']
];

function renderCaseStops(days,factor){

  const steps=caseStopSteps.map(([name,reached,held,errors,skipped,pending,typical,slow])=>{
    const count=value=>Math.round(value*factor);
    const entered=count(reached);
    const stopped=count(held)+count(errors);
    return {
      name,entered,stopped,typical,slow,
      held:count(held),errors:count(errors),skipped:count(skipped),pending:count(pending),
      passed:entered-stopped-count(skipped)-count(pending),
      share:entered?`${(100*stopped/entered).toFixed(1)}%`:'—'
    };
  });
  const notable=steps.filter(step=>step.stopped>0);
  const reachedSteps=steps.filter(step=>step.entered>0).length;
  document.querySelector('#caseStopsSummary').textContent=
    `Sample data: ${steps[0].entered.toLocaleString()} cases reached at least one step. Cases were held up or had an error at ${notable.length} of ${reachedSteps} steps they reached.`;
  const row=(step,full)=>{
    const counts=full
      ? [step.entered,step.passed,step.held,step.errors,step.skipped,step.pending,step.share,step.typical,step.slow]
      : [step.entered,step.held,step.errors,step.share];
    return `<tr><th scope="row">${step.name}${step.entered?'':'<small>Not reached</small>'}</th>${counts.map(value=>`<td>${value.toLocaleString()}</td>`).join('')}</tr>`;
  };
  document.querySelector('#caseStopsHighlights').innerHTML=notable.map(step=>row(step,false)).join('');
  document.querySelector('#caseStopsAll').innerHTML=steps.map(step=>row(step,true)).join('');
}

function renderStageTime(days,factor){
  renderCaseStops(days,factor);
  const summary=days===7?['8m 24s','32m 10s']:days===30?['9m 02s','35m 40s']:['9m 48s','41m 12s'];
  document.querySelector('#stageTypical').textContent=summary[0];
  document.querySelector('#stageSlow').textContent=summary[1];
  document.querySelector('#stageMedianNote').textContent=`Median across ${Math.round(128*factor).toLocaleString()} cases`;
  stageTimeRows.innerHTML=stageTimeData.map(item=>`<tr class="${item.tone==='warning'?'is-bottleneck':''}"><td><strong>${item.stage}</strong></td><td>${item.owner}</td><td>${Math.round(item.cases*factor).toLocaleString()}</td><td>${item.p50}</td><td>${item.p90}</td><td><span class="stage-share"><i style="--share:${item.share}%"></i><b>${item.share}%</b></span></td></tr>`).join('');
}

document.querySelectorAll('.stage-info').forEach(info=>{
  info.addEventListener('pointerenter',()=>showMetricTip(info));
  info.addEventListener('pointerleave',hideMetricTip);
  info.addEventListener('focus',()=>showMetricTip(info));
  info.addEventListener('blur',hideMetricTip);
  info.addEventListener('click',event=>{event.stopPropagation();showMetricTip(info)});
});

const dashboardTab=document.querySelector('#dashboardTab');
const diagnosticsTab=document.querySelector('#diagnosticsTab');
const dashboardView=document.querySelector('#dashboardView');
const diagnosticsView=document.querySelector('#diagnosticsView');
const runScan=document.querySelector('#runScan');

let scanTimer;

function showView(view){
  const diagnostics=view==='diagnostics';
  dashboardView.hidden=diagnostics;
  diagnosticsView.hidden=!diagnostics;
  dashboardTab.classList.toggle('selected',!diagnostics);
  diagnosticsTab.classList.toggle('selected',diagnostics);
  dashboardTab.setAttribute('aria-selected',String(!diagnostics));
  diagnosticsTab.setAttribute('aria-selected',String(diagnostics));
  document.body.classList.toggle('dashboard-mode',!diagnostics);
  document.body.classList.toggle('diagnostics-mode',diagnostics);
  document.body.classList.remove('casebox-mode');
}
dashboardTab.addEventListener('click',()=>showView('dashboard'));
diagnosticsTab.addEventListener('click',()=>showView('diagnostics'));
document.querySelector('#deliveryDetails').addEventListener('click',event=>{
  event.preventDefault();
  if(embeddedMode&&parent!==window){
    parent.postMessage({type:'intellibox:navigate',page:'diagnostics',section:'deliverability'},location.origin);
    return;
  }
  showView('diagnostics');
  const section=document.querySelector('#deliverability');
  section.focus({preventScroll:true});
  section.scrollIntoView({block:'start'});
});

const requestSplit=document.querySelector('#requestSplit');

const sampleRequest={Sentiment:'Neutral',Category:'Trade'};
const requestFlowDetail=document.querySelector('#requestFlowDetail');
const requestFlowButtons=document.querySelectorAll('.request-flow button');
function updateRequestFlow(){
  document.querySelector('#requestMiddle').textContent=sampleRequest[requestSplit.dataset.value];

  requestFlowDetail.hidden=true;
  requestFlowButtons.forEach(button=>button.setAttribute('aria-pressed','false'));
}

setupPeriodMenu('requestSplit',updateRequestFlow,String);

requestFlowButtons.forEach(button=>button.addEventListener('click',()=>{
  const wasSelected=button.getAttribute('aria-pressed')==='true';
  requestFlowButtons.forEach(item=>item.setAttribute('aria-pressed',String(item===button&&!wasSelected)));
  document.querySelector('#requestDetailTitle').textContent=button.querySelector('b').textContent;
  requestFlowDetail.hidden=wasSelected;
}));

const diagnosticsSkeletons=diagnosticsView.querySelectorAll(
  '.delivery-summary,.email-risk-chart,.email-risk p:last-child,.stage-time-loaded,.stage-time-empty,.case-stops-results,.case-stops-empty,.return-panel .diagnostic-overview-donut,.human-legend,.request-flow-body,.customer-panel .diagnostic-empty'
);
const appliedDiagnosticsRange=document.querySelector('#appliedDiagnosticsRange');
diagnosticsSkeletons.forEach(element=>element.classList.add('diagnostics-skeleton'));

function completeScan(days=7){
  diagnosticsView.removeAttribute('aria-busy');
  diagnosticsSkeletons.forEach(element=>element.inert=false);
  appliedDiagnosticsRange.textContent=`Analysis range: Last ${days} days`;
  appliedDiagnosticsRange.hidden=false;
  const factor=days===7?1:days===30?3.8:10.5;
  const count=value=>Math.round(value*factor);
  renderStageTime(days,factor);
  const requests=count(1);
  const requestLabel=requests===1?'request':'requests';
  document.querySelector('#requestPeriod').textContent=`${requests} ${requestLabel} in the last ${days} days`;
  document.querySelectorAll('.request-flow-count').forEach(label=>label.textContent=`100% (${requests})`);
  document.querySelector('#requestDetailCount').textContent=`${requests} of ${requests} ${requestLabel} · 100%`;
  const delivered=count(125),bounced=count(1),rejected=count(1);
  document.querySelector('#detailDelivered').textContent=delivered;
  document.querySelector('#detailBounced').textContent=bounced;
  document.querySelector('#detailRejected').textContent=rejected;
  document.querySelector('#deliverySuccessDetail').textContent=`${(100*delivered/(delivered+bounced+rejected)).toFixed(1)}%`;
  diagnosticsView.classList.remove('is-loading');
  diagnosticsView.classList.add('is-loaded');
  const values=[count(128).toLocaleString(),count(28).toLocaleString(),{7:'12m 40s',30:'13m 12s',90:'14m 05s'}[days],`${(100*count(28)/count(128)).toFixed(1)}%`];
  document.querySelectorAll('.diag-kpi-copy strong').forEach((el,index)=>el.textContent=values[index]);
  document.querySelectorAll('.diag-change').forEach((el,index)=>{el.textContent=el.dataset.value;el.classList.add(diagnosticData[index].tone)});
  document.querySelectorAll('.diag-spark .line').forEach(el=>el.setAttribute('d',el.dataset.loadedPath));
  document.querySelectorAll('.diag-fill').forEach((el,index)=>el.setAttribute('d',`${el.parentElement.querySelector('.line').dataset.loadedPath} L145 84 L0 84 Z`));
  document.querySelectorAll('.diagnostic-empty,.empty-value').forEach(el=>el.hidden=true);
  document.querySelectorAll('.diagnostic-loaded,.loaded-value').forEach(el=>el.hidden=false);
  document.querySelector('.diag-total').textContent=count(28).toLocaleString();
  {
    const kind='human';
    const items=[...document.querySelectorAll(`.${kind}-legend li`)].map(row=>{
      const percent=row.querySelector('.loaded-value').textContent;
      return {label:row.querySelector('span').textContent,color:row.querySelector('i').style.getPropertyValue('--c'),value:parseFloat(percent),percent};
    });
    renderInteractiveDonut(`#${kind}Donut`,`#${kind}Tooltip`,items,'status-segment',{navigate:false,showCount:false});
  }


  runScan.disabled=false;
  runScan.classList.remove('is-scanning');
  runScan.querySelector('.scan-label').textContent='Refresh analysis';
}

runScan.addEventListener('click',()=>{
  clearTimeout(scanTimer);
  diagnosticsView.classList.remove('is-loaded');
  diagnosticsView.classList.add('is-loading');
  diagnosticsView.setAttribute('aria-busy','true');
  diagnosticsSkeletons.forEach(element=>element.inert=true);
  runScan.disabled=true;
  runScan.classList.add('is-scanning');
  runScan.querySelector('.scan-label').textContent='Refreshing';

  const days=pendingDiagnosticsDays;
  scanTimer=setTimeout(()=>completeScan(days),1500);
});

const navDashboard=document.querySelector('#navDashboard');
const navCasebox=document.querySelector('#navCasebox');
const navAbout=document.querySelector('#navAbout');
const caseboxView=document.querySelector('#caseboxView');
const viewSwitch=document.querySelector('.view-switch');
const poweredBrand=document.querySelector('.powered');
const aboutSheet=document.querySelector('#aboutSheet');
const sheetBackdrop=document.querySelector('#sheetBackdrop');
const appSearch=document.querySelector('#appSearch');
const aboutSupplement=document.querySelector('#aboutSupplement');
const aboutScroll=document.querySelector('.sheet-scroll');
let lastFocusedElement;

function selectGlobalPage(page){
  const isDashboard=page==='dashboard';
  caseboxView.hidden=isDashboard;
  viewSwitch.hidden=!isDashboard;
  poweredBrand.hidden=!isDashboard;
  if(isDashboard){
    showView('dashboard');
  }else{
    dashboardView.hidden=true;
    diagnosticsView.hidden=true;
    document.body.classList.remove('dashboard-mode','diagnostics-mode');
    document.body.classList.add('casebox-mode');
  }
  navDashboard.classList.toggle('active',isDashboard);
  navCasebox.classList.toggle('active',!isDashboard);
}

function openAbout(){
  lastFocusedElement=document.activeElement;
  sheetBackdrop.hidden=false;
  aboutSheet.setAttribute('aria-hidden','false');
  navAbout.setAttribute('aria-expanded','true');
  document.body.classList.add('sheet-open');
  requestAnimationFrame(()=>{
    aboutSheet.classList.add('open');
    appSearch.focus();
  });
}

function closeAbout(){
  aboutSheet.classList.remove('open');
  aboutSheet.setAttribute('aria-hidden','true');
  navAbout.setAttribute('aria-expanded','false');
  document.body.classList.remove('sheet-open');
  setTimeout(()=>{sheetBackdrop.hidden=true},320);
  if(lastFocusedElement)lastFocusedElement.focus();
  if(embeddedMode&&parent!==window)parent.postMessage({type:'intellibox:about-closed'},location.origin);
}

addEventListener('message',event=>{
  if(event.origin===location.origin&&event.data?.type==='intellibox:open-about')openAbout();
});

navDashboard.addEventListener('click',()=>selectGlobalPage('dashboard'));
navCasebox.addEventListener('click',()=>selectGlobalPage('casebox'));
navAbout.addEventListener('click',openAbout);
sheetBackdrop.addEventListener('click',closeAbout);
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&aboutSheet.classList.contains('open'))closeAbout()});

appSearch.addEventListener('input',()=>{
  const query=appSearch.value.trim().toLowerCase();
  const apps=[...document.querySelectorAll('#applicationList article')];
  const searching=query.length>0;
  aboutSupplement.hidden=searching;
  aboutScroll.classList.toggle('search-results-mode',searching);
  apps.forEach(app=>app.hidden=!`${app.dataset.app} ${app.textContent}`.toLowerCase().includes(query));
  document.querySelector('#noApps').hidden=apps.some(app=>!app.hidden);
});

const requestedEmbeddedView=new URLSearchParams(location.search).get('view');
if(embeddedMode){
  if(requestedEmbeddedView==='diagnostics'){
    showView('diagnostics');
    completeScan();
  }else if(requestedEmbeddedView==='casebox'){
    selectGlobalPage('casebox');
  }else if(requestedEmbeddedView==='about'){
    selectGlobalPage('dashboard');
    openAbout();
  }else{
    selectGlobalPage('dashboard');
  }
}
