const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const read = name => fs.readFileSync(path.join(__dirname, name), 'utf8');
const write = (name, contents) => fs.writeFileSync(path.join(__dirname, name), contents);
const shellBackup = 'sbproto-before-packaging.html';
const currentShell = read('sbproto.html');
const shell = currentShell.includes('id="intelliboxBundle"') ? read(shellBackup) : currentShell;

function inlineAssets(source) {
  return source.replace(/(["'])(Icon\/[^"'\n]+\.svg|agentOS\.svg)\1/g, (match, quote, name) => {
    const asset = fs.readFileSync(path.join(__dirname, name));
    return quote + 'data:image/svg+xml;base64,' + asset.toString('base64') + quote;
  });
}

const localFonts = /\s*<link[^>]+href="https:\/\/fonts\.(?:googleapis|gstatic)\.com[^"]*"[^>]*>/g;
const closeScript = source => source.replace(/<\/script/gi, '<\\/script');
const appCss = inlineAssets(read('styles.css'));
const appScript = inlineAssets(read('script.js'))
  .replace("const requestedEmbeddedView=new URLSearchParams(location.search).get('view');", 'const requestedEmbeddedView=window.intelliboxEntry;')
  .replace("const embeddedMode=new URLSearchParams(location.search).get('embedded')==='1';", 'const embeddedMode=window.intelliboxEmbedded;')
  .replaceAll('},location.origin);', "},location.origin==='null'?'*':location.origin);")
  .replace("if(event.origin===location.origin&&event.data?.type==='intellibox:open-about')", "if(event.source===parent&&event.origin===location.origin&&event.data?.type==='intellibox:open-about')")
  .replaceAll('location.origin', 'window.origin');
const app = inlineAssets(read('index.html'))
  .replace(/<script>if\(new URLSearchParams[^\n]+<\/script>/, '')
  .replace(localFonts, '')
  .replace(/<link rel="stylesheet" href="styles\.css[^"]*"\s*\/>/, () => '<style>\n' + appCss + '\n</style>')
  .replace(/<script src="script\.js[^"]*"><\/script>/, () => '<script>\n' + closeScript(appScript) + '\n</script>');

function makeApp(view, embedded) {
  const chrome = embedded ? '' : '<style>.global-header,.view-switch,.powered{display:none!important}body>main{padding-top:0}</style>';
  return app.replace('</head>', () =>
    chrome + '<script>window.intelliboxEntry=' + JSON.stringify(view) +
    ';window.intelliboxEmbedded=' + embedded + ';</script></head>'
  ).replace('</body>', () =>
    (embedded || view !== 'diagnostics' ? '' : "<script>showView('diagnostics');completeScan();</script>") + '</body>'
  );
}

const frameUrl = / src="\.\/index\.html\?embedded=1[^"]+"/;
if (!frameUrl.test(shell)) throw new Error('Shell iframe source was not found');
const appBundle = makeApp('__INTELLIBOX_ENTRY__', true);
const packedShell = inlineAssets(shell).replace(localFonts, '')
  .replace(frameUrl, '')
  .replace('    requestAnimationFrame(syncAppContentInsets);\n    return;', () =>
    '    frame.srcdoc=$("#intelliboxBundle").textContent.replace("__INTELLIBOX_ENTRY__",contentPage);\n    requestAnimationFrame(syncAppContentInsets);\n    return;')
  .replaceAll('},location.origin)', '},location.origin==="null"?"*":location.origin)')
  .replace('if(e.origin!==location.origin||e.data?.type!=="intellibox:about-closed"', 'if(e.origin!==location.origin||e.source!==$("#intelliboxFrame")?.contentWindow||e.data?.type!=="intellibox:about-closed"')
  .replaceAll('location.origin', 'window.origin')
  .replace('<head>', () => '<head>\n<script id="intelliboxBundle" type="text/plain">' +
    appBundle.replace(/<\/script>/gi, '</script-BUNDLE>') + '</script>');
const finalShell = packedShell.replace('.textContent.replace("__INTELLIBOX_ENTRY__",contentPage)', '.textContent.replaceAll("</script-BUNDLE>","</"+"script>").replace("__INTELLIBOX_ENTRY__",contentPage)');

const outputs = {
  'sbproto.html': finalShell,
  'intellibox-overview.html': makeApp('overview', false),
  'intellibox-diagnostics.html': makeApp('diagnostics', false)
};
for (const [name, html] of Object.entries(outputs)) {
  for (const match of html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/gi)) {
    if (!match[1].includes('text/plain')) new vm.Script(match[2], {filename: name});
  }
}
if (!fs.existsSync(path.join(__dirname, shellBackup))) fs.copyFileSync(path.join(__dirname, 'sbproto.html'), path.join(__dirname, shellBackup));
for (const [name, html] of Object.entries(outputs)) write(name, html);
