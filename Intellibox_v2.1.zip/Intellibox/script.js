const kpis=[
  {value:'128',label:'Email received',sub:'↑ 18% vs previous day',tone:'neutral',color:'var(--metric-purple-chart)',points:'0,58 14,42 28,30 42,38 56,60 70,52 84,17 98,7 112,13 126,29 140,34 154,26 168,25 184,14'},
  {value:'24',label:'Email sent',sub:'↑ 9% vs previous day',tone:'neutral',color:'var(--metric-purple-chart)',points:'0,61 18,36 36,23 54,35 72,45 90,38 108,20 126,7 144,14 162,17 180,3 194,12'},
  {value:'92',label:'Cases completed',sub:'↑ 14% vs previous day',tone:'green',color:'#38D200',points:'0,62 32,56 58,54 76,44 96,25 120,35 140,21 160,4'},
  {value:'12',label:'Bounced',sub:'↑ 3% vs previous day',tone:'red',color:'#E3232C',points:'0,38 28,25 52,21 75,14 96,12 124,4 152,18 176,25'},
  {value:'27',label:'Pending actions',sub:'↑ 11% vs previous day',tone:'amber',color:'#F4A909',tooltip:'Includes pending approval and pending manual resolution.',points:'0,43 25,22 52,17 75,8 100,6 124,1 140,12 152,37 166,43 182,77'},
  {value:'6',label:'Exceptions',sub:'↑ 5% vs previous day',tone:'red',color:'#E3232C',tooltip:'Includes rejected, escalated, and expired cases.',points:'0,37 30,24 60,19 85,12 110,11 135,3 160,17 184,24'}
];
const embeddedMode=new URLSearchParams(location.search).get('embedded')==='1';
if(embeddedMode)document.body.classList.add('embedded-mode');
const caseDetailKpis=[
  {value:'15',label:'Pending approval',sub:'↑ 8% vs previous day',tone:'amber',color:'#F4A909',points:kpis[4].points},
  {value:'12',label:'Pending manual resolution',sub:'↑ 15% vs previous day',tone:'amber',color:'#F4A909',points:kpis[4].points}
];
const exceptionDetailKpis=[
  {value:'3',label:'Rejected',sub:'↑ 3% vs previous day',tone:'red',color:'#E3232C',points:kpis[5].points},
  {value:'2',label:'Escalated',sub:'↑ 7% vs previous day',tone:'red',color:'#E3232C',points:kpis[5].points},
  {value:'1',label:'Expired',sub:'↑ 2% vs previous day',tone:'red',color:'#E3232C',points:kpis[5].points}
];
const smoothSparkline=points=>{
  const values=points.split(' ').map(pair=>pair.split(',').map(Number));
  let path=`M ${values[0][0]} ${values[0][1]}`;
  for(let i=1;i<values.length-1;i++){
    const [x,y]=values[i];
    const [nextX,nextY]=values[i+1];
    path+=` Q ${x} ${y} ${(x+nextX)/2} ${(y+nextY)/2}`;
  }
  const last=values.at(-1);
  path+=` T ${last[0]} ${last[1]}`;
  return {path,last};
};

const kpiGrid=document.querySelector('#kpiGrid');
function caseCardMarkup(k,i){
  const {path,last}=smoothSparkline(k.points);
  const info=k.tooltip?`<span class="metric-tip-wrap"><button class="info-dot" aria-label="More about ${k.label}" data-tooltip="${k.tooltip}"><img src="Icon/info i tooltip circle.svg" alt=""></button></span>`:'';
  return `<article class="kpi-card" role="link" tabindex="0" data-case-category="${k.label}"><strong>${k.value}</strong><span class="label">${k.label}${info}</span><span class="sub tone-${k.tone}">${k.sub}</span><svg class="trend" viewBox="0 0 190 80" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="g${i}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${k.color}" stop-opacity=".46"/><stop offset=".60" stop-color="${k.color}" stop-opacity=".25"/><stop offset="1" stop-color="${k.color}" stop-opacity="0"/></linearGradient></defs><path class="area" d="${path} L ${last[0]} 80 L 0 80 Z" fill="url(#g${i})"/><path class="sparkline" d="${path}" fill="none" stroke="${k.color}" stroke-width="1.65" vector-effect="non-scaling-stroke"/></svg></article>`;
}
function renderCaseKpis(){
  const coreCards=[kpis[0],kpis[1],kpis[2],kpis[4],kpis[5]];
  const cards=caseExpanded?[kpis[0],kpis[1],kpis[2],kpis[3],...caseDetailKpis,...exceptionDetailKpis]:coreCards;
  kpiGrid.className=`kpi-grid ${caseExpanded?'case-expanded':'case-summary'}`;
  kpiGrid.innerHTML=cards.map(caseCardMarkup).join('');
}
const metricFloatingTip=document.createElement('div');
metricFloatingTip.className='metric-floating-tip';
metricFloatingTip.hidden=true;
document.body.append(metricFloatingTip);
function showMetricTip(button){
  const rect=button.getBoundingClientRect();
  metricFloatingTip.textContent=button.dataset.tooltip;
  metricFloatingTip.hidden=false;
  metricFloatingTip.style.left=`${Math.min(Math.max(rect.left+rect.width/2,130),innerWidth-130)}px`;
  metricFloatingTip.style.top=`${rect.top-10}px`;
}
function hideMetricTip(){metricFloatingTip.hidden=true}
kpiGrid.addEventListener('pointerover',event=>{const button=event.target.closest('.info-dot');if(button)showMetricTip(button)});
kpiGrid.addEventListener('pointerout',event=>{if(event.target.closest('.info-dot'))hideMetricTip()});
kpiGrid.addEventListener('focusin',event=>{const button=event.target.closest('.info-dot');if(button)showMetricTip(button)});
kpiGrid.addEventListener('focusout',event=>{if(event.target.closest('.info-dot'))hideMetricTip()});
kpiGrid.addEventListener('click',event=>{const button=event.target.closest('.info-dot');if(button){event.stopPropagation();showMetricTip(button)}});
kpiGrid.addEventListener('click',event=>{
  const card=event.target.closest('.kpi-card[data-case-category]');
  if(card&&!event.target.closest('.info-dot'))openCasebox(card.dataset.caseCategory);
});
kpiGrid.addEventListener('keydown',event=>{
  const card=event.target.closest('.kpi-card[data-case-category]');
  if(card&&(event.key==='Enter'||event.key===' ')){
    event.preventDefault();
    openCasebox(card.dataset.caseCategory);
  }
});
document.addEventListener('click',event=>{if(!event.target.closest('.info-dot'))hideMetricTip()});

const systems=[
  ['Temporal Workflow Engine','26ms','up'],['EBBS CIV API','266ms','up'],['Atlas Transaction API','365ms','up'],['Email Channel (M365)','3840ms','down'],['AI Factory (LLM endpoints)','365ms','up'],
  ['Customer Profile Service','42ms','up'],['Document Intelligence','318ms','up'],['Policy Rules Engine','91ms','up'],['Notification Gateway','740ms','down'],['Case Routing Service','58ms','up'],
  ['Audit & Compliance Store','126ms','up'],['Knowledge Retrieval API','284ms','up']
];
let analysisMode='case';
let systemExpanded=false;
let caseExpanded=false;
function renderSystemCards(){
  const visible=systemExpanded?systems:systems.slice(0,5);
  kpiGrid.className='kpi-grid system-grid';
  kpiGrid.innerHTML=visible.map(([name,latency,status],index)=>`<article class="system-card" data-system-index="${index}" style="animation-delay:${Math.min(index,7)*.035}s"><h3>${name}</h3><strong>${latency}</strong><span class="system-status ${status}">${status==='up'?'Up':'Down'}</span></article>`).join('');
}
renderCaseKpis();

const statuses=[
  {color:'#209400',label:'Completed',value:92,percent:'63.4%'},
  {color:'#078CAF',label:'Sent to client',value:20,percent:'13.8%'},
  {color:'#C77D00',label:'Pending approval',value:15,percent:'10.3%'},
  {color:'#F4A909',label:'Pending manual resolution',value:12,percent:'8.3%'},
  {color:'#B4232D',label:'Rejected',value:3,percent:'2.1%'},
  {color:'#E3232C',label:'Escalated',value:2,percent:'1.4%'},
  {color:'#EF6670',label:'Expired',value:1,percent:'0.7%'}
];
const statusLegend=document.querySelector('#statusLegend');
const statusCaseTotal=statuses.reduce((total,item)=>total+item.value,0);
document.querySelector('#statusTotal').textContent=statusCaseTotal.toLocaleString();
statusLegend.innerHTML=statuses.map(item=>`
  <li class="status-legend-item status-bar-row" role="link" tabindex="0" data-case-category="${item.label==='Completed'?'Resolved':item.label}">
    <span>${item.label} <span class="status-case-count">(<span class="numeric-value">${item.value.toLocaleString()}</span> out of <span class="numeric-value">${statusCaseTotal.toLocaleString()}</span> cases)</span></span><b>${item.percent}</b>
    <span class="status-bar-track" aria-hidden="true"><i style="--status-color:${item.color};--status-share:${item.percent}"></i></span>
  </li>`).join('');
function renderInteractiveDonut(svgSelector,tooltipSelector,items,segmentClass,{navigate=true,showCount=true}={}){
  const svg=document.querySelector(svgSelector);
  const tooltip=document.querySelector(tooltipSelector);
  const values=items.map(item=>item.value);
  const sum=values.reduce((total,value)=>total+value,0);
  let offset=0;
  svg.innerHTML=`<g transform="rotate(-90 110 110)">${items.map((item,index)=>{
    const length=values[index]/sum*100;
    const detail=showCount?`${item.value} cases · ${item.percent}`:item.percent;
    const circle=`<circle class="${segmentClass}" cx="110" cy="110" r="90" pathLength="100" fill="none" stroke="${item.color}" stroke-width="36" stroke-dasharray="${length} ${100-length}" stroke-dashoffset="${-offset}" data-label="${item.label}" data-value="${detail}" data-category="${item.label}" role="${navigate?'link':'img'}" tabindex="0" aria-label="${item.label}: ${detail}"/>`;
    offset+=length;
    return circle;
  }).join('')}</g>`;
  svg.querySelectorAll(`.${segmentClass}`).forEach(segment=>{
    segment.addEventListener('pointerenter',()=>{tooltip.innerHTML=`<strong>${segment.dataset.label}</strong><span>${segment.dataset.value}</span>`;tooltip.hidden=false});
    segment.addEventListener('pointermove',event=>{const box=svg.getBoundingClientRect();tooltip.style.left=`${event.clientX-box.left+10}px`;tooltip.style.top=`${event.clientY-box.top-34}px`});
    segment.addEventListener('pointerleave',()=>tooltip.hidden=true);
    segment.addEventListener('focus',()=>{tooltip.innerHTML=`<strong>${segment.dataset.label}</strong><span>${segment.dataset.value}</span>`;tooltip.style.left='95px';tooltip.style.top='32px';tooltip.hidden=false});
    segment.addEventListener('blur',()=>tooltip.hidden=true);
    if(!navigate)return;
    segment.addEventListener('click',()=>openCasebox(segment.dataset.category));
    segment.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();openCasebox(segment.dataset.category)}});
  });
}
statusLegend.addEventListener('click',event=>{const item=event.target.closest('[data-case-category]');if(item)openCasebox(item.dataset.caseCategory)});
statusLegend.addEventListener('keydown',event=>{const item=event.target.closest('[data-case-category]');if(item&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openCasebox(item.dataset.caseCategory)}});

function renderDeliveryGauge(){
  const svg=document.querySelector('#deliveryGauge');
  const percentLabel=document.querySelector('#deliveryPercent');
  const successRate=100*125/127;
  const arc='M 32.06 155 A 90 90 0 1 1 187.94 155';
  svg.innerHTML=`<path class="delivery-arc-track" d="${arc}"/><path class="delivery-arc-progress" d="${arc}" pathLength="100" stroke-dasharray="0 100"/>`;
  const fill=svg.querySelector('.delivery-arc-progress');
  const paint=rate=>{
    fill.setAttribute('stroke-dasharray',`${rate} 100`);
    percentLabel.textContent=`${rate.toFixed(1)}%`;
  };
  if(matchMedia('(prefers-reduced-motion: reduce)').matches){paint(successRate);return}
  const start=performance.now();
  const animate=now=>{
    const progress=Math.min(1,(now-start)/1100);
    paint(successRate*(1-Math.pow(1-progress,3)));
    if(progress<1)requestAnimationFrame(animate);
  };
  requestAnimationFrame(animate);
}
renderDeliveryGauge();

const approvals=[
  ['FSS-2026-9','Confirm the cancellation',1442],
  ['FSS-2026-8','Review policy exception',1420],
  ['FSS-2026-7','Approve manual resolution',1458],
  ['FSS-2026-6','Redirect to a human',1380],
  ['FSS-2026-5','Verify client response',1320],
  ['FSS-2026-4','Confirm the cancellation',1500],
  ['FSS-2026-3','Asked for more information',1200],
  ['FSS-2026-2','Approve deadline extension',1560],
  ['FSS-2026-1','Escalate compliance review',1620]
];
const approvalSlaMs=24*60*60*1000;
const approvalSnapshotTime=Date.now();
const approvalQueuedAt=waitingMinutes=>approvalSnapshotTime-waitingMinutes*60000;
const approvalDeadline=waitingMinutes=>approvalQueuedAt(waitingMinutes)+approvalSlaMs;
const exceedsApprovalSla=approval=>Date.now()>approvalDeadline(approval[2]);
const approvalStatus=waitingMinutes=>{
  const elapsed=Math.floor((Date.now()-approvalDeadline(waitingMinutes))/60000);
  if(elapsed<0)return `Waiting for ${Math.floor(waitingMinutes/60)} hr`;
  return elapsed>=60?`Overdue by ${Math.floor(elapsed/60)} hr`:`Overdue by ${elapsed} min`;
};
const approvalAttention=document.querySelector('#approvalAttention');
const approvalList=document.querySelector('#approvalList');
function renderApprovalList(){
  const cancellation=caseSamples.find(item=>item.id===cancellationCaseId);
  const waitingMinutes=Math.max(0,Math.floor((approvalSnapshotTime-cancellationEmailDate)/60000));
  const entries=caseListGroups['Pending actions'].includes(cancellation.status)
    ?[[cancellationCaseId,cancellation.title,waitingMinutes],...approvals]:approvals;
  const overdueCount=entries.filter(exceedsApprovalSla).length;
  approvalAttention.hidden=overdueCount===0;
  approvalAttention.querySelector('span').textContent=`${overdueCount} approvals have been waiting for more than 24 hours.`;
  approvalList.innerHTML=entries.map(a=>`<div class="approval-row${exceedsApprovalSla(a)?' is-overdue':''}" role="link" tabindex="0" data-case-category="${a[0]}" aria-label="Open ${a[0]} in Case box"><span>${a[0]}</span><strong>${safeEmailPreview(a[1])}</strong><small>${approvalStatus(a[2])}</small><b><img src="Icon/arrow chevron nav right forward.svg" alt=""></b></div>`).join('');
}
function openApproval(id){
  if(id===cancellationCaseId){openCasebox(id);return}
  showUnavailableCase();
}
approvalList.addEventListener('click',event=>{const row=event.target.closest('.approval-row');if(row)openApproval(row.dataset.caseCategory)});
approvalList.addEventListener('keydown',event=>{const row=event.target.closest('.approval-row');if(row&&(event.key==='Enter'||event.key===' ')){event.preventDefault();openApproval(row.dataset.caseCategory)}});

const rows=[
  {label:'Confirmed cancellation',volume:20,delivered:[12,20],average:'6m',sent:12,pending:6,rejected:2,sla:1},
  {label:'Asked for more information',volume:4,delivered:[3,4],average:'9m',sent:3,pending:1,rejected:0,sla:1},
  {label:'Asked ops to cancel',volume:4,delivered:[3,4],average:'12m',sent:3,pending:0,rejected:1,sla:0},
  {label:'Case closure notify',volume:1,delivered:[1,1],average:'2m',sent:1,pending:0,rejected:0,sla:0},
  {label:'Asked for human intervention',volume:18,delivered:[4,18],average:'39.4h',sent:4,pending:12,rejected:2,sla:8}
];

const responseColors=[
  '#0473EA',
  '#38D200',
  '#35DF93',
  '#078CAF',
  '#10BEE8'
];
function renderAgentResponses(days=7){
  const factor=days===7?1:days===30?3.4:9.1;
  const scaled=value=>Math.round(value*factor);
  const result=rows.map(row=>({
    ...row,sent:scaled(row.sent),pending:scaled(row.pending),rejected:scaled(row.rejected)
  }));
  const responseTypes=result.map((row,index)=>({
    label:row.label,value:row.sent+row.pending+row.rejected,color:responseColors[index]
  }));
  const total=responseTypes.reduce((sum,item)=>sum+item.value,0);
  const share=item=>(item.value/total*100).toLocaleString('en',{maximumFractionDigits:1});
  document.querySelector('#agentResponseTotal').textContent=total.toLocaleString();
  document.querySelector('#responseLegend').innerHTML=responseTypes.map(item=>`<li role="link" tabindex="0" data-overview-destination="${item.label}"><i class="dot" style="--dot:${item.color}"></i><span>${item.label}</span><b>${share(item)}%</b></li>`).join('');
  document.querySelector('#responseRows').innerHTML=result.map((r,i)=>{
    const deliveryTotal=responseTypes[i].value;
    const delivered=scaled(r.delivered[0]);
    const progress=deliveryTotal?delivered/deliveryTotal*100:0;
    const rate=r.sent/deliveryTotal*100;
    const rateClass=rate>=90?'good':rate>=50?'warn':'neutral';
    return `<tr><td><a class="response-type-cell" href="#caseboxView" data-overview-destination="${r.label}"><i class="response-type-dot" style="--response-color:${responseTypes[i].color}"></i><span>${r.label}</span></a></td><td>${scaled(r.volume)}</td><td><i class="tiny-bar" style="--progress:${progress}%"></i><span class="tone-blue">${delivered}/${deliveryTotal}</span></td><td><span class="rate rate-${rateClass}">${rate.toFixed(1)}%</span></td><td>${r.average}</td><td>${scaled(r.sent)}</td><td>${scaled(r.pending)}</td><td>${scaled(r.rejected)}</td><td>${scaled(r.sla)}</td></tr>`;
  }).join('');
  const sum=responseTypes.reduce((n,item)=>n+item.value,0);
  let offset=0;
  const circles=responseTypes.map(item=>{
    const length=item.value/sum*100;
    const circle=`<circle class="agent-segment" role="link" tabindex="0" aria-label="${item.label}, ${share(item)} percent" data-overview-destination="${item.label}" cx="110" cy="110" r="90" pathLength="100" fill="none" stroke="${item.color}" stroke-width="36" stroke-dasharray="${length} ${100-length}" stroke-dashoffset="${-offset}" data-label="${item.label}" data-value="${share(item)}%"/>`;
    offset+=length;
    return circle;
  }).join('');
  const svg=document.querySelector('#agentResponseDonut');
  svg.innerHTML=`<g transform="rotate(-90 110 110)">${circles}</g>`;
  const tooltip=document.querySelector('#agentChartTooltip');
  svg.querySelectorAll('.agent-segment').forEach(segment=>{
    segment.addEventListener('pointerenter',()=>{tooltip.innerHTML=`<strong>${segment.dataset.label}</strong><span>${segment.dataset.value}</span>`;tooltip.hidden=false});
    segment.addEventListener('pointermove',event=>{const box=svg.getBoundingClientRect();tooltip.style.left=`${event.clientX-box.left+10}px`;tooltip.style.top=`${event.clientY-box.top-34}px`});
    segment.addEventListener('pointerleave',()=>tooltip.hidden=true);
  });
}

const activityDateFormat=new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'short'});
const emailTimeFormat=new Intl.DateTimeFormat('en-GB',{hour:'2-digit',minute:'2-digit'});
const fullActivityDateFormat=new Intl.DateTimeFormat('en-GB',{day:'numeric',month:'short',year:'numeric'});
const caseUpdatedTimeFormat=new Intl.DateTimeFormat('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
function localDayOffset(today,offset){
  return new Date(today.getFullYear(),today.getMonth(),today.getDate()+offset,12);
}
function activitySeries(days,today=new Date()){
  const dates=Array.from({length:days},(_,index)=>localDayOffset(today,index-days+1));
  const sampleDay=date=>Date.UTC(date.getFullYear(),date.getMonth(),date.getDate())/86400000;
  const received=dates.map((date,index)=>{
    if(index===days-1)return Number(kpis[0].value);
    if(index===days-2)return 108;
    const day=sampleDay(date);
    return Math.round(109+8*Math.sin(day*.19)+3*Math.sin(day*.49));
  });
  const sent=dates.map((date,index)=>{
    if(index===days-1)return Number(kpis[1].value);
    if(index===days-2)return 22;
    const day=sampleDay(date);
    return Math.round(24+4*Math.sin(day*.21+.7)+2*Math.sin(day*.46));
  });
  return {dates,labels:dates.map(date=>activityDateFormat.format(date)),received,sent};
}
let currentActivityDays=30;
let selectedActivityIndex=null;
function renderActivityChart(days=30){
  if(days!==currentActivityDays)selectedActivityIndex=null;
  currentActivityDays=days;
  const data=activitySeries(days);
  const svg=document.querySelector('#activityChart');
  const width=Math.max(1,Math.round(svg.clientWidth||720));
  const height=Math.max(220,Math.round(svg.clientHeight||260));
  svg.setAttribute('viewBox',`0 0 ${width} ${height}`);
  const left=36,right=16,top=18,bottom=42,max=Math.max(...data.sent,...data.received)+2;
  const x=i=>left+i*(width-left-right)/(data.labels.length-1);
  const y=v=>top+(max-v)*(height-top-bottom)/max;
  const points=values=>values.map((v,i)=>`${x(i)},${y(v)}`).join(' ');
  const grids=[0,.25,.5,.75,1].map(n=>{const gy=top+n*(height-top-bottom);return `<line x1="${left}" y1="${gy}" x2="${width-right}" y2="${gy}"/><text x="4" y="${gy+4}">${Math.round(max*(1-n))}</text>`}).join('');
  const tickCount=Math.min(data.labels.length,Math.max(2,Math.floor((width-left-right)/65)+1));
  const tickIndices=new Set(Array.from({length:tickCount},(_,i)=>Math.round(i*(data.labels.length-1)/(tickCount-1))));
  const labels=data.labels.map((label,i)=>tickIndices.has(i)?`<text class="x-label" x="${x(i)}" y="${height-12}">${label}</text>`:'').join('');
  svg.innerHTML=`<g class="chart-grid">${grids}</g>${labels}<polyline class="sent-line" points="${points(data.sent)}" fill="none" stroke="#35DF93" stroke-width="2.25" stroke-linejoin="round" stroke-linecap="round"/><polyline class="received-line" points="${points(data.received)}" fill="none" stroke="#0473EA" stroke-width="2.25" stroke-linejoin="round" stroke-linecap="round"/><line class="activity-guide" x1="${left}" y1="${top}" x2="${left}" y2="${height-bottom}" hidden/><circle class="activity-focus-point sent" r="4.5" hidden/><circle class="activity-focus-point received" r="4.5" hidden/><rect class="activity-overlay" x="${left}" y="${top}" width="${width-left-right}" height="${height-top-bottom}"/>`;
  const tooltip=document.querySelector('#activityTooltip');
  const guide=svg.querySelector('.activity-guide');
  const sentPoint=svg.querySelector('.activity-focus-point.sent');
  const receivedPoint=svg.querySelector('.activity-focus-point.received');
  const overlay=svg.querySelector('.activity-overlay');
  const setVisible=(element,visible)=>visible?element.removeAttribute('hidden'):element.setAttribute('hidden','');
  const showIndex=index=>{
    const i=Math.max(0,Math.min(data.labels.length-1,index));
    const gx=x(i);
    guide.setAttribute('x1',gx);guide.setAttribute('x2',gx);setVisible(guide,true);
    sentPoint.setAttribute('cx',gx);sentPoint.setAttribute('cy',y(data.sent[i]));setVisible(sentPoint,true);
    receivedPoint.setAttribute('cx',gx);receivedPoint.setAttribute('cy',y(data.received[i]));setVisible(receivedPoint,true);
    tooltip.innerHTML=`<strong>${fullActivityDateFormat.format(data.dates[i])}</strong><span>${data.received[i]} received</span><span>${data.sent[i]} sent</span>`;
    const box=svg.getBoundingClientRect();
    const screenX=gx/width*box.width;
    tooltip.style.left=`${Math.min(Math.max(screenX+10,4),box.width-130)}px`;
    tooltip.style.top=`${Math.max(top/height*box.height+8,4)}px`;
    tooltip.hidden=false;
  };
  const indexFromPointer=event=>{
    const box=svg.getBoundingClientRect();
    const svgX=(event.clientX-box.left)/box.width*width;
    return Math.round((svgX-left)/(width-left-right)*(data.labels.length-1));
  };
  overlay.addEventListener('pointermove',event=>showIndex(indexFromPointer(event)));
  overlay.addEventListener('pointerleave',()=>{
    if(selectedActivityIndex===null){setVisible(guide,false);setVisible(sentPoint,false);setVisible(receivedPoint,false);tooltip.hidden=true}
    else showIndex(selectedActivityIndex);
  });
  overlay.addEventListener('click',event=>{selectedActivityIndex=Math.max(0,Math.min(data.labels.length-1,indexFromPointer(event)));showIndex(selectedActivityIndex)});
  if(selectedActivityIndex!==null)showIndex(selectedActivityIndex);
}
function setupPeriodMenu(id,onChange,parseValue=Number){
  const root=document.querySelector(`#${id}`);
  const trigger=root.firstElementChild;
  const label=trigger.querySelector('span');
  const options=root.querySelector('.analysis-options');
  const close=()=>{options.hidden=true;trigger.setAttribute('aria-expanded','false')};
  const select=value=>{
    root.dataset.value=value;
    options.querySelectorAll('[data-value]').forEach(item=>{
      const selected=item.dataset.value===value;
      item.setAttribute('aria-checked',String(selected));
      if(selected)label.textContent=item.querySelector('span').textContent;
    });
  };
  trigger.addEventListener('click',event=>{
    event.stopPropagation();
    const open=options.hidden;
    document.querySelectorAll('.period-menu .analysis-options').forEach(menu=>menu.hidden=true);
    options.hidden=!open;
    trigger.setAttribute('aria-expanded',String(open));
  });
  options.addEventListener('click',event=>{
    const option=event.target.closest('[data-value]');
    if(!option)return;
    select(option.dataset.value);
    close();
    onChange(parseValue(option.dataset.value));
    trigger.focus();
  });
  document.addEventListener('click',event=>{if(!root.contains(event.target))close()});
  root.addEventListener('keydown',event=>{if(event.key==='Escape'&&!options.hidden){close();trigger.focus()}});
  return select;
}
setupPeriodMenu('activityRange',renderActivityChart);
setupPeriodMenu('responseRange',renderAgentResponses);
let pendingDiagnosticsDays=7;
setupPeriodMenu('diagnosticsRange',days=>{pendingDiagnosticsDays=days});
renderActivityChart(30);
renderAgentResponses(7);
const dispatchInfo=document.querySelector('.dispatch-info');
dispatchInfo.addEventListener('pointerenter',()=>showMetricTip(dispatchInfo));
dispatchInfo.addEventListener('pointerleave',hideMetricTip);
dispatchInfo.addEventListener('focus',()=>showMetricTip(dispatchInfo));
dispatchInfo.addEventListener('blur',hideMetricTip);
dispatchInfo.addEventListener('click',event=>{event.stopPropagation();showMetricTip(dispatchInfo)});
let activityResizeFrame;
window.addEventListener('resize',()=>{
  cancelAnimationFrame(activityResizeFrame);
  activityResizeFrame=requestAnimationFrame(()=>renderActivityChart(currentActivityDays));
});

document.querySelectorAll('a,button').forEach(el=>el.addEventListener('click',e=>{if(el.getAttribute('href')==='#')e.preventDefault()}));

const analysisMenu=document.querySelector('#analysisMenu');
const analysisMenuButton=document.querySelector('#analysisMenuButton');
const analysisMenuLabel=document.querySelector('#analysisMenuLabel');
const analysisOptions=document.querySelector('#analysisOptions');
const caseAction=document.querySelector('#caseAction');
const systemAction=document.querySelector('#systemAction');
const metricToggle=document.querySelector('#metricToggle');
const refreshSystems=document.querySelector('#refreshSystems');
const refreshTime=document.querySelector('#refreshTime');
let systemLastUpdated=Date.now();
let systemRefreshInFlight=false;

function updateRefreshLabel(){
  const seconds=Math.max(0,Math.floor((Date.now()-systemLastUpdated)/1000));
  refreshTime.textContent=seconds<5?'just now':seconds<60?`${seconds}s ago`:`${Math.floor(seconds/60)} min${seconds<120?'':'s'} ago`;
}

function updateSystemMetrics({allowStatusChange=true}={}){
  systems.forEach((system,index)=>{
    const current=Math.max(1,Number.parseInt(system[1],10)||50);
    const volatility=current>1000?.055:current>300?.08:.12;
    const next=Math.max(8,Math.round(current*(1+(Math.random()-.5)*volatility)));
    system[1]=`${next}ms`;
    if(allowStatusChange){
      if(system[2]==='down'&&Math.random()<.08)system[2]='up';
      else if(system[2]==='up'&&Math.random()<.012)system[2]='down';
    }
    const card=kpiGrid.querySelector(`[data-system-index="${index}"]`);
    if(!card)return;
    const value=card.querySelector('strong');
    const status=card.querySelector('.system-status');
    value.textContent=system[1];
    value.classList.remove('system-value-updated');
    void value.offsetWidth;
    value.classList.add('system-value-updated');
    status.className=`system-status ${system[2]}`;
    status.textContent=system[2]==='up'?'Up':'Down';
  });
  systemLastUpdated=Date.now();
  updateRefreshLabel();
}

const emailMetricDestinations={
  'Email received':'inbox',
  'Email sent':'sent',
  Bounced:'bounced'
};
let caseDetailReturn;
function openCasebox(category='all',view=category==='all'||Object.hasOwn(emailMetricDestinations,category)?'casebox':'cases'){
  const openingCase=view==='cases'&&caseSamples.some(item=>item.id===category);
  const source=caseboxView.hidden
    ? {page:diagnosticsView.hidden?'overview':'diagnostics'}
    : caseViewMode==='casebox'
      ? {page:'casebox'}
      : {page:'cases',useCurrentList:true};
  if(embeddedMode&&parent!==window){
    parent.postMessage({type:'intellibox:navigate',page:view,category},location.origin);
    return;
  }
  if(openingCase){
    caseDetailReturn=source.page==='cases'&&!casesWorkspace.hidden?{page:'cases'}:source;
  }
  caseboxView.dataset.category=category;
  selectGlobalPage('casebox');
  openCaseWorkspaceDestination(view,category);
}
function openCaseWorkspaceDestination(view,category){
  const destination=view==='casebox'&&Object.hasOwn(emailMetricDestinations,category)?emailMetricDestinations[category]:null;
  const originalEmailId=view==='casebox'&&category?.startsWith('mail:')?category.slice(5):null;
  setupCaseWorkspace(view,destination||originalEmailId?undefined:category,destination||undefined);
  if(originalEmailId)selectOriginalCaseEmail(originalEmailId);
}
const overview=document.getElementById('dashboardView');
overview.addEventListener('click',event=>{
  const link=event.target.closest('[data-overview-destination]');
  if(!link)return;
  event.preventDefault();
  openCasebox(link.dataset.overviewDestination);
});
overview.addEventListener('keydown',event=>{
  const link=event.target.closest('[data-overview-destination][role="link"]');
  if(!link||(event.key!=='Enter'&&event.key!==' '))return;
  event.preventDefault();
  openCasebox(link.dataset.overviewDestination);
});
document.querySelectorAll('[data-delivery-destination]').forEach(link=>{
  link.addEventListener('click',event=>{
    event.preventDefault();
    openCasebox(link.dataset.deliveryDestination);
  });
});

caseAction.querySelector('a').addEventListener('click',event=>{
  event.preventDefault();
  openCasebox('all','cases');
});

function syncMetricToggle(){
  const expanded=analysisMode==='system'?systemExpanded:caseExpanded;
  metricToggle.classList.toggle('expanded',expanded);
  metricToggle.setAttribute('aria-expanded',String(expanded));
  metricToggle.setAttribute('aria-label',analysisMode==='system'?(systemExpanded?'Show fewer systems':'Show more systems'):(caseExpanded?'Show summary metrics':'Show detailed metrics'));
}

function selectAnalysisMode(mode){
  analysisMode=mode;
  analysisMenuLabel.textContent=mode==='system'?'System analysis':'Case analysis';
  analysisOptions.querySelectorAll('[data-mode]').forEach(option=>option.setAttribute('aria-checked',String(option.dataset.mode===mode)));
  analysisOptions.hidden=true;
  analysisMenuButton.setAttribute('aria-expanded','false');
  caseAction.hidden=analysisMode!=='case';
  systemAction.hidden=analysisMode!=='system';
  kpiGrid.hidden=false;
  caseExpanded=false;
  systemExpanded=false;
  if(analysisMode==='system')renderSystemCards();else renderCaseKpis();
  syncMetricToggle();
}

analysisMenuButton.addEventListener('click',()=>{
  const opening=analysisOptions.hidden;
  analysisOptions.hidden=!opening;
  analysisMenuButton.setAttribute('aria-expanded',String(opening));
  if(opening)analysisOptions.querySelector(`[data-mode="${analysisMode}"]`).focus();
});
analysisOptions.addEventListener('click',event=>{
  const option=event.target.closest('[data-mode]');
  if(option)selectAnalysisMode(option.dataset.mode);
});
analysisMenu.addEventListener('keydown',event=>{
  const options=[...analysisOptions.querySelectorAll('[data-mode]')];
  const index=options.indexOf(document.activeElement);
  if(event.key==='Escape'){
    analysisOptions.hidden=true;
    analysisMenuButton.setAttribute('aria-expanded','false');
    analysisMenuButton.focus();
  }else if(!analysisOptions.hidden&&(event.key==='ArrowDown'||event.key==='ArrowUp')){
    event.preventDefault();
    const direction=event.key==='ArrowDown'?1:-1;
    options[(index+direction+options.length)%options.length].focus();
  }else if(!analysisOptions.hidden&&(event.key==='Enter'||event.key===' ')){
    const option=event.target.closest('[data-mode]');
    if(option){event.preventDefault();selectAnalysisMode(option.dataset.mode)}
  }
});
document.addEventListener('click',event=>{
  if(!analysisMenu.contains(event.target)){
    analysisOptions.hidden=true;
    analysisMenuButton.setAttribute('aria-expanded','false');
  }
});

let metricTransitionTimer;
function finishMetricTransition(){
  clearTimeout(metricTransitionTimer);
  kpiGrid.style.height='';
  kpiGrid.style.overflow='';
  kpiGrid.classList.remove('metric-grid-animating');
  metricToggle.disabled=false;
}
function animateMetricCards(expanding,render,baseCount){
  if(matchMedia('(prefers-reduced-motion: reduce)').matches){render();return}
  clearTimeout(metricTransitionTimer);
  metricToggle.disabled=true;
  const oldHeight=kpiGrid.getBoundingClientRect().height;
  const animateHeight=newHeight=>{
    kpiGrid.style.height=`${oldHeight}px`;
    kpiGrid.style.overflow='hidden';
    kpiGrid.classList.add('metric-grid-animating');
    void kpiGrid.offsetHeight;
    requestAnimationFrame(()=>{kpiGrid.style.height=`${newHeight}px`});
  };
  if(expanding){
    render();
    const cards=[...kpiGrid.querySelectorAll('.kpi-card,.system-card')];
    const enteringCards=cards.slice(baseCount);
    const newHeight=kpiGrid.getBoundingClientRect().height;
    animateHeight(newHeight);
    enteringCards.forEach((card,index)=>{
      card.classList.add('metric-card-enter');
      card.style.setProperty('--metric-delay',`${index*48}ms`);
    });
    metricTransitionTimer=setTimeout(finishMetricTransition,Math.max(460,enteringCards.length*48+300));
    return;
  }
  const extra=[...kpiGrid.querySelectorAll('.kpi-card,.system-card')].slice(baseCount);
  extra.forEach(card=>card.remove());
  let enteringCards=[];
  if(analysisMode==='case'){
    kpiGrid.classList.remove('case-expanded');
    kpiGrid.classList.add('case-summary');
    kpiGrid.insertAdjacentHTML('beforeend',caseCardMarkup(kpis[4],3)+caseCardMarkup(kpis[5],4));
    enteringCards=[...kpiGrid.querySelectorAll('.kpi-card')].slice(3);
    enteringCards.forEach((card,index)=>{
      card.classList.add('metric-card-enter');
      card.style.setProperty('--metric-delay',`${index*45}ms`);
    });
  }
  const newHeight=kpiGrid.getBoundingClientRect().height;
  animateHeight(newHeight);
  metricTransitionTimer=setTimeout(finishMetricTransition,Math.max(420,enteringCards.length*45+280));
}

metricToggle.addEventListener('click',()=>{
  if(analysisMode==='system'){
    systemExpanded=!systemExpanded;
    animateMetricCards(systemExpanded,renderSystemCards,5);
  }else{
    caseExpanded=!caseExpanded;
    animateMetricCards(caseExpanded,renderCaseKpis,3);
  }
  syncMetricToggle();
});

refreshSystems.addEventListener('click',()=>{
  if(systemRefreshInFlight)return;
  systemRefreshInFlight=true;
  refreshSystems.classList.add('refreshing');
  refreshSystems.disabled=true;
  kpiGrid.classList.add('is-loading');
  kpiGrid.setAttribute('aria-busy','true');
  setTimeout(()=>{
    updateSystemMetrics();
    kpiGrid.classList.remove('is-loading');
    kpiGrid.removeAttribute('aria-busy');
    refreshSystems.classList.remove('refreshing');
    refreshSystems.disabled=false;
    systemRefreshInFlight=false;
  },900+Math.round(Math.random()*500));
});

updateRefreshLabel();
setInterval(updateRefreshLabel,1000);
let lastActivityDay=localDayOffset(new Date(),0).getTime();
setInterval(()=>{
  const today=localDayOffset(new Date(),0).getTime();
  if(today===lastActivityDay)return;
  lastActivityDay=today;
  selectedActivityIndex=null;
  renderActivityChart(currentActivityDays);
},30000);
setInterval(()=>{
  if(analysisMode==='system'&&!systemRefreshInFlight)updateSystemMetrics();
},7000);

const diagnosticData=[
  {icon:'Icon/flash lighting bolt filled.svg',value:'128',empty:'0',label:'cases analysed',change:'↑12% vs previous period',tone:'neutral',color:'#0473EA',tint:'#EAF4FF',path:'M0 56 L22 30 L42 43 L62 34 L88 10 L110 18 L128 2 L145 14'},
  {icon:'Icon/alert triangle ! exclamation filled.svg',value:'28',empty:'–',label:'SLA breaches',change:'↓5% vs previous period',tone:'positive',color:'#E3232C',tint:'#FDE9EA',path:'M0 27 L25 18 L52 14 L78 6 L95 48 L116 58 L135 50 L145 56'},
  {icon:'Icon/timer clock filled.svg',value:'12m 40s',empty:'–',label:'average duration',change:'↓18% vs previous period',tone:'positive',color:'#0473EA',tint:'#EAF4FF',path:'M0 5 L14 22 L38 25 L58 34 L72 10 L86 5 L104 40 L117 69 L130 66 L145 82'},
  {icon:'Icon/user profile person filled.svg',value:'18.7%',empty:'–',label:'human intervention',change:'↑13% vs previous period',tone:'warning',color:'#C77D00',tint:'#FFF5DF',path:'M0 62 L24 56 L50 54 L68 45 L86 27 L104 34 L124 17 L145 0'}
];
const diagnosticKpis=document.querySelector('#diagnosticKpis');
diagnosticKpis.innerHTML=diagnosticData.map((item,index)=>`<article class="diagnostic-kpi" style="--color:${item.color};--tint:${item.tint}"><div class="diag-kpi-copy"><strong data-empty="${item.empty}" data-value="${item.value}">${item.empty}</strong><span>${item.label}</span><small class="diag-change" data-value="${item.change}">– vs previous period</small></div><svg class="diag-spark" viewBox="0 0 145 84" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="diagGradient${index}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${item.color}" stop-opacity=".22"/><stop offset=".68" stop-color="${item.color}" stop-opacity=".05"/><stop offset="1" stop-color="${item.color}" stop-opacity="0"/></linearGradient></defs><path class="diag-fill" d="M0 64 L145 64 L145 84 L0 84 Z" fill="url(#diagGradient${index})"/><path class="line" d="M0 64 L145 64" data-loaded-path="${smoothSparkline(item.path.replace(/^M/,'').replaceAll(' L',' ').replace(/(\d+) (\d+)/g,'$1,$2')).path}"/></svg></article>`).join('');

const stageTimeData=[
  {stage:'Intake & de-duplication',owner:'Agent',cases:128,p50:'12s',p90:'28s',share:3,tone:'normal'},
  {stage:'Classify & extract',owner:'Agent',cases:128,p50:'34s',p90:'1m 12s',share:7,tone:'normal'},
  {stage:'Policy & identity checks',owner:'Agent',cases:116,p50:'48s',p90:'2m 10s',share:9,tone:'normal'},
  {stage:'Order status lookup',owner:'Agent',cases:104,p50:'22s',p90:'58s',share:5,tone:'normal'},
  {stage:'Cancellation execution',owner:'Agent',cases:92,p50:'38s',p90:'1m 46s',share:8,tone:'normal'},
  {stage:'Draft the reply',owner:'Agent',cases:104,p50:'46s',p90:'2m 05s',share:9,tone:'normal'},
  {stage:'Waiting for human review',owner:'Client service team',cases:32,p50:'4m 20s',p90:'18m 40s',share:54,tone:'warning'},
  {stage:'Send to client',owner:'Email service',cases:102,p50:'18s',p90:'1m 30s',share:5,tone:'normal'}
];
const stageTimeRows=document.querySelector('#stageTimeRows');
// Demo step outcomes. Columns after the name: reached, held, errors, skipped, pending, P50, P90.
const caseStopSteps=[
  ['Check incoming message',128,0,0,0,0,'2s','5s'],
  ['Check for duplicates',128,0,0,4,0,'4s','9s'],
  ['Identify the request type',124,0,0,0,0,'18s','40s'],
  ['Create the case',124,0,1,0,0,'5s','12s'],
  ['Link the email to the case',123,0,0,0,0,'3s','8s'],
  ['Check the sender’s email domain',123,2,0,0,0,'3s','8s'],
  ['Check if the team can handle the request',121,3,0,0,0,'7s','18s'],
  ['Check for missing information',118,10,0,0,2,'18s','48s'],
  ['Verify the customer’s identity',106,2,1,0,1,'25s','1m 8s'],
  ['Look up the order status',102,0,2,0,1,'22s','58s'],
  ['Cancel the order',99,0,1,10,0,'38s','1m 46s'],
  ['Notify the operations team',88,0,0,0,0,'5s','14s'],
  ['Draft the reply',98,0,0,0,0,'46s','2m 5s'],
  ['Queue the reply for approval',32,0,0,0,7,'4m 20s','18m 40s'],
  ['Send to the team for manual processing',0,0,0,0,0,'—','—']
];

function renderCaseStops(days,factor){

  const steps=caseStopSteps.map(([name,reached,held,errors,skipped,pending,typical,slow])=>{
    const count=value=>Math.round(value*factor);
    const entered=count(reached);
    const stopped=count(held)+count(errors);
    return {
      name,entered,stopped,typical,slow,
      held:count(held),errors:count(errors),skipped:count(skipped),pending:count(pending),
      passed:entered-stopped-count(skipped)-count(pending),
      share:entered?`${(100*stopped/entered).toFixed(1)}%`:'—'
    };
  });
  const notable=steps.filter(step=>step.stopped>0);
  const reachedSteps=steps.filter(step=>step.entered>0).length;
  document.querySelector('#caseStopsSummary').textContent=
    `Sample data: ${steps[0].entered.toLocaleString()} cases reached at least one step. Cases were held up or had an error at ${notable.length} of ${reachedSteps} steps they reached.`;
  const row=(step,full)=>{
    const counts=full
      ? [step.entered,step.passed,step.held,step.errors,step.skipped,step.pending,step.share,step.typical,step.slow]
      : [step.entered,step.held,step.errors,step.share];
    return `<tr><th scope="row">${step.name}${step.entered?'':'<small>Not reached</small>'}</th>${counts.map(value=>`<td>${value.toLocaleString()}</td>`).join('')}</tr>`;
  };
  document.querySelector('#caseStopsHighlights').innerHTML=notable.map(step=>row(step,false)).join('');
  document.querySelector('#caseStopsAll').innerHTML=steps.map(step=>row(step,true)).join('');
}

function renderStageTime(days,factor){
  renderCaseStops(days,factor);
  const summary=days===7?['8m 24s','32m 10s']:days===30?['9m 02s','35m 40s']:['9m 48s','41m 12s'];
  document.querySelector('#stageTypical').textContent=summary[0];
  document.querySelector('#stageSlow').textContent=summary[1];
  document.querySelector('#stageMedianNote').textContent=`Median across ${Math.round(128*factor).toLocaleString()} cases`;
  stageTimeRows.innerHTML=stageTimeData.map(item=>`<tr class="${item.tone==='warning'?'is-bottleneck':''}"><td><strong>${item.stage}</strong></td><td>${item.owner}</td><td>${Math.round(item.cases*factor).toLocaleString()}</td><td>${item.p50}</td><td>${item.p90}</td><td><span class="stage-share"><i style="--share:${item.share}%"></i><b>${item.share}%</b></span></td></tr>`).join('');
}

document.querySelectorAll('.stage-info').forEach(info=>{
  info.addEventListener('pointerenter',()=>showMetricTip(info));
  info.addEventListener('pointerleave',hideMetricTip);
  info.addEventListener('focus',()=>showMetricTip(info));
  info.addEventListener('blur',hideMetricTip);
  info.addEventListener('click',event=>{event.stopPropagation();showMetricTip(info)});
});

const dashboardTab=document.querySelector('#dashboardTab');
const diagnosticsTab=document.querySelector('#diagnosticsTab');
const dashboardView=document.querySelector('#dashboardView');
const diagnosticsView=document.querySelector('#diagnosticsView');
const runScan=document.querySelector('#runScan');

let scanTimer;

function showView(view){
  const diagnostics=view==='diagnostics';
  dashboardView.hidden=diagnostics;
  diagnosticsView.hidden=!diagnostics;
  dashboardTab.classList.toggle('selected',!diagnostics);
  diagnosticsTab.classList.toggle('selected',diagnostics);
  dashboardTab.setAttribute('aria-selected',String(!diagnostics));
  diagnosticsTab.setAttribute('aria-selected',String(diagnostics));
  document.body.classList.toggle('dashboard-mode',!diagnostics);
  document.body.classList.toggle('diagnostics-mode',diagnostics);
  document.body.classList.remove('casebox-mode');
}
dashboardTab.addEventListener('click',()=>showView('dashboard'));
diagnosticsTab.addEventListener('click',()=>showView('diagnostics'));
document.querySelectorAll('#deliveryDetails,.delivery-detail-trigger').forEach(link=>link.addEventListener('click',event=>{
  event.preventDefault();
  if(embeddedMode&&parent!==window){
    parent.postMessage({type:'intellibox:navigate',page:'diagnostics',section:'deliverability'},location.origin);
    return;
  }
  showView('diagnostics');
  const section=document.querySelector('#deliverability');
  section.focus({preventScroll:true});
  section.scrollIntoView({block:'start'});
}));

const requestSplit=document.querySelector('#requestSplit');

const sampleRequest={Sentiment:'Neutral',Category:'Trade'};
const requestFlowDetail=document.querySelector('#requestFlowDetail');
const requestFlowButtons=document.querySelectorAll('.request-flow button');
function updateRequestFlow(){
  document.querySelector('#requestMiddle').textContent=sampleRequest[requestSplit.dataset.value];

  requestFlowDetail.hidden=true;
  requestFlowButtons.forEach(button=>button.setAttribute('aria-pressed','false'));
}

setupPeriodMenu('requestSplit',updateRequestFlow,String);

requestFlowButtons.forEach(button=>button.addEventListener('click',()=>{
  const wasSelected=button.getAttribute('aria-pressed')==='true';
  requestFlowButtons.forEach(item=>item.setAttribute('aria-pressed',String(item===button&&!wasSelected)));
  document.querySelector('#requestDetailTitle').textContent=button.querySelector('b').textContent;
  requestFlowDetail.hidden=wasSelected;
}));

const diagnosticsSkeletons=diagnosticsView.querySelectorAll(
  '.delivery-summary,.email-risk-chart,.email-risk p:last-child,.stage-time-loaded,.stage-time-empty,.case-stops-results,.case-stops-empty,.return-panel .diagnostic-overview-donut,.human-legend,.request-flow-body,.customer-panel .diagnostic-empty'
);
diagnosticsSkeletons.forEach(element=>element.classList.add('diagnostics-skeleton'));

function completeScan(days=7){
  diagnosticsView.removeAttribute('aria-busy');
  diagnosticsSkeletons.forEach(element=>element.inert=false);
  const factor=days===7?1:days===30?3.8:10.5;
  const count=value=>Math.round(value*factor);
  renderStageTime(days,factor);
  const requests=count(1);
  const requestLabel=requests===1?'request':'requests';
  document.querySelector('#requestPeriod').textContent=`${requests} ${requestLabel} in the last ${days} days`;
  document.querySelectorAll('.request-flow-count').forEach(label=>label.textContent=`100% (${requests})`);
  document.querySelector('#requestDetailCount').textContent=`${requests} of ${requests} ${requestLabel} · 100%`;
  const delivered=count(125),bounced=count(1),rejected=count(1);
  document.querySelector('#detailDelivered').textContent=delivered;
  document.querySelector('#detailBounced').textContent=bounced;
  document.querySelector('#detailRejected').textContent=rejected;
  document.querySelector('#deliverySuccessDetail').textContent=`${(100*delivered/(delivered+bounced+rejected)).toFixed(1)}%`;
  diagnosticsView.classList.remove('is-loading');
  diagnosticsView.classList.add('is-loaded');
  const values=[count(128).toLocaleString(),count(28).toLocaleString(),{7:'12m 40s',30:'13m 12s',90:'14m 05s'}[days],`${(100*count(28)/count(128)).toFixed(1)}%`];
  document.querySelectorAll('.diag-kpi-copy strong').forEach((el,index)=>el.textContent=values[index]);
  document.querySelectorAll('.diag-change').forEach((el,index)=>{el.textContent=el.dataset.value;el.classList.add(diagnosticData[index].tone)});
  document.querySelectorAll('.diag-spark .line').forEach(el=>el.setAttribute('d',el.dataset.loadedPath));
  document.querySelectorAll('.diag-fill').forEach((el,index)=>el.setAttribute('d',`${el.parentElement.querySelector('.line').dataset.loadedPath} L145 84 L0 84 Z`));
  document.querySelectorAll('.diagnostic-empty,.empty-value').forEach(el=>el.hidden=true);
  document.querySelectorAll('.diagnostic-loaded,.loaded-value').forEach(el=>el.hidden=false);
  document.querySelector('.diag-total').textContent=count(28).toLocaleString();
  {
    const kind='human';
    const items=[...document.querySelectorAll(`.${kind}-legend li`)].map(row=>{
      const percent=row.querySelector('.loaded-value').textContent;
      return {label:row.querySelector('span').textContent,color:row.querySelector('i').style.getPropertyValue('--c'),value:parseFloat(percent),percent};
    });
    renderInteractiveDonut(`#${kind}Donut`,`#${kind}Tooltip`,items,'status-segment',{navigate:false,showCount:false});
  }


  runScan.disabled=false;
  runScan.classList.remove('is-scanning');
  runScan.querySelector('.scan-label').textContent='Refresh analysis';
}

runScan.addEventListener('click',()=>{
  clearTimeout(scanTimer);
  diagnosticsView.classList.remove('is-loaded');
  diagnosticsView.classList.add('is-loading');
  diagnosticsView.setAttribute('aria-busy','true');
  diagnosticsSkeletons.forEach(element=>element.inert=true);
  runScan.disabled=true;
  runScan.classList.add('is-scanning');
  runScan.querySelector('.scan-label').textContent='Refreshing';

  const days=pendingDiagnosticsDays;
  scanTimer=setTimeout(()=>completeScan(days),1500);
});

const navDashboard=document.querySelector('#navDashboard');
const navCasebox=document.querySelector('#navCasebox');
const navAbout=document.querySelector('#navAbout');
const caseboxView=document.querySelector('#caseboxView');
const viewSwitch=document.querySelector('.view-switch');
const poweredBrand=document.querySelector('.powered');
const aboutSheet=document.querySelector('#aboutSheet');
const sheetBackdrop=document.querySelector('#sheetBackdrop');
const appSearch=document.querySelector('#appSearch');
const aboutSupplement=document.querySelector('#aboutSupplement');
const aboutScroll=document.querySelector('.sheet-scroll');
let lastFocusedElement;

function selectGlobalPage(page){
  const isDashboard=page==='dashboard';
  caseboxView.hidden=isDashboard;
  viewSwitch.hidden=!isDashboard;
  poweredBrand.hidden=!isDashboard;
  if(isDashboard){
    showView('dashboard');
  }else{
    dashboardView.hidden=true;
    diagnosticsView.hidden=true;
    document.body.classList.remove('dashboard-mode','diagnostics-mode');
    document.body.classList.add('casebox-mode');
  }
  navDashboard.classList.toggle('active',isDashboard);
  navCasebox.classList.toggle('active',!isDashboard);
}

function openAbout(){
  lastFocusedElement=document.activeElement;
  sheetBackdrop.hidden=false;
  aboutSheet.setAttribute('aria-hidden','false');
  navAbout.setAttribute('aria-expanded','true');
  document.body.classList.add('sheet-open');
  requestAnimationFrame(()=>{
    aboutSheet.classList.add('open');
    appSearch.focus();
  });
}

function closeAbout(){
  aboutSheet.classList.remove('open');
  aboutSheet.setAttribute('aria-hidden','true');
  navAbout.setAttribute('aria-expanded','false');
  document.body.classList.remove('sheet-open');
  setTimeout(()=>{sheetBackdrop.hidden=true},320);
  if(lastFocusedElement)lastFocusedElement.focus();
  if(embeddedMode&&parent!==window)parent.postMessage({type:'intellibox:about-closed'},location.origin);
}

addEventListener('message',event=>{
  if(event.origin===location.origin&&event.data?.type==='intellibox:open-about')openAbout();
});

navDashboard.addEventListener('click',()=>selectGlobalPage('dashboard'));
navCasebox.addEventListener('click',()=>openCasebox());
navAbout.addEventListener('click',openAbout);
sheetBackdrop.addEventListener('click',closeAbout);
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&aboutSheet.classList.contains('open'))closeAbout()});

appSearch.addEventListener('input',()=>{
  const query=appSearch.value.trim().toLowerCase();
  const apps=[...document.querySelectorAll('#applicationList article')];
  const searching=query.length>0;
  aboutSupplement.hidden=searching;
  aboutScroll.classList.toggle('search-results-mode',searching);
  apps.forEach(app=>app.hidden=!`${app.dataset.app} ${app.textContent}`.toLowerCase().includes(query));
  document.querySelector('#noApps').hidden=apps.some(app=>!app.hidden);
});

const caseUi={};
for(const id of ['caseQueueTitle','caseSearch','caseFilter','caseRefresh','caseQueueCount','caseboxContext','caseQueueItems','caseReaderActions','caseReply','caseLinkAction','caseArchive','caseReplyAll','caseForward','mailAiDraft','mailAiDraftBody','mailAiDraftProgress','mailAiRetry','mailAiUse','viewLinkedCase','linkedCase','caseReaderSubject','caseReaderTitle','caseReaderDate','caseReaderSender','caseClassification','caseClassificationFields','caseReaderBody','caseEmailDisclaimer','caseReaderNotice']){
  caseUi[id]=document.getElementById(id);
}
const caseStatusGroups={
  'Cases completed':['Completed'],
  'Pending actions':['Pending approval','Pending manual resolution'],
  'Exceptions':['Rejected','Escalated','Expired']
};
const inboxSamples=[
  ['Alex Morgan','Trade order cancellation request','Please cancel trade order 1036574 as soon as possible.','New','FSS-2026-28','High'],
  ['Jamie Chen','Please check my order','Could you confirm whether order 1036574 is still open?','Replied','','Normal'],
  ['Taylor Wong','Please cancel my order','I’d like to cancel my trade order before it is processed.','New','','High'],
  ['Morgan Lee','Update on my cancellation','Could you share an update on the cancellation request?','Replied','','Normal'],
  ['Sam Patel','Request to cancel a trade','Please cancel trade order 132532327. Thank you.','New','','Normal'],
  ['Avery Tan','Order confirmation','Could you confirm that my instruction was received?','New','','Normal'],
  ['Trade Operations','Partial fill confirmed','The execution desk confirmed a partial fill. The remaining quantity is still open.','New','FSS-2026-29','Normal','Internal','Human'],
  ['Priya Shah','Cancel the remaining quantity','Please cancel the unfilled balance and leave the executed portion as is.','New','FSS-2026-30','High'],
  ['Custodian Gateway','Custodian trade confirmation','The custodian has accepted the trade and issued a confirmation for your records.','New','','Low','External','System'],
  ['Robin Ho','Order reference corrected','I checked the booking and sent the corrected order reference to the client.','New','FSS-2026-31','Normal','Internal','Human'],
  ['Drew Lin','Order amendment status','Can you confirm whether my amendment went through before cutoff?','New','','Normal'],
  ['Riley Chua','Cancellation after market close','Please confirm whether my cancellation can still be processed today.','New','FSS-2026-32','High'],
  ['Intellibox Alerts','Possible duplicate instruction','Two instructions share the same order reference. The case was escalated for review.','New','FSS-2026-42','High','Internal','System'],
  ['Casey Lau','Execution time inquiry','What time was my order executed? The confirmation only shows the date.','Replied','','Normal'],
  ['Reese Yap','Cancel an unfilled order','Please cancel the open order ahead of the next trading session.','New','FSS-2026-34','Normal'],
  ['Clearing Network','Settlement date updated','The clearing system moved the expected settlement date to the next business day.','New','','Low','External','System'],
  ['Blair Park','Verification documents received','The client supplied the documents we requested. Please verify them before releasing the instruction.','New','','Normal','Internal','Human'],
  ['Jules Teo','Trade cancellation acknowledgment','Thanks for the update. Could you confirm when the cancellation was accepted?','Replied','','Normal'],
  ['Workflow notifications','Approval reminder','An order amendment is still waiting for approval ahead of the next cutoff.','New','','High','Internal','System'],
  ['Dara Singh','Amend an open order','Can I change the limit price while the order is still open?','New','','Normal']
].map(([sender,title,body,status,linked,urgency,origin='External',senderType='Human'],index)=>({id:`mail-${index}`,sender,title,body,status,linked,urgency,origin,senderType,age:index}));
const cancellationCaseId='FSS-2026-33';
const cancellationEmailId='mail-cancellation-33';
const cancellationEmailDate=Date.parse('2026-11-27T10:47:49+08:00');
const cancellationRequester={name:'Joseph Tan',address:'Joseph.Tan@sc.com'};
const cancellationResponder={name:'Kingston Johnson',address:'Kingston.Johnson@sc.com'};
const cancellationCc=[
  {name:'Sara Liu',address:'Sara.Liu@sc.com'},
  {name:'Carlsson Chee',address:'Carlsson.Chee@sc.com'}
];
inboxSamples.push({
  id:cancellationEmailId,sender:'Joseph',title:'Please help to cancel',
  to:cancellationResponder.address,cc:cancellationCc,
  body:'Hi Team,\n\nI would like to cancel the trade raised with the order id 132532327 urgently. Thank you.\n\nRegards,\nJoseph',
  status:'Read',linked:cancellationCaseId,urgency:'High',importance:'High',origin:'External',senderType:'Human',
  age:Math.max(0,Math.floor((Date.now()-cancellationEmailDate)/86400000)),
  savedAt:cancellationEmailDate
});
const inboxThreadReplies={
  'mail-0':'We received your cancellation request and linked it to a case for review.',
  'mail-1':'We checked the order. The remaining quantity is still open.',
  'mail-3':'Your cancellation was accepted. We’ll send the final confirmation once processing is complete.',
  'mail-13':'Your order was executed at 10:42. We can send an updated confirmation if needed.',
  'mail-17':'The cancellation was accepted before the market cutoff.'
};
inboxSamples.find(email=>email.id==='mail-5').reply='Thank you for reaching out. We received your instruction and will confirm the order details shortly.';
const caseTagTones={
  New:'blue', Replied:'green', Sent:'teal', Bounced:'red', Draft:'amber', Completed:'green', 'Sent to client':'teal',
  Resolved:'green', 'Resolved by rejection':'green', 'SLA breached':'green', 'AI processing':'purple',
  'Pending approval':'amber', 'Pending manual resolution':'amber',
  Rejected:'red', Escalated:'red', Expired:'red',
  Trade:'teal', Ops:'blue', Technology:'purple', Cancellation:'purple', 'Order inquiry':'purple',
  Compliance:'amber', Settlement:'teal', Approval:'blue',
  'Client service':'blue', Custody:'purple', 'Order status':'blue',
  'Instruction receipt':'green', 'Partial execution':'teal', 'Trade confirmation':'green',
  'Booking correction':'amber', 'Order amendment':'purple', 'Duplicate detection':'orange',
  'Execution inquiry':'blue', 'Settlement date':'teal', 'Document verification':'amber', 'Delivery failure':'red',
  Neutral:'gray', Normal:'green', High:'red'
};
function statusIcon(status){
  const icons={
    Draft:'draft', 'AI processing':'ai', 'Sent to client':'progress',
    Completed:'complete', Resolved:'success',
    Sent:'success', Replied:'success',
    Rejected:'rejected', 'Resolved by rejection':'success',
    Bounced:'error', Escalated:'minor-error', 'SLA breached':'error', Expired:'minor-error',
    'Pending approval':'pending', 'Pending manual resolution':'pending'
  };
  return icons[status]||'information';
}
const additionalCaseStatuses={
  'FSS-2026-29':'Completed',
  'FSS-2026-30':'Pending approval',
  'FSS-2026-31':'Sent to client',
  'FSS-2026-32':'Pending manual resolution',
  'FSS-2026-42':'Escalated',
  [cancellationCaseId]:'Pending approval',
  'FSS-2026-34':'Completed'
};
const internalCaseExamples=new Set(['FSS-2026-1','FSS-2026-2','FSS-2026-6','FSS-2026-7','FSS-2026-8','FSS-2026-35','FSS-2026-36','FSS-2026-40','FSS-2026-41']);
const caseSamples=[
  {id:'FSS-2026-28',title:'Trade order cancellation request',status:'Completed',body:inboxSamples[0].body,age:0},
  ...approvals.map(([id,title],index)=>({id,title,status:index%2?'Pending manual resolution':'Pending approval',body:`${title}. This request is awaiting approval from the client service team.`,age:index+1})),
  ...statuses.filter(item=>!item.label.startsWith('Pending')&&item.label!=='Completed').map((item,index)=>({id:`FSS-2026-${19+index}`,title:`Trade cancellation · ${item.label}`,status:item.label,body:`Current status: ${item.label}.`,age:index+2})),
  ...[
    ['FSS-2026-35','Duplicate cancellation closed','Resolved by rejection','The original request was already resolved.',2],
    ['FSS-2026-36','Settlement instruction awaiting review','SLA breached','The case exceeded its service deadline.',3],
    ['FSS-2026-37','Check trade execution status','AI processing','The agent is checking the order status.',0],
    ['FSS-2026-38','Review revised settlement instruction','AI processing','The agent is extracting the updated instruction.',0],
    ['FSS-2026-39','Confirm client reference','Pending approval','The case is awaiting a reference check.',1],
    ['FSS-2026-40','Ask operations to cancel an order','Pending manual resolution','The agent requested that operations cancel the remaining quantity.',2],
    ['FSS-2026-41','Notify client of case closure','Completed','The agent sent the client a case closure notice.',3]
  ].map(([id,title,status,body,age])=>({id,title,status,body,age})),
  ...inboxSamples.filter(item=>additionalCaseStatuses[item.linked]).map(({linked,title,body,age,savedAt})=>({id:linked,title,status:additionalCaseStatuses[linked],body,age,savedAt}))
].map(item=>({
  ...item,origin:inboxSamples.find(email=>email.linked===item.id)?.origin||(internalCaseExamples.has(item.id)?'Internal':'External')
})).sort((first,second)=>first.age-second.age);
const defaultMailCaseIds=new Map(inboxSamples.map((email,index)=>[email.id,email.linked||'FSS-2026-'+(100+index)]));
const caseLinkStorageKey='intellibox:case-email-links';
let savedCaseLinks={};
try{
  savedCaseLinks=JSON.parse(sessionStorage.getItem(caseLinkStorageKey))||{};
}catch{}
for(const email of inboxSamples){
  email.linked=savedCaseLinks[email.id]||defaultMailCaseIds.get(email.id);
}
const emailStateKey='intellibox:email-state';
let emailState={};
try{emailState=JSON.parse(sessionStorage.getItem(emailStateKey))||{}}catch{}
for(const email of inboxSamples){
  Object.assign(email,emailState[email.id]);
  if(email.archived)email.linked='';
}
const isArchivedEmail=email=>Boolean(email.archived||email.disregarded);
function updateInboxEmail(email,changes){
  Object.assign(email,changes);
  emailState[email.id]={...emailState[email.id],...changes};
  try{sessionStorage.setItem(emailStateKey,JSON.stringify(emailState))}catch{}
}
const caseUndoNotice=document.getElementById('caseUndoNotice');
let lastArchivedEmail;
function restoreArchivedEmail(email){
  const linked=email.archivedLink||email.linked||defaultMailCaseIds.get(email.id);
  updateInboxEmail(email,{archived:false,disregarded:false,archivedLink:null});
  updateEmailLink(email,linked);
}
document.getElementById('caseUndoArchive').addEventListener('click',()=>{
  if(lastArchivedEmail)restoreArchivedEmail(lastArchivedEmail);
  lastArchivedEmail=undefined;
  caseUndoNotice.hidden=true;
  renderCaseWorkspace('Email restored');
  caseUi.caseSearch.focus({preventScroll:true});
});
function updateEmailLink(email,caseId){
  email.linked=caseId;
  savedCaseLinks[email.id]=caseId;
  try{sessionStorage.setItem(caseLinkStorageKey,JSON.stringify(savedCaseLinks))}catch{}
}
let caseViewMode='casebox';
let activeMailFolder='inbox';
const mailFolderNames={inbox:'Inbox',sent:'Sent',bounced:'Bounced',drafts:'Drafts',archive:'Archive'};
const caseMailFolders=document.getElementById('caseMailFolders');
const caseFolderToggle=document.getElementById('caseFolderToggle');
function setMailFolderMenu(open){
  caseMailFolders.classList.toggle('is-menu-open',open);
  caseFolderToggle.setAttribute('aria-expanded',String(open));
}
caseFolderToggle.addEventListener('click',()=>{
  const open=caseFolderToggle.getAttribute('aria-expanded')!=='true';
  setMailFolderMenu(open);
  if(open)caseMailFolders.querySelector('[aria-current="page"]')?.focus();
});
document.addEventListener('click',event=>{
  if(!caseMailFolders.contains(event.target)&&!caseFolderToggle.contains(event.target))setMailFolderMenu(false);
});
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&caseMailFolders.classList.contains('is-menu-open')){
    setMailFolderMenu(false);
    caseFolderToggle.focus();
  }
});
matchMedia('(max-width:850px)').addEventListener('change',()=>setMailFolderMenu(false));
const caseComposeDialog=document.getElementById('caseComposeDialog');
const caseComposeForm=document.getElementById('caseComposeForm');
const caseSendNotice=document.getElementById('caseSendNotice');
let caseSendNoticeTimer;
function showCaseSnackbar(message,success=false,position="bottom"){
  caseSendNotice.dataset.position=position;
  clearTimeout(caseSendNoticeTimer);
  caseSendNotice.querySelector('i').hidden=!success;
  caseSendNotice.querySelector('span').textContent=message;
  caseSendNotice.classList.add('on');
  caseSendNoticeTimer=setTimeout(()=>caseSendNotice.classList.remove('on'),4200);
}
const composeStorageKey='intellibox:composed-emails';
let composedEmails=[];
let visibleMailAiDraft;
const mailApproveAndSend=document.getElementById('mailApproveAndSend');
const mailReplyAndSend=document.getElementById('mailReplyAndSend');
const mailReviewAction=document.getElementById('mailReviewAction');
const mailReviewForm=document.getElementById('mailReviewForm');
const mailReviewActions=document.getElementById('mailReviewActions');
let reviewingMailId;
const mailRejectAndSend=document.getElementById('mailRejectAndSend');
const cancellationDecision={
  'approve-cancellation':{status:'Resolved',label:'Approve cancellation & Send',decision:'Cancellation approved and confirmed by email.'},
  'reject-cancellation':{status:'Resolved by rejection',label:'Reject cancellation & Send',decision:'Cancellation declined and communicated by email.'}
};
let renderingMailAiDraftId;
let mailAiDraftTimer;
try{
  const saved=JSON.parse(sessionStorage.getItem(composeStorageKey));
  if(Array.isArray(saved))composedEmails=saved.filter(email=>!email.id.startsWith('compose-case-'));
}catch{}
let editingComposeId='';
let editingComposeSourceId;
let initialComposeFields;
function openCaseComposer(email){
  if(caseComposeDialog.open){
    caseComposeForm.elements.recipient.focus();
    return;
  }
  editingComposeId=email.id;
  editingComposeSourceId=email.sourceEmailId;
  caseComposeForm.elements.recipient.value=email?.recipient||'';
  caseComposeForm.elements.subject.value=email?.subject||'';
  caseComposeForm.elements.message.value=email?.body||'';
  initialComposeFields=[...new FormData(caseComposeForm).values()];
  caseComposeDialog.show();
  caseComposeForm.elements.recipient.focus();
}
function recordComposedEmail(email){
  composedEmails=[email,...composedEmails.filter(item=>item.id!==email.id)];
  try{sessionStorage.setItem(composeStorageKey,JSON.stringify(composedEmails))}catch{}
}
function storeComposedEmail(status,openFolder=true){
  const {recipient,subject,message}=caseComposeForm.elements;
  const email={
    id:editingComposeId,sourceEmailId:editingComposeSourceId,
    linked:inboxSamples.find(email=>email.id===editingComposeSourceId)?.linked,
    status,recipient:recipient.value.trim(),subject:subject.value.trim(),body:message.value.trim(),savedAt:Date.now()
  };
  if(!email.recipient&&!email.subject&&!email.body)return;
  recordComposedEmail(email);
  caseComposeDialog.close();
  if(!openFolder){
    renderCaseWorkspace('Draft saved');
    return;
  }
  setupCaseWorkspace('casebox',undefined,status==='Sent'?'sent':'drafts');
  caseSelectedId=email.id;
  renderCaseWorkspace(status==='Draft'?'Draft saved':'');
  if(status==='Sent'){
    if(embeddedMode&&parent!==window){
      parent.postMessage({type:'intellibox:email-sent'},location.origin);
      return;
    }
    showCaseSnackbar('Email sent',true);
  }
}
function closeCaseComposer(){
  const fields=[...new FormData(caseComposeForm).values()];
  if(fields.some((value,index)=>value!==initialComposeFields[index])&&fields.some(value=>value.trim())){
    storeComposedEmail('Draft',false);
    return;
  }
  caseComposeDialog.close();
}
document.getElementById('caseCloseCompose').addEventListener('click',closeCaseComposer);
document.getElementById('caseSaveCompose').addEventListener('click',()=>storeComposedEmail('Draft'));
caseComposeForm.addEventListener('submit',event=>{
  event.preventDefault();
  if(caseComposeForm.elements.message.value.trim())storeComposedEmail('Sent');
});
caseComposeDialog.addEventListener('keydown',event=>{
  if(event.key==='Escape')closeCaseComposer();
});
document.getElementById('caseCollapseFolders').addEventListener('click',event=>{
  const collapsed=caseMailFolders.classList.toggle('is-collapsed');
  const label=collapsed?'Expand folders':'Collapse folders';
  event.currentTarget.setAttribute('aria-expanded',String(!collapsed));
  event.currentTarget.setAttribute('aria-label',label);
  event.currentTarget.title=label;
});
const bouncedMailSamples=[
  {id:'bounce-1',title:'Trade confirmation copy',recipient:'settlements@example.com',age:0,body:'Delivery failed because the recipient mailbox could not be found.',originalBody:'Please find the trade confirmation for your settlement records.'},
  {id:'bounce-2',title:'Order amendment confirmation',recipient:'operations@example.com',age:1,body:'Delivery failed because the recipient mailbox was full.',originalBody:'The order amendment has been confirmed. Please update your records.'}
].map(email=>({...email,status:'Bounced',sender:'Client service team',origin:'Internal',senderType:'Human',urgency:'Normal'}));
function sentThreadReplies(email){
  const sent=[...composedEmails,...caseApprovedEmails].filter(message=>
    message.status==='Sent'&&(message.sourceEmailId===email.id||
      (!message.sourceEmailId&&email.id===cancellationEmailId&&message.linked===cancellationCaseId))
  ).sort((a,b)=>b.savedAt-a.savedAt);
  const sampleBody=inboxThreadReplies[email.id];
  if(sampleBody)sent.push({
    subject:'Re: '+email.title,body:sampleBody,recipient:emailSenderAddress(email),
    savedAt:threadMessageDate(email.age,true).getTime()
  });
  return sent.map(message=>({
    ...message,title:message.subject,sender:message.sender||'Client service team',
    senderAddress:message.senderAddress||'',origin:'Internal',
    cc:message.cc?.map(address=>typeof address==='string'
      ? {address,name:caseEmployeeProfiles[address.toLowerCase()]?.[0]||address}
      : address)
  }));
}
function mailFolderItems(){
  if(activeMailFolder==='bounced')return bouncedMailSamples.filter(email=>!composedEmails.some(sent=>sent.id===`resend-${email.id}`));
  if(activeMailFolder==='archive')return inboxSamples.filter(isArchivedEmail);
  const composed=[...caseApprovedEmails,...composedEmails].filter(email=>
    (activeMailFolder==='drafts'&&email.status==='Draft')||
    (activeMailFolder==='sent'&&email.status==='Sent')
  ).map(email=>({...email,title:email.subject||'(No subject)',sender:email.sender||'Client service team',origin:'Internal',senderType:'Human',urgency:'Normal',age:0}));
  if(activeMailFolder==='drafts')return [...composed,...inboxSamples.filter(email=>email.reply).map(email=>({
    ...email,title:`Re: ${email.title}`,body:email.reply,status:'Draft',recipient:email.sender,savedAt:email.replySavedAt,
    sender:'Client service team',origin:'Internal',senderType:'Human'
  }))];
  if(activeMailFolder==='sent')return [...composed,...inboxSamples.filter(email=>inboxThreadReplies[email.id]).map(email=>({
    ...email,title:`Re: ${email.title}`,body:inboxThreadReplies[email.id],status:'Sent',recipient:email.sender,
    sender:'Client service team',origin:'Internal',senderType:'Human'
  }))];
  const received=inboxSamples.filter(email=>!isArchivedEmail(email));
  if(activeMailFolder==='inbox'){
    const featured=received.findIndex(email=>email.id===cancellationEmailId);
    if(featured>0)received.unshift(...received.splice(featured,1));
  }
  return received.map(email=>sentThreadReplies(email).length?{...email,status:'Replied'}:email);
}
function displayMailbox(value){
  const name=value.trim();
  if(name.includes('@'))return name;
  const handle=name.replace(/[^a-z0-9]+/gi,'.').replace(/^\.|\.$/g,'');
  return handle?`${handle}@example.com`:'';
}
function emailSenderAddress(email){
  if(email.senderAddress)return email.senderAddress;
  if(email.sender==='Joseph')return cancellationRequester.address;
  return displayMailbox(email.sender);
}
function emailSenderAvatar(sender,address){
  const initials=sender.split(' ').slice(0,2).map(word=>word[0]).join('').toUpperCase();
  const avatar=caseEmployeeProfiles[address.toLowerCase()]?.[4];
  return `<span class="case-avatar" aria-hidden="true">${avatar?`<img src="${avatar}" alt="">`:safeEmailPreview(initials)}</span>`;
}
const safeEmailPreview=text=>text.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const mailSubject=(title,origin)=>`[${origin}] ${title}`;
let caseSelectedId='';
let caseSelectedMessage=0;
let caseVisibleItems=[];
const compactMailLayout=matchMedia('(max-width:850px)');
const caseBackToMail=document.getElementById('caseBackToMail');
let compactMailListScroll=0;
let emailIllustration;
const emailEmptyState=document.getElementById('caseEmailEmpty');
const reducedEmailMotion=matchMedia('(prefers-reduced-motion: reduce)');
function showEmailEmptyState(visible){
  if(emailEmptyState.hidden===!visible)return;
  emailEmptyState.hidden=!visible;
  if(!visible){
    emailIllustration?.pause();
    return;
  }
  if(!emailIllustration){
    emailIllustration=window.lottie.loadAnimation({
      container:document.getElementById('caseEmailAnimation'),
      renderer:'svg',loop:true,autoplay:false,animationData:structuredClone(inboxEmailAnimation)
    });
  }
  if(reducedEmailMotion.matches)emailIllustration.goToAndStop(45,true);
  else emailIllustration.goToAndPlay(0,true);
}
const caseFilterPanel=document.getElementById('caseFilterPanel');
const caseFilterToggle=document.getElementById('caseFilterToggle');
const caseAdvancedToggle=document.getElementById('caseAdvancedToggle');
const caseClearFilters=document.getElementById('caseClearFilters');
const caseAdvancedDialog=document.getElementById('caseAdvancedDialog');
const caseAdvancedForm=document.getElementById('caseAdvancedForm');
const caseAdvancedChoices=document.getElementById('caseAdvancedChoices');
const caseCustomDates=document.getElementById('caseCustomDates');
const caseLinkDialog=document.getElementById('caseLinkDialog');
const caseLinkForm=document.getElementById('caseLinkForm');
const caseLinkId=document.getElementById('caseLinkId');
let appliedEmailFilters=new FormData();
let clearQuickOnApply=false;
const emailRecipient=item=>item.recipient||(classifyInboxItem(item)[0]==='Ops'?'Trade Operations':'Client service team');
const emailAttachments=new Map([
  ['mail-8',{name:'Trade confirmation.txt',body:'Sample trade confirmation\n\nThe custodian accepted the trade and issued a confirmation for your records.'}],
  ['mail-15',{name:'Settlement update.txt',body:'Sample settlement update\n\nThe expected settlement date moved to the next business day.'}],
  ['mail-16',{name:'Verification checklist.txt',body:'Sample verification checklist\n\nReview the client reference, confirm the instruction details, and check that the requested documents are complete.'}]
]);
const mailAttachmentDialog=document.getElementById('mailAttachmentDialog');
const mailReaderAttachment=document.getElementById('mailReaderAttachment');
const mailReaderAttachmentOpen=document.getElementById('mailReaderAttachmentOpen');
const mailAttachmentDownload=document.getElementById('mailAttachmentDownload');
let openedMailAttachmentId;
let mailAttachmentTrigger;
let mailAttachmentUrl;
function openMailAttachment(id,trigger){
  const attachment=emailAttachments.get(id);
  if(!attachment)return false;
  openedMailAttachmentId=id;
  mailAttachmentTrigger=trigger;
  document.getElementById('mailAttachmentTitle').textContent=attachment.name;
  document.getElementById('mailAttachmentText').textContent=attachment.body;
  mailAttachmentUrl=URL.createObjectURL(new Blob([attachment.body],{type:'text/plain;charset=utf-8'}));
  mailAttachmentDownload.href=mailAttachmentUrl;
  mailAttachmentDownload.download=attachment.name;
  mailAttachmentDialog.showModal();
  return true;
}
mailReaderAttachmentOpen.addEventListener('click',()=>{
  openMailAttachment(mailReaderAttachmentOpen.dataset.mailId,mailReaderAttachmentOpen);
});
const inboxClassifications={
  'mail-1':['Client service','Order status'],
  'mail-5':['Client service','Instruction receipt'],
  'mail-6':['Ops','Partial execution'],
  'mail-8':['Custody','Trade confirmation'],
  'mail-9':['Ops','Booking correction'],
  'mail-10':['Trade','Order amendment'],
  'mail-11':['Trade','Cancellation eligibility'],
  'mail-12':['Technology','Duplicate detection'],
  'mail-13':['Trade','Execution inquiry'],
  'mail-15':['Settlement','Settlement date'],
  'mail-16':['Compliance','Document verification'],
  'mail-18':['Ops','Approval'],
  'mail-19':['Trade','Order amendment'],
  'bounce-1':['Settlement','Delivery failure'],
  'bounce-2':['Ops','Delivery failure']
};
function classifyInboxItem(item){
  return inboxClassifications[item.id]||['Trade',/cancel/i.test(item.title)?'Cancellation':'Order inquiry'];
}
const mailReviewTypes={
  'Order amendment':['Check order amendment','Match the amendment to the original order.','Check whether the amendment was accepted before the cutoff.'],
  'Cancellation eligibility':['Check cancellation eligibility','Check the order status and whether the market cutoff has passed.','Confirm what can still be cancelled.'],
  'Document verification':['Verify documents','Check that the requested documents are present.','Verify they match the client and instruction before release.'],
  'Duplicate detection':['Review duplicate instruction','Compare both instructions against the original order.','Confirm whether either instruction should be held for review.'],
  'Approval':['Check pending approval','Verify which instruction is awaiting approval.','Confirm the approver and current status.']
};
const existingCaseIds=new Set(caseSamples.map(item=>item.id));
for(const email of inboxSamples){
  const id=defaultMailCaseIds.get(email.id);
  if(existingCaseIds.has(id))continue;
  const [,subcategory]=classifyInboxItem(email);
  const status=email.status==='Replied'||(email.senderType==='System'&&!mailReviewTypes[subcategory])
    ?'Completed'
    : subcategory==='Cancellation'?'Pending approval':'Pending manual resolution';
  caseSamples.push({id,title:email.title,body:email.body,age:email.age,savedAt:email.savedAt,origin:email.origin,status});
  existingCaseIds.add(id);
}
function primaryMailAction(email,canDecideCancellation){
  if(canDecideCancellation)return 'decision';
  if(email.status==='Replied'||classifyInboxItem(email)[1]==='Cancellation')return '';
  const review=mailReviewTypes[classifyInboxItem(email)[1]];
  if(review&&!email.manuallyReviewed)return 'review';
  return email.senderType==='System'?'':'reply';
}
function filterGroup(key,label,options,selected){
  if(!options.length)return '';
  return `<fieldset><legend>${label}</legend>${options.map(value=>{
    const encoded=safeEmailPreview(value);
    return `<label><input type="checkbox" name="${key}" value="${encoded}"${value===selected?' checked':''}><span>${encoded}</span></label>`;
  }).join('')}</fieldset>`;
}
function setCaseFilterOpen(open){
  caseFilterPanel.hidden=!open;
  caseFilterToggle.setAttribute('aria-expanded',String(open));
}
caseFilterToggle.addEventListener('click',()=>setCaseFilterOpen(caseFilterPanel.hidden));
caseAdvancedToggle.addEventListener('click',()=>{
  setCaseFilterOpen(false);
  clearQuickOnApply=false;
  const emails=mailFolderItems();
  const categories=emails.map(classifyInboxItem);
  const choices=[
    ['subcategory','Subcategory',categories.map(([,value])=>value)],
    ['fromSender','Sender',emails.map(item=>item.sender)],
    ['recipient','Recipient',emails.map(emailRecipient)]
  ];
  caseAdvancedChoices.innerHTML=choices.map(([key,label,options])=>
    `<div class="case-advanced-choice"><span>${label}</span><details>
      <summary aria-label="${label}"><span>Select</span><img src="Icon/arrow chevron nav downward.svg" alt=""></summary>
      <div class="case-filter-panel">${filterGroup(key,label,[...new Set(options)])}</div>
    </details></div>`
  ).join('');
  caseAdvancedForm.reset();
  for(const input of caseAdvancedForm.elements){
    if(input.type==='checkbox'||input.type==='radio'){
      if(input.name==='range')input.checked=input.value===(appliedEmailFilters.get('range')||'all');
      else input.checked=appliedEmailFilters.getAll(input.name).includes(input.value);
    }else if(input.name)input.value=appliedEmailFilters.get(input.name)||'';
  }
  syncAdvancedForm();
  caseAdvancedDialog.showModal();
});
function syncAdvancedForm(){
  const {range,from,to}=caseAdvancedForm.elements;
  caseCustomDates.hidden=range.value!=='custom';
  from.disabled=to.disabled=caseCustomDates.hidden;
  to.min=from.value;
  caseAdvancedChoices.querySelectorAll('details').forEach(choice=>{
    const checked=[...choice.querySelectorAll(':checked')];
    choice.querySelector('summary span').textContent=checked.length?checked.map(input=>input.value).join(', '):'Select';
  });
}
caseAdvancedForm.addEventListener('change',syncAdvancedForm);
caseAdvancedForm.addEventListener('click',event=>{
  const current=event.target.closest('details');
  caseAdvancedChoices.querySelectorAll('details[open]').forEach(choice=>{if(choice!==current)choice.open=false});
  if(event.target.closest('[data-close-filters]'))caseAdvancedDialog.close();
});
caseAdvancedDialog.addEventListener('close',()=>caseFilterToggle.focus());
document.getElementById('caseClearAdvanced').addEventListener('click',()=>{
  caseAdvancedForm.reset();
  clearQuickOnApply=true;
  syncAdvancedForm();
});
caseAdvancedForm.addEventListener('submit',event=>{
  event.preventDefault();
  const draft=new FormData(caseAdvancedForm);
  if(clearQuickOnApply)caseFilterPanel.querySelectorAll(':checked').forEach(input=>input.checked=false);
  if(draft.get('range')==='all')draft.delete('range');
  for(const key of ['subject','content']){
    const value=draft.get(key).trim().toLowerCase();
    if(value)draft.set(key,value);
    else draft.delete(key);
  }
  appliedEmailFilters=draft;
  caseAdvancedDialog.close();
  renderCaseWorkspace();
});
function resetEmailFilters(){
  caseFilterPanel.querySelectorAll(':checked').forEach(input=>input.checked=false);
  appliedEmailFilters=new FormData();
}
caseClearFilters.addEventListener('click',()=>{
  resetEmailFilters();
  renderCaseWorkspace();
  caseFilterToggle.focus();
});
caseFilterPanel.addEventListener('change',()=>{
  renderCaseWorkspace();
});
document.addEventListener('click',event=>{
  if(!caseUi.caseFilter.contains(event.target))setCaseFilterOpen(false);
});
caseUi.caseFilter.addEventListener('keydown',event=>{
  if(event.key!=='Escape'||caseFilterPanel.hidden)return;
  setCaseFilterOpen(false);
  caseFilterToggle.focus();
});
const mailWorkspace=document.getElementById('mailWorkspace');
const casesWorkspace=document.getElementById('casesWorkspace');
const caseListNav=document.getElementById('caseListNav');
const caseListToggle=document.getElementById('caseListToggle');
const caseListSearch=document.getElementById('caseListSearch');
const caseListRows=document.getElementById('caseListRows');
const caseListPrevious=document.getElementById('caseListPrevious');
const caseListNext=document.getElementById('caseListNext');
const caseDetailWorkspace=document.getElementById('caseDetailWorkspace');
const caseQuickView=document.getElementById('caseQuickView');
const caseQuickContent=document.getElementById('caseQuickContent');
const caseQuickActions=document.getElementById('caseQuickActions');
const caseQuickResize=document.getElementById('caseQuickResize');
const originalCaseEmailButton=document.getElementById('openOriginalCaseEmail');
const caseWorkspaceHeading=document.getElementById('caseWorkspaceHeading');
const caseDetailBack=document.getElementById('caseDetailBack');
const caseReturnPageNames={casebox:'Inbox',cases:'All cases',overview:'Overview',diagnostics:'Diagnostics'};
const caseWorkspaceTitle=document.getElementById('caseWorkspaceTitle');
const caseWorkspaceSummary=document.getElementById('caseWorkspaceSummary');
const caseDraftActions=document.getElementById('caseDraftActions');
const caseDetailsTab=document.getElementById('caseDetailsTab');
const caseAuditTab=document.getElementById('caseAuditTab');
const caseApprovalDraft=document.getElementById('caseApprovalDraft');
const caseDraftResize=document.getElementById('caseDraftResize');
const caseDraftSubject=document.getElementById('caseDraftSubject');
const draftHeight=()=>caseApprovalDraft.offsetHeight;
function syncCaseDraftResize(height){
  if(caseDraftResize.hidden||!caseApprovalDraft.offsetHeight)return;
  const max=Math.max(0,caseDraftResize.parentElement.clientHeight-caseWorkspaceHeading.offsetHeight-caseWorkspaceSummary.offsetHeight-caseDraftResize.offsetHeight-48);
  const min=Math.min(180,max);
  if(height!==undefined){
    caseApprovalDraft.style.setProperty('--case-draft-height',`${Math.max(min,Math.min(max,height))}px`);
  }
  caseDraftResize.setAttribute('aria-valuemin',min);
  caseDraftResize.setAttribute('aria-valuemax',max);
  caseDraftResize.setAttribute('aria-valuenow',Math.max(min,Math.min(max,draftHeight())));
}
let draftDrag;
caseDraftResize.addEventListener('pointerdown',event=>{
  if(!event.isPrimary||event.button!==0)return;
  draftDrag={id:event.pointerId,y:event.clientY,height:draftHeight()};
  caseDraftResize.setPointerCapture(event.pointerId);
  caseDraftResize.dataset.dragging='';
});
caseDraftResize.addEventListener('pointermove',event=>{
  if(draftDrag?.id===event.pointerId)syncCaseDraftResize(draftDrag.height+event.clientY-draftDrag.y);
});
caseDraftResize.addEventListener('lostpointercapture',()=>{
  draftDrag=undefined;
  delete caseDraftResize.dataset.dragging;
});
caseDraftResize.addEventListener('keydown',event=>{
  const sizes={ArrowUp:draftHeight()-24,ArrowDown:draftHeight()+24,Home:0,End:Infinity};
  if(!Object.hasOwn(sizes,event.key))return;
  event.preventDefault();
  syncCaseDraftResize(sizes[event.key]);
});
new ResizeObserver(()=>syncCaseDraftResize()).observe(caseApprovalDraft);
const caseDraftBody=document.getElementById('caseDraftBody');
const caseDraftTo=document.getElementById('caseDraftTo');
const caseDraftRecipientField=document.getElementById('caseDraftRecipientField');
const caseAiWrite=document.getElementById('caseAiWrite');
const caseDraftSend=document.getElementById('caseDraftSend');
const caseDraftReject=document.getElementById('caseDraftReject');
const caseAiWriteStatus=document.getElementById('caseAiWriteStatus');
let caseAiWriteTimer;
let caseAiWriting=false;
let caseAiWriteAttempts=0;
const caseAiWriteLabel=caseAiWrite.lastElementChild;
const openedCases=(embeddedMode&&parent!==window?parent.intelliboxOpenedCaseIds:undefined)||[];
function notifyOpenedCasesChanged(){
  if(embeddedMode&&parent!==window)parent.postMessage({type:'intellibox:opened-cases-changed'},location.origin);
}
const casePreviewState=(embeddedMode&&parent!==window?parent.intelliboxCasePreview:undefined)||{decisions:{},sent:[],drafts:new Map()};
const caseDrafts=casePreviewState.drafts;
const caseDecisions=casePreviewState.decisions;
const caseApprovedEmails=casePreviewState.sent;
for(const item of caseSamples)Object.assign(item,caseDecisions[item.id]);
const featuredCase=caseSamples.find(item=>item.id===cancellationCaseId);
const latestOtherCaseUpdate=Math.max(...caseSamples.filter(item=>item!==featuredCase).map(item=>emailRecordDate(item).getTime()));
featuredCase.savedAt=Math.max(Date.now(),latestOtherCaseUpdate+1000);
let activeCaseId='';
let caseAuditVisible=false;
const caseListGroups={
  'Pending actions':['Pending manual resolution','Pending approval'],
  'In progress':['AI processing','Sent to client'],
  Completed:['Resolved','Resolved by rejection','SLA breached'],
  Exceptions:['Rejected','Escalated','Expired']
};
const responseCaseIds={
  'Confirmed cancellation':['FSS-2026-28','FSS-2026-4','FSS-2026-9'],
  'Asked for more information':['FSS-2026-3','FSS-2026-39'],
  'Asked ops to cancel':['FSS-2026-40'],
  'Case closure notify':['FSS-2026-41'],
  'Asked for human intervention':['FSS-2026-6','FSS-2026-8','FSS-2026-1','FSS-2026-42']
};
const caseListPageSize=20;
let caseListCategory='All';
let caseListPage=0;
const displayCaseStatus=item=>item.status==='Completed'?'Resolved':item.status;
function matchesCaseCategory(item,category){
  if(category==='All')return true;
  if(category==='Overdue approvals')return approvals.some(approval=>approval[0]===item.id&&exceedsApprovalSla(approval));
  if(Object.hasOwn(responseCaseIds,category))return responseCaseIds[category].includes(item.id);
  const status=displayCaseStatus(item);
  return status===category||(caseListGroups[category]||[]).includes(status);
}
function linkedSourceEmail(item){
  return inboxSamples.find(email=>email.linked===item.id);
}
function caseSubject(item){
  const email=linkedSourceEmail(item);
  return `[${email?.origin||item.origin}] ${email?.title||item.title}`;
}
function caseTableClassification(item){
  const email=linkedSourceEmail(item);
  if(email)return classifyInboxItem(email);
  if(/settlement/i.test(item.title))return ['Settlement','Settlement instruction'];
  return ['Trade',/cancel/i.test(item.title)?'Cancellation':'Order inquiry'];
}
function setupCasesList(destination){
  showCaseListView();
  const specificCase=caseSamples.find(item=>item.id===destination);
  caseListCategory=destination==='Cases completed'?'Completed':specificCase||!destination||destination==='all'?'All':destination;
  caseListPage=0;
  caseListSearch.value=specificCase?.id||'';
  const label=(category)=>`<span>${category}</span><span class="case-list-badge">${caseSamples.filter(item=>matchesCaseCategory(item,category)).length}</span>`;
  const entry=(category)=>`<button type="button" data-case-list-category="${category}">${label(category)}</button>`;
  caseListNav.innerHTML=entry('All')+Object.entries(caseListGroups).map(([group,children])=>
    `<details class="case-list-group" open><summary class="case-list-group-label">${label(group)}</summary><div class="case-list-children">${children.map(entry).join('')}</div></details>`
  ).join('');
  setCaseListMenu(false);
  renderCasesList();
  if(specificCase)showCaseDetails(specificCase);
}
function emphasizeNumericValues(text){
  return safeEmailPreview(text).replace(/\d+(?:[,.]\d+)*(?:%)?/g,value=>`<span class="numeric-value">${value}</span>`);
}
function renderCasesList(){
  const query=caseListSearch.value.trim().toLowerCase();
  const results=caseSamples.filter(item=>matchesCaseCategory(item,caseListCategory)&&
    [item.id,caseSubject(item),item.status,displayCaseStatus(item),...caseTableClassification(item)].some(value=>value.toLowerCase().includes(query)));
  results.sort((first,second)=>emailRecordDate(second)-emailRecordDate(first));
  const pageCount=Math.max(1,Math.ceil(results.length/caseListPageSize));
  caseListPage=Math.min(caseListPage,pageCount-1);
  const offset=caseListPage*caseListPageSize;
  document.getElementById('caseListTitle').textContent=caseListCategory==='All'?'All cases':caseListCategory;
  document.getElementById('caseListCount').innerHTML=emphasizeNumericValues(`${results.length} ${results.length===1?'case':'cases'}`);
  for(const button of caseListNav.querySelectorAll('[data-case-list-category]')){
    if(button.dataset.caseListCategory===caseListCategory)button.setAttribute('aria-current','page');
    else button.removeAttribute('aria-current');
  }
  caseListRows.innerHTML=results.slice(offset,offset+caseListPageSize).map(item=>{
    const status=displayCaseStatus(item);
    const [category,subcategory]=caseTableClassification(item);
    const updated=emailRecordDate(item);
    return `<tr><td><button class="case-link-action" type="button" data-open-case="${item.id}">${item.id}</button></td>
      <td>${safeEmailPreview(caseSubject(item))}</td><td><span class="case-status-label" data-status-icon="${statusIcon(status)}">${status}</span></td>
      <td><span class="case-table-classification"><img src="Icon/cube 3D.svg" alt="">${safeEmailPreview(category)}</span></td>
      <td><span class="case-table-classification"><img src="Icon/cube 3D.svg" alt="">${safeEmailPreview(subcategory)}</span></td>
      <td><time datetime="${updated.toISOString()}">${fullActivityDateFormat.format(updated)} · ${caseUpdatedTimeFormat.format(updated)}</time></td></tr>`;
  }).join('')||'<tr><td colspan="6">No matching cases</td></tr>';
  document.getElementById('caseListPageSummary').innerHTML=emphasizeNumericValues(results.length?
    `${offset+1}–${Math.min(offset+caseListPageSize,results.length)} of ${results.length}`:'0 cases');
  caseListPrevious.disabled=caseListPage===0;
  caseListNext.disabled=caseListPage+1>=pageCount;
  caseListRows.closest('.case-list-table-region').scrollTop=0;
}
function setCaseListMenu(open){
  caseListNav.classList.toggle('is-menu-open',open);
  caseListToggle.setAttribute('aria-expanded',String(open));
}
caseListToggle.addEventListener('click',()=>{
  const open=caseListToggle.getAttribute('aria-expanded')!=='true';
  setCaseListMenu(open);
  if(open)caseListNav.querySelector('[data-case-list-category]').focus();
});
document.addEventListener('click',event=>{
  if(!caseListNav.contains(event.target)&&!caseListToggle.contains(event.target))setCaseListMenu(false);
});
casesWorkspace.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&caseListNav.classList.contains('is-menu-open')){
    setCaseListMenu(false);
    caseListToggle.focus();
  }
});
caseListNav.addEventListener('click',event=>{
  const category=event.target.closest('[data-case-list-category]')?.dataset.caseListCategory;
  if(!category)return;
  caseListCategory=category;
  caseListPage=0;
  caseListSearch.value='';
  if(caseListNav.classList.contains('is-menu-open')){
    setCaseListMenu(false);
    caseListToggle.focus();
  }
  renderCasesList();
});
caseListSearch.addEventListener('input',()=>{caseListPage=0;renderCasesList()});
document.getElementById('caseListRefresh').addEventListener('click',renderCasesList);
caseListPrevious.addEventListener('click',()=>{caseListPage=Math.max(0,caseListPage-1);renderCasesList()});
caseListNext.addEventListener('click',()=>{caseListPage++;renderCasesList()});
caseListRows.addEventListener('click',event=>{
  const id=event.target.closest('[data-open-case]')?.dataset.openCase;
  const item=caseSamples.find(entry=>entry.id===id);
  if(item){
    caseDetailReturn={page:'cases',useCurrentList:true};
    showCaseDetails(item);
  }
});
function showUnavailableCase(){
  if(embeddedMode&&parent!==window){
    parent.postMessage({type:'intellibox:case-unavailable'},location.origin);
    return;
  }
  showCaseSnackbar('This case is unavailable in the current prototype.');
}
function showCaseDetails(item){
  if(item.id!==cancellationCaseId){
    showUnavailableCase();
    return;
  }
  if(!openedCases.includes(item.id)){
    const populateDemoList=openedCases.length===0;
    openedCases.unshift(item.id);
    if(populateDemoList){
      const examples=caseSamples.filter(entry=>entry.id!==item.id).slice(0,11);
      openedCases.push(...examples.map(entry=>entry.id));
    }
  }
  activeCaseId=item.id;
  const returnPage=caseDetailReturn?.page||'cases';
  caseDetailBack.querySelector('span').textContent='Back to '+caseReturnPageNames[returnPage];
  caseAuditVisible=false;
  renderOpenedCases();
  document.getElementById('caseSummaryWhy').open=false;
  renderCaseDetails(item);
}
function showCaseListView(){
  finishCaseAiWriting();
  activeCaseId='';
  renderOpenedCases();
}
function renderOpenedCases(){
  casesWorkspace.hidden=Boolean(activeCaseId);
  caseDetailWorkspace.hidden=!activeCaseId;
  notifyOpenedCasesChanged();
}
window.intelliboxCaseStack={
  entries:()=>openedCases.map(id=>({id,current:id===activeCaseId,title:caseSamples.find(item=>item.id===id).title})),
  open(id){
    const item=caseSamples.find(entry=>entry.id===id);
    if(!item||!openedCases.includes(id))return;
    if(!activeCaseId)caseDetailReturn={page:'cases',useCurrentList:true};
    showCaseDetails(item);
    if(item.id===activeCaseId)caseWorkspaceTitle.focus({preventScroll:true});
  },
  close(id){
    const index=openedCases.indexOf(id);
    if(index<0)return;
    openedCases.splice(index,1);
    notifyOpenedCasesChanged();
    if(activeCaseId===id)showCaseListView();
  },
  list(){
    showCaseListView();
    caseListSearch.focus();
  }
};
function setCaseDetailPane(audit){
  caseAuditVisible=audit;
  caseDetailsTab.setAttribute('aria-selected',String(!audit));
  caseAuditTab.setAttribute('aria-selected',String(audit));
  caseDetailsTab.tabIndex=audit?-1:0;
  caseAuditTab.tabIndex=audit?0:-1;
  document.getElementById('caseDetailsPane').hidden=audit;
  document.getElementById('caseAuditPane').hidden=!audit;
}
caseDetailsTab.addEventListener('click',()=>setCaseDetailPane(false));
caseAuditTab.addEventListener('click',()=>setCaseDetailPane(true));
caseDetailsTab.parentElement.addEventListener('keydown',event=>{
  if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
  event.preventDefault();
  setCaseDetailPane(event.key==='Home'?false:event.key==='End'?true:!caseAuditVisible);
  (caseAuditVisible?caseAuditTab:caseDetailsTab).focus();
});
let caseSummaryKey;
let caseSummaryTimer;
function renderCaseSummary(key,summary,insight){
  if(caseSummaryKey===key)return;
  caseSummaryKey=key;
  clearTimeout(caseSummaryTimer);
  const title=document.getElementById('caseAssistantTitle');
  const content=document.getElementById('caseSummaryContent');
  const recommendation=document.getElementById('caseSummaryRecommendation');
  title.textContent='AI summarizing…';
  content.hidden=true;
  recommendation.hidden=true;
  document.getElementById('caseSummaryWhy').open=false;
  function showSummary(){
    title.textContent='Case insights';
    document.getElementById('caseSummaryText').textContent=summary;
    content.hidden=false;
    const value=document.getElementById('caseRecommendationValue');
    value.textContent=insight.action;
    value.dataset.tone=insight.tone;
    document.getElementById('caseConfidenceValue').textContent=insight.confidence+'%';
    document.getElementById('caseWhyPreview').textContent=insight.reasons[0];
    document.getElementById('caseWhyReasons').replaceChildren(...insight.reasons.map(reason=>{
      const paragraph=document.createElement('p');
      paragraph.textContent=reason;
      return paragraph;
    }));
    recommendation.hidden=false;
  }
  if(reducedEmailMotion.matches)showSummary();
  else caseSummaryTimer=setTimeout(showSummary,1400);
}
function renderAiSummaryTags(target,category,subcategory,email){
  const fields=[['Category',category],['Subcategory',subcategory],['Sentiment',email?.sentiment||'Neutral'],['Urgency',email?.urgency||'Normal']];
  target.innerHTML=fields.map(([label,value])=>{
    const classification=label==='Category'||label==='Subcategory';
    return `<div><dt>${label}</dt><dd><span class="${classification?'case-table-classification':'case-chip'}" data-tone="${caseTagTones[value]||'gray'}">${classification?'<img src="Icon/cube 3D.svg" alt="">':''}${safeEmailPreview(value)}</span></dd></div>`;
  }).join('');
}
function hasCancellationRecommendation(item,status){
  return item.id===cancellationCaseId&&status==='Pending approval';
}
function mockCaseRecommendation(item,source,status){
  const recommend=(action,confidence,tone,...reasons)=>({action,confidence,tone,reasons});
  if(hasCancellationRecommendation(item,status)){
    return recommend('Approve',90,'green','The order reference matched. The order is still unmatched and eligible for cancellation.',
      'Joseph marked the original email as high importance. Verify the order status before confirming the cancellation.');
  }
  if(status==='SLA breached')return recommend('Review delay',85,'amber','The case exceeded its service deadline. Check the timeline to identify where it stalled.');
  if(caseListGroups.Completed.includes(status)||status==='Rejected'){
    return recommend('Review outcome',95,'gray','The case is already closed. Review the recorded outcome and email thread if you need to follow up.');
  }
  if(status==='Sent to client')return recommend('Monitor for reply',90,'blue','A response has been sent. Check the thread for any follow-up.');
  if(status==='Escalated')return recommend('Review escalation',82,'amber','The case has been escalated for human review. Check what triggered the escalation before taking action.');
  if(status==='Expired')return recommend('Check for a new request',80,'amber','The original case has expired. Check whether the customer still needs assistance.');
  if(status==='AI processing')return recommend('Wait for analysis',75,'blue','Automated processing is still underway. Review the result before responding.');
  const subcategory=source&&classifyInboxItem(source)[1];
  if(subcategory==='Instruction receipt'){
    return recommend('Reply',88,'blue','The sender is asking whether the instruction was received. Acknowledge receipt and tell them if anything else is needed.');
  }
  if(status==='Pending approval'||subcategory==='Cancellation'){
    return recommend('Verify before deciding',72,'amber','The request needs an approval decision. Verify the instruction and current order status before approving or rejecting it.');
  }
  const manualCheck=mailReviewTypes[subcategory];
  if(manualCheck)return recommend('Review manually',80,'amber',...manualCheck.slice(1));
  return recommend('Review case',70,'blue','Check the case context and original email to determine the next action.');
}
function mockCaseSummary(item,emails,status){
  if(hasCancellationRecommendation(item,status))return 'Joseph requested urgent cancellation of trade order 132532327.';
  const nextStep={
    'Pending approval':'Verify the request and order reference before approving the draft.',
    'Pending manual resolution':'Review the request and decide how to resolve it before sending a response.',
    'AI processing':'The case is still being processed. Review the result when it becomes available.',
    'Sent to client':'A response has been sent. Check the thread for any follow-up.',
    Resolved:'The case is marked resolved. The thread is available for reference.',
    'Resolved by rejection':'The case was closed by rejection. Review the audit history for the recorded outcome.',
    'SLA breached':'The case exceeded its service deadline. Review the timeline for the recorded events.',
    Rejected:'The case was rejected. Check the audit history before taking further action.',
    Escalated:'The case has been escalated for manual review.',
    Expired:'The case has expired. Check whether a new request is needed.'
  };
  const context=item.id===cancellationCaseId
    ? 'Joseph requested urgent cancellation of trade order 132532327. The draft records the order as unmatched.'
    : emails[0]
      ? `The linked email from ${emails[0].sender} concerns “${emails[0].title}”.`
      : item.body;
  const sourceEmail=emails.find(email=>email.id===cancellationEmailId?email:undefined);
  const urgencyReason=sourceEmail?.importance==='High'
    ? caseListGroups['Pending actions'].includes(status)
      ? 'Urgency is high because Joseph marked the email as high importance.'+
        (Date.now()-cancellationEmailDate>48*60*60*1000?' The request is also more than 24 hours past its review deadline.':'')
      : 'Joseph marked the original email as high importance.'
    : '';
  const action=item.approvedDraft?'The response was approved and marked as sent to Joseph Tan.':nextStep[status]||`Current status: ${status}.`;
  return [context,urgencyReason,action].filter(Boolean).join(' ');
}
const caseEmployeeProfiles={
  'joseph.tan@sc.com':['Joseph Tan','Manager, Data Solution','IT-TPS-CT GCNA','SCT(CN),16/F','avatar/profile_3.png'],
  'kingston.johnson@sc.com':['Kingston Johnson','Head, Application Platform','IT-Proj-IC-TA SE Msg Platform','Standard Chartered @ Changi, 4/F','avatar/profile_2.png'],
  'sara.liu@sc.com':['Sara Liu','Senior Experience Designer','IT-Proj-IC-TA SE App Platform','Tianjin SCC, 2/F'],
  'carlsson.chee@sc.com':['Carlsson Chee','Design Director','IT-Proj-IC-TA Msg Platform','Standard Chartered @ Changi, 4/F','avatar/profile_1.png']
};
const caseEmployeeCard=document.getElementById('caseEmployeeCard');
let caseEmployeeTrigger;
let caseEmployeeTimer;
function hideCaseEmployeeCard(){
  clearTimeout(caseEmployeeTimer);
  caseEmployeeTrigger?.removeAttribute('aria-describedby');
  caseEmployeeTrigger=null;
  caseEmployeeCard.hidePopover();
}
function scheduleCaseEmployeeCard(trigger){
  if(trigger===caseEmployeeTrigger)return;
  hideCaseEmployeeCard();
  caseEmployeeTrigger=trigger;
  caseEmployeeTimer=setTimeout(()=>{
    if(!trigger.isConnected||!trigger.getClientRects().length){hideCaseEmployeeCard();return}
    const address=trigger.dataset.caseEmployee;
    const [name,role,team,location,avatar]=caseEmployeeProfiles[address.toLowerCase()] || [address];
    const initials=name.split(' ').map(word=>word[0]).slice(0,2).join('');
    caseEmployeeCard.innerHTML=`<span class="case-avatar" aria-hidden="true">${avatar?`<img src="${avatar}" alt="">`:initials}</span>
      <div class="case-employee-details">
        <strong>${safeEmailPreview(name)}</strong>
        ${team&&role?`<div class="case-employee-job"><p>${team}</p><p>${role}</p></div>`: ''}
        <div class="case-employee-contact">
          <span><img src="Icon/mail envelope closed.svg" alt="">${safeEmailPreview(address)}</span>
          ${location?`<span><img src="Icon/map navigation pin location.svg" alt="">${location}</span>`: ''}
        </div>
      </div>`;
    trigger.setAttribute('aria-describedby','caseEmployeeCard');
    caseEmployeeCard.showPopover();
    const bounds=trigger.getBoundingClientRect();
    const {offsetWidth,offsetHeight}=caseEmployeeCard;
    const below=bounds.bottom+8+offsetHeight<=innerHeight;
    const top=below?bounds.bottom+8:bounds.top-offsetHeight-8;
    const left=Math.max(8,Math.min(bounds.left,innerWidth-offsetWidth-8));
    const arrow=Math.max(14,Math.min(bounds.left+bounds.width/2-left,offsetWidth-14));
    caseEmployeeCard.dataset.placement=below?'below':'above';
    caseEmployeeCard.style.top=`${Math.max(8,top)}px`;
    caseEmployeeCard.style.left=`${left}px`;
    caseEmployeeCard.style.setProperty('--case-employee-arrow',`${arrow}px`);
  },1000);
}
for(const type of ['pointerover','focusin']){
  document.addEventListener(type,event=>{
    const trigger=event.target.closest('[data-case-employee]');
    if(trigger)scheduleCaseEmployeeCard(trigger);
  });
}
for(const type of ['pointerout','focusout']){
  document.addEventListener(type,event=>{
    if(!caseEmployeeTrigger?.contains(event.target)||caseEmployeeTrigger.contains(event.relatedTarget))return;
    hideCaseEmployeeCard();
  });
}
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&caseEmployeeTrigger)hideCaseEmployeeCard()});
window.addEventListener('resize',hideCaseEmployeeCard);
document.addEventListener('scroll',hideCaseEmployeeCard,true);
function caseEmailLink(address){
  const text=safeEmailPreview(address);
  return `<a class="case-email-address" href="mailto:${safeEmailPreview(encodeURIComponent(address).replace('%40','@'))}" data-case-employee="${text}">${text}</a>`;
}
function caseCcLinks(contacts){
  return contacts.map(({name,address})=>`${safeEmailPreview(name)} &lt;${caseEmailLink(address)}&gt;`).join('; ');
}
function renderOriginalEmailBody(body,original,{showAddresses=true}={}){
  const disclaimer=caseUi.caseEmailDisclaimer.textContent.trim();
  return `<div class="case-original-email">
      ${original&&showAddresses?`<div class="case-thread-addresses"><div><b>To:</b> ${caseCcLinks([{name:'Kingston Johnson',address:original.to}])}</div><div><b>Cc:</b> ${caseCcLinks(original.cc)}</div></div>`:''}${original?.importance==='High'?'<p class="case-thread-importance"><svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.2" aria-hidden="true"><path d="M6 3.5a2 2 0 1 1 4 0l-.8 5.2a1.2 1.2 0 0 1-2.4 0z"/><circle cx="8" cy="12.8" r="1"/></svg><span>This message is high importance.</span></p>':''}<p>${safeEmailPreview(body)}</p>
      ${original?`<p>Get <a href="https://aka.ms/GetOutlookForMac">Outlook for Mac</a></p>
        <footer class="case-email-disclaimer"><p>${safeEmailPreview(disclaimer)}</p><p>${safeEmailPreview(disclaimer.split(' via our public website.')[0])}</p></footer>`:''}</div>`;
}
function renderCaseDetails(item){
  const status=displayCaseStatus(item);
  const emails=inboxSamples.filter(email=>email.linked===item.id);
  originalCaseEmailButton.hidden=!emails.length;
  const [category,subcategory]=caseTableClassification(item);
  const referenceCancellation=item.id===cancellationCaseId;
  const created=referenceCancellation?new Date(cancellationEmailDate):threadMessageDate(item.age,false);
  const updated=emailRecordDate(item);
  const formatDate=date=>`${fullActivityDateFormat.format(date)} · ${caseUpdatedTimeFormat.format(date)}`;
  document.getElementById('caseDetailTitle').textContent=item.id;
  const tag=document.getElementById('caseDetailStatus');
  tag.textContent=status;
  tag.dataset.statusIcon=statusIcon(status);
  document.getElementById('caseDetailCreated').textContent=formatDate(created);
  document.getElementById('caseDetailUpdated').textContent=formatDate(updated);
  renderAiSummaryTags(document.getElementById('caseDetailRouting'),category,subcategory,emails[0]);
  const summary=mockCaseSummary(item,emails,status);
  const insight=mockCaseRecommendation(item,emails[0],status);
  renderCaseSummary(`${item.id}:${status}:${summary}:${insight.action}`,summary,insight);
  const messageMarkup=(subject,sender,body,date=updated,original)=>`<details open>
    <summary><span>${safeEmailPreview(subject)}</span><span class="case-thread-date"><span class="case-thread-count">1 msg</span><time datetime="${date.toISOString()}">${formatDate(date)}</time></span></summary>
    <div class="case-thread-message"><span class="case-avatar"${original?' tabindex="0" data-case-employee="Joseph.Tan@sc.com" aria-label="Joseph Tan, employee information"':' aria-hidden="true"'}>${original?`<img src="${caseEmployeeProfiles['joseph.tan@sc.com'][4]}" alt="">`:safeEmailPreview(sender.split(' ').slice(0,2).map(word=>word[0]).join('').toUpperCase())}</span>
      <div><strong class="case-thread-sender">${safeEmailPreview(sender)}</strong>
      ${renderOriginalEmailBody(body,original)}</div>
    </div></details>`;
  const thread=emails.length?emails.map(email=>
    sentThreadReplies(email).map(reply=>
      messageMarkup(mailSubject(reply.title,reply.origin),reply.sender,reply.body,emailRecordDate(reply))
    ).join('')+messageMarkup(mailSubject(email.title,email.origin),email.sender,email.body,emailRecordDate(email),email.id===cancellationEmailId?email:undefined)
  ).join(''):messageMarkup(caseSubject(item),'Case notes',item.body);
  document.getElementById('caseThreadMessages').innerHTML=thread;
  const inPreview=caseQuickView.open;
  const previewDraft=inPreview?caseDrafts.get(item.id):null;
  const reviewingEmail=reviewingMailId&&inboxSamples.find(email=>email.id===reviewingMailId);
  mailReviewForm.hidden=!inPreview||!reviewingEmail||Boolean(reviewingEmail.manuallyReviewed);
  mailReviewActions.hidden=mailReviewForm.hidden;
  if(!mailReviewForm.hidden)updateMailReviewAvailability();
  caseApprovalDraft.hidden=inPreview
    ?Boolean(reviewingMailId||caseQuickSentEmail)||!previewDraft
    :!caseListGroups['Pending actions'].includes(status);
  const showRecipient=Boolean(previewDraft?.mailAction)&&!caseApprovalDraft.hidden;
  caseDraftRecipientField.hidden=!showRecipient;
  caseDraftTo.disabled=!showRecipient;
  caseDraftTo.required=showRecipient;
  if(showRecipient)caseDraftTo.value=previewDraft.recipient||'';
  caseWorkspaceTitle.textContent=caseSubject(item);
  const sourceEmail=emails[0];
  document.getElementById('caseOriginalEnvelopeDetails').hidden=!sourceEmail;
  if(sourceEmail){
    const from=referenceCancellation?caseCcLinks([cancellationRequester]):caseEmailLink(emailSenderAddress(sourceEmail));
    const to=referenceCancellation?caseCcLinks([cancellationResponder]):caseEmailLink(displayMailbox(sourceEmail.to||emailRecipient(sourceEmail)));
    const cc=sourceEmail.cc?.length?caseCcLinks(sourceEmail.cc):'—';
    document.getElementById('caseOriginalEnvelope').innerHTML=`<dt>From</dt><dd>${from}</dd><dt>To</dt><dd>${to}</dd><dt>Cc</dt><dd>${cc}</dd>`;
  }
  document.getElementById('caseDraftEnvelopeDetails').hidden=caseApprovalDraft.hidden||!referenceCancellation;
  caseDraftActions.hidden=caseApprovalDraft.hidden;
  caseDraftResize.hidden=caseApprovalDraft.hidden;
  if(!caseApprovalDraft.hidden){
    if(!caseDrafts.has(item.id))caseDrafts.set(item.id,referenceCancellation?emptyCaseReplyDraft(item):{
      subject:`Re: ${emails[0]?.title||item.title}`,
      body:`Hello,\n\nWe’ve received your request and are reviewing case ${item.id}. We’ll follow up once the review is complete.\n\n${cancellationResponder.name}`
    });
    const draft=caseDrafts.get(item.id);
    const disposition=cancellationDecision[draft.intent];
    const fullCancellation=!inPreview&&referenceCancellation;
    caseDraftReject.hidden=inPreview;
    document.getElementById('caseDraftRejectLabel').textContent=fullCancellation?'Reject & Send':'Reject';
    caseAiWrite.hidden=inPreview?draft.mailAction==='forward'||Boolean(disposition)||Boolean(visibleMailAiDraft):!referenceCancellation;
    caseDraftBody.closest('label').hidden=inPreview&&Boolean(visibleMailAiDraft);
    document.getElementById('caseDraftSendLabel').textContent=inPreview?(disposition?.label||'Send'):'Approve & Send';
    caseDraftSend.classList.toggle('case-action-danger',inPreview&&draft.intent==='reject-cancellation');
    caseDraftSubject.value=draft.subject;
    caseDraftSubject.readOnly=inPreview?draft.mailAction!=='forward':referenceCancellation||Boolean(disposition);
    caseDraftBody.value=draft.body;
    updateCaseSendAvailability();
    caseDraftBody.placeholder=fullCancellation
      ? (draft.intent==='reject-cancellation'?'Write a reply declining the cancellation':'Write a reply confirming the cancellation')
      : '';
    const metadata=[
      ['Period','—'],
      ['Ready for review since',formatDate(created)],
      ['ID','OPS-'+item.id+'-'+created.toISOString().slice(0,19).replace(/[-:]/g,'')]
    ];
    document.getElementById('caseDraftMetadata').innerHTML=metadata.map(([label,value])=>
      `<dt>${label}</dt><dd>${value}</dd>`
    ).join('');
  }
  document.getElementById('caseDetailNotice').textContent=item.approvedDraft?'':item.decision||'';
  setCaseDetailPane(caseAuditVisible);
}
function updateCaseSendAvailability(){
  const emptyBody=!caseDraftBody.value.trim();
  caseDraftSend.disabled=caseAiWriting||emptyBody||(!caseDraftTo.disabled&&!caseDraftTo.value.trim());
  const rejectsAndSends=!caseQuickView.open&&activeCaseId===cancellationCaseId;
  caseDraftReject.disabled=caseAiWriting||(rejectsAndSends&&emptyBody);
}
caseApprovalDraft.addEventListener('input',event=>{
  if(event.target!==caseDraftBody&&event.target!==caseDraftSubject&&event.target!==caseDraftTo)return;
  updateCaseSendAvailability();
  caseDrafts.set(activeCaseId,{...caseDrafts.get(activeCaseId),subject:caseDraftSubject.value,body:caseDraftBody.value,...(!caseDraftTo.disabled?{recipient:caseDraftTo.value}:{})});
});
function caseDraftRecipient(item){
  const source=inboxSamples.find(email=>email.id===caseDrafts.get(item.id)?.sourceEmailId)||linkedSourceEmail(item);
  return source?emailSenderAddress(source):'';
}
function decideCaseDraft(status,decision,send=status==='Sent to client'){
  const item=caseSamples.find(entry=>entry.id===activeCaseId);
  if(!item||!caseListGroups['Pending actions'].includes(item.status))return;
  const savedAt=Date.now();
  const changes={status,decision,savedAt};
  if(send){
    if(!caseDraftSubject.value.trim()||!caseDraftBody.value.trim())return;
    changes.approvedDraft={
      subject:caseDraftSubject.value.trim(),body:caseDraftBody.value.trim(),
      sender:cancellationResponder.name,senderAddress:cancellationResponder.address
    };
    const recipient=caseDraftRecipient(item);
    if(item.id===cancellationCaseId)changes.approvedDraft.cc=cancellationCc.map(contact=>contact.address);
    const sentEmail={id:`compose-case-${item.id}-${savedAt}`,...changes.approvedDraft,status:'Sent',recipient,linked:item.id,sourceEmailId:caseDrafts.get(item.id)?.sourceEmailId||linkedSourceEmail(item)?.id,savedAt};
    caseApprovedEmails.unshift(sentEmail);
    if(caseQuickView.open){
      caseQuickSentEmail=sentEmail;
      visibleMailAiDraft=undefined;
      renderSuggestedMailDraft();
    }
  }
  Object.assign(item,changes);
  caseDecisions[item.id]=changes;
  renderApprovalList();
  if(caseQuickView.open){
    renderCaseDetails(item);
    if(!selectSentCaseReply(caseQuickSentEmail))renderCaseWorkspace();
  }else{
    setupCasesList(caseListCategory);
    showCaseDetails(item);
  }
  if(send)showCaseSnackbar('Email approved and sent',true,'top');
}
function sendCasePreviewMail(){
  const item=caseSamples.find(entry=>entry.id===activeCaseId);
  const draft=caseDrafts.get(activeCaseId);
  const body=caseDraftBody.value.trim();
  if(!item||!draft?.mailAction||!body||caseQuickSentEmail)return;
  const sentEmail={id:'compose-'+crypto.randomUUID(),status:'Sent',
    sender:cancellationResponder.name,senderAddress:cancellationResponder.address,
    recipient:caseDraftTo.value.trim(),subject:caseDraftSubject.value.trim(),body,
    sourceEmailId:draft.sourceEmailId,linked:item.id,savedAt:Date.now()};
  recordComposedEmail(sentEmail);
  caseQuickSentEmail=sentEmail;
  visibleMailAiDraft=undefined;
  renderSuggestedMailDraft();
  renderCaseDetails(item);
  if(!selectSentCaseReply(sentEmail))renderCaseWorkspace();
  showCaseSnackbar('Email sent',true,'top');
}
function submitCancellationDecision(intent){
  if(caseAiWriting)return;
  const draft=caseDrafts.get(activeCaseId);
  const previousIntent=draft?.intent||'approve-cancellation';
  if(previousIntent!==intent){
    const item=caseSamples.find(entry=>entry.id===activeCaseId);
    const email=item&&linkedSourceEmail(item);
    if(!email)return;
    const {subject}=buildMailResponse(email,intent);
    caseDrafts.set(activeCaseId,{subject,body:'',intent});
    caseAiWriteAttempts=0;
    caseAiWriteLabel.textContent='Draft with AI';
    renderCaseDetails(item);
    caseDraftBody.focus();
    return;
  }
  if(!caseApprovalDraft.reportValidity())return;
  const {status,decision}=cancellationDecision[intent];
  decideCaseDraft(status,decision,true);
}
caseApprovalDraft.addEventListener('submit',event=>{
  event.preventDefault();
  if(caseAiWriting)return;
  const intent=caseQuickView.open?caseDrafts.get(activeCaseId)?.intent:'approve-cancellation';
  if(cancellationDecision[intent]){
    submitCancellationDecision(intent);
    return;
  }
  if(caseQuickView.open){
    if(caseApprovalDraft.reportValidity())sendCasePreviewMail();
    return;
  }
  if(caseApprovalDraft.reportValidity())decideCaseDraft('Sent to client','Response approved and added to the case in this preview.');
});
caseDraftReject.addEventListener('click',()=>{
  if(caseAiWriting)return;
  if(!caseQuickView.open&&activeCaseId===cancellationCaseId){
    submitCancellationDecision('reject-cancellation');
    return;
  }
  decideCaseDraft('Resolved by rejection','Draft response rejected.');
});
function setupCaseWorkspace(view,category,folder='inbox'){
  if(caseQuickView.open)closeCaseQuickView(false);
  caseViewMode=view;
  activeMailFolder=folder;
  const inbox=view==='casebox';
  caseboxView.classList.toggle('is-mail-workspace',inbox);
  mailWorkspace.hidden=!inbox;
  casesWorkspace.hidden=inbox;
  caseDetailWorkspace.hidden=true;
  if(!inbox){
    if(category?.startsWith('list:')){
      setupCasesList();
      caseListSearch.value=category.slice(5);
      renderCasesList();
    }else setupCasesList(category);
    return;
  }
  compactMailListScroll=0;
  caseMailFolders.hidden=!inbox;
  caseFolderToggle.hidden=!inbox;
  setMailFolderMenu(false);
  for(const button of caseMailFolders.querySelectorAll('[data-mail-folder]')){
    if(button.dataset.mailFolder===folder)button.setAttribute('aria-current','page');
    else button.removeAttribute('aria-current');
  }
  caseSelectedId=inbox?'':category||'';
  caseSelectedMessage=0;
  caseUi.caseQueueTitle.textContent=inbox?mailFolderNames[folder]:'Cases';
  caseUi.caseSearch.value=caseSamples.some(item=>item.id===category)?category:'';
  caseUi.caseSearch.placeholder=inbox?`Search ${({sent:'sent mail',bounced:'bounced mail'})[folder]||mailFolderNames[folder].toLowerCase()}`:'Search cases';
  caseUi.caseSearch.setAttribute('aria-label',caseUi.caseSearch.placeholder);
  const filters=inbox?(folder==='inbox'?['New','Unresolved','Replied']:[]):[...statuses.map(item=>item.label),...Object.keys(caseStatusGroups)];
  const emails=inbox?mailFolderItems():[];
  const categories=emails.map(classifyInboxItem);
  const groups=[filterGroup('status','Status',filters,category)];
  if(inbox){
    groups.push(filterGroup('urgency','Urgency',['High','Normal','Low']));
    groups.push(filterGroup('category','Category',[...new Set(categories.map(([value])=>value))]));
  }
  caseFilterPanel.querySelector('.case-filter-fields').innerHTML=groups.join('');
  appliedEmailFilters=new FormData();
  caseAdvancedToggle.hidden=!inbox;
  setCaseFilterOpen(false);
  caseUi.caseboxContext.hidden=!category||category==='all'||filters.includes(category)||Boolean(caseUi.caseSearch.value);
  caseUi.caseboxContext.textContent=caseUi.caseboxContext.hidden?'':`Opened from ${category}`;
  renderCaseWorkspace();
  caseUi.caseQueueItems.scrollTop=0;
}
caseMailFolders.addEventListener('click',event=>{
  const folder=event.target.closest('[data-mail-folder]')?.dataset.mailFolder;
  if(!folder)return;
  const fromMenu=caseMailFolders.classList.contains('is-menu-open');
  if(folder!==activeMailFolder)setupCaseWorkspace('casebox',undefined,folder);
  if(fromMenu){
    setMailFolderMenu(false);
    caseFolderToggle.focus();
  }
});
function matchesAdvancedEmailFilters(item){
  const filters=appliedEmailFilters;
  const selected=(key,value)=>!filters.has(key)||filters.getAll(key).includes(value);
  const range=filters.get('range');
  const date=emailRecordDate(item).toLocaleDateString('sv-SE');
  const matchesDate=!range||(range==='custom'
    ?date>=filters.get('from')&&date<=filters.get('to')
    :date>=localDayOffset(new Date(),1-Number(range)).toLocaleDateString('sv-SE'));
  const content=[item.body,...sentThreadReplies(item).map(reply=>reply.body)].join(' ').toLowerCase();
  return matchesDate&&selected('subcategory',classifyInboxItem(item)[1])&&selected('fromSender',item.sender)&&selected('recipient',emailRecipient(item))&&
    item.title.toLowerCase().includes(filters.get('subject')||'')&&content.includes(filters.get('content')||'')&&
    (!filters.has('attachments')||emailAttachments.has(item.id))&&
    (!filters.has('replied')||(item.status==='Replied'||sentThreadReplies(item).length>0));
}
function threadMessageDate(age,isReply){
  const date=localDayOffset(new Date(),-age);
  date.setHours(isReply?14:9,0,0,0);
  return date;
}
function emailRecordDate(item,isReply=false){
  return item.savedAt?new Date(item.savedAt):threadMessageDate(item.age,isReply);
}
function renderCaseWorkspace(notice=''){
  const inbox=caseViewMode==='casebox';
  const receivedMail=activeMailFolder==='inbox';
  const query=caseUi.caseSearch.value.trim().toLowerCase();
  const checked=[...caseFilterPanel.querySelectorAll(':checked')];
  const values=key=>checked.filter(input=>input.name===key).map(input=>input.value);
  const activeStatuses=values('status').map(status=>status==='Unresolved'?'Read':status);
  const matches=(key,value)=>{const options=values(key);return !options.length||options.includes(value)};
  const filterCount=checked.length+new Set([...appliedEmailFilters.keys()].map(key=>['from','to'].includes(key)?'range':key)).size;
  caseClearFilters.hidden=!filterCount;
  const filterLabel=filterCount?`Filters (${filterCount})`:'Filters';
  caseFilterToggle.querySelector('span').textContent=filterLabel;
  caseFilterToggle.setAttribute('aria-label',filterLabel);
  caseFilterToggle.title=filterLabel;
  const items=inbox?mailFolderItems():caseSamples;
  caseVisibleItems=items.filter(item=>{
    const matchesStatus=!activeStatuses.length||activeStatuses.some(status=>(caseStatusGroups[status]||[status]).includes(item.status))||
      (inbox&&activeStatuses.includes('New')&&item.status==='Read'&&item.id===caseSelectedId);
    const [category]=inbox?classifyInboxItem(item):[];
    return matchesStatus&&matches('urgency',item.urgency)&&matches('category',category)&&
      (!inbox||matchesAdvancedEmailFilters(item))&&
      [item.id,item.title,item.sender,inbox?emailSenderAddress(item):null,item.recipient,item.body,item.linked,item.origin,item.senderType].some(value=>value?.toLowerCase().includes(query));
  });
  const selected=caseVisibleItems.find(item=>item.id===caseSelectedId)||(!inbox?caseVisibleItems[0]:undefined);
  caseSelectedId=selected?.id||'';
  caseboxView.classList.toggle('is-reading-mail',inbox&&Boolean(selected));
  const threadSource=inbox&&(receivedMail?selected:activeMailFolder==='sent'?
    inboxSamples.find(email=>email.id===(selected?.sourceEmailId||selected?.id)):null);
  const threadReplies=threadSource?sentThreadReplies(threadSource):[];
  const reply=receivedMail&&caseSelectedMessage>0?threadReplies[caseSelectedMessage-1]:null;
  const sentReplyIndex=activeMailFolder==='sent'&&threadSource?
    threadReplies.findIndex(entry=>entry.id===selected.id||(!entry.id&&selected.id===threadSource.id)):-1;
  const replyIndex=reply?caseSelectedMessage-1:sentReplyIndex;
  const previousMessages=replyIndex<0?[]:[...threadReplies.slice(replyIndex+1),threadSource];
  const message=reply||selected;
  caseUi.caseQueueCount.innerHTML=emphasizeNumericValues(`Showing ${caseVisibleItems.length} of ${items.length} ${inbox?(receivedMail?'email threads':'emails'):'cases'}`);
  const expandedThreads=new Set([...caseUi.caseQueueItems.querySelectorAll('details[open]')].map(thread=>thread.dataset.thread));
  caseUi.caseQueueItems.innerHTML=caseVisibleItems.map(item=>{
    const senderAddress=inbox?emailSenderAddress(item):'';
    const statusTag=item.status==='Read'?'':`<span class="case-status-label" data-status-icon="${statusIcon(item.status)}">${item.status}</span>`;
    const replies=inbox&&receivedMail?sentThreadReplies(item):[];
    const threadReply=replies.length>0;
    const open=expandedThreads.has(item.id);
    const attachment=inbox?emailAttachments.get(item.id):null;
    const row=`<button type="button" class="case-queue-row${attachment?' has-mail-attachment':''}" data-case-item="${item.id}" ${threadReply?`aria-expanded="${open}" aria-controls="thread-${item.id}"`:`aria-current="${item===selected}"`}>
      ${inbox?emailSenderAvatar(item.sender,senderAddress):''}
      <span class="case-row-copy"><span class="case-row-meta">${item.recipient?`To: ${safeEmailPreview(displayMailbox(item.recipient))}`:inbox?safeEmailPreview(senderAddress):item.id}</span><strong>${safeEmailPreview(inbox?mailSubject(item.title,item.origin):item.title)}</strong><span class="case-row-meta">${safeEmailPreview(item.body)}</span></span>
      <span class="case-row-end">${statusTag}<span class="case-row-meta">${activityDateFormat.format(emailRecordDate(item))}</span></span>
    </button>`;
    if(!inbox)return row;
    return `<div class="case-email-item">${row}${threadReply?`<details id="thread-${item.id}" data-thread="${item.id}"${open?' open':''}>
      <summary aria-label="Toggle email thread"><img src="Icon/arrow chevron nav right forward.svg" alt=""></summary>
      ${[...replies.map((message,index)=>({message,index:index+1})),{message:item,index:0}].map(({message,index})=>{
        const date=emailRecordDate(message);
        return `<button type="button" class="case-queue-row case-thread-message" data-case-item="${item.id}" data-message="${index}" aria-current="${item===selected&&index===caseSelectedMessage}">
          <span class="case-row-copy"><span class="case-row-meta">${safeEmailPreview(emailSenderAddress(message))}</span><strong>${safeEmailPreview(mailSubject(message.title,message.origin))}</strong><span class="case-row-meta">${safeEmailPreview(message.body)}</span></span>
          <time class="case-row-meta" datetime="${date.toISOString()}">${activityDateFormat.format(date)} · ${emailTimeFormat.format(date)}</time>
        </button>`;
      }).join('')}
    </details>`:''}${attachment?`<button class="case-link-action mail-attachment-open" type="button" data-mail-attachment="${item.id}" aria-label="Open attachment: ${safeEmailPreview(attachment.name)}" title="${safeEmailPreview(attachment.name)}"><img src="Icon/attachment paperclip.svg" alt=""></button>`:''}</div>`;
  }).join('');
  const bounced=activeMailFolder==='bounced'&&selected?.status==='Bounced';
  document.getElementById('caseResend').hidden=!bounced;
  caseUi.caseReaderActions.hidden=!inbox||!selected||selected.status==='Sent';
  const editingDraft=activeMailFolder==='drafts';
  const replyLabel=editingDraft?'Edit draft':'Reply';
  caseUi.caseReply.title=replyLabel;
  caseUi.caseReply.setAttribute('aria-label',replyLabel);
  caseUi.caseReply.querySelector('span').textContent=replyLabel;
  caseUi.caseReply.querySelector('img').src=editingDraft?'Icon/pencil edit.svg':'Icon/arrow reply.svg';
  const archived=activeMailFolder==='archive';
  const canReply=inbox&&Boolean(selected)&&!archived&&!bounced&&selected.status!=='Sent'&&!editingDraft;
  document.getElementById('caseMoreActions').hidden=!selected||!(receivedMail||archived||canReply||editingDraft);
  caseUi.caseReplyAll.hidden=!canReply;
  caseUi.caseForward.hidden=!canReply;
  const canSuggest=canReply&&receivedMail&&!reply;
  const linkedCaseForDecision=canSuggest&&caseSamples.find(item=>item.id===selected.linked);
  const canDecideCancellation=canSuggest&&selected.status!=='Replied'&&classifyInboxItem(selected)[1]==='Cancellation'&&
    (!linkedCaseForDecision||caseListGroups['Pending actions'].includes(displayCaseStatus(linkedCaseForDecision)));
  const primaryAction=canSuggest?primaryMailAction(selected,canDecideCancellation):'';
  mailReplyAndSend.hidden=primaryAction!=='reply';
  mailReviewAction.hidden=primaryAction!=='review';
  if(!mailReviewAction.hidden)mailReviewAction.textContent=mailReviewTypes[classifyInboxItem(selected)[1]][0];
  caseUi.caseReply.hidden=!canReply&&!editingDraft;
  mailApproveAndSend.hidden=!canDecideCancellation;
  mailRejectAndSend.hidden=!canDecideCancellation;
  caseUi.caseLinkAction.hidden=!receivedMail||archived||Boolean(selected?.linked);
  caseUi.caseArchive.hidden=!receivedMail&&!archived;
  caseUi.caseArchive.querySelector('span').textContent=archived?'Restore to Inbox':selected?.linked?'Unlink and archive':'Archive email';
  caseUi.caseArchive.querySelector('img').src=archived?'Icon/mail envelope closed.svg':'Icon/box 2d archive.svg';
  document.getElementById('caseMoreActionsMenu').hidePopover();
  caseUi.linkedCase.hidden=!selected?.linked;
  caseUi.viewLinkedCase.querySelector('span').textContent=selected?.linked||'';
  caseUi.caseLinkAction.setAttribute('aria-haspopup','dialog');
  const original=inbox&&!reply&&message?.id===cancellationEmailId?message:null;
  caseUi.caseEmailDisclaimer.hidden=!inbox||!selected||(Boolean(original)||previousMessages.some(email=>email.id===cancellationEmailId));
  const awaitingEmailSelection=inbox&&!selected&&caseVisibleItems.length>0;
  showEmailEmptyState(awaitingEmailSelection);
  caseUi.caseReaderTitle.parentElement.hidden=awaitingEmailSelection;
  caseUi.caseReaderSubject.textContent=(message&&inbox?mailSubject(message.title,message.origin):message?.title)||
    (caseVisibleItems.length?'Select an email':query||filterCount?'No matching results':inbox?`No ${({sent:'sent emails',bounced:'bounced emails',drafts:'drafts',archive:'archived emails'})[activeMailFolder]||'emails in the inbox'}`:'No cases');
  const selectedDate=message?emailRecordDate(message,activeMailFolder==='sent'):null;
  caseUi.caseReaderDate.textContent=selectedDate?fullActivityDateFormat.format(selectedDate):'';
  if(selectedDate&&inbox&&(message.savedAt||sentThreadReplies(selected).length)){
    caseUi.caseReaderDate.textContent+=` · ${emailTimeFormat.format(selectedDate)}`;
  }
  if(message&&inbox){
    const address=emailSenderAddress(message);
    const recipient=displayMailbox(message.to||emailRecipient(message));
    const to=`<span class="mail-recipient-label">To:</span> ${recipient.split(',').map(address=>address.trim()).filter(Boolean).map(caseEmailLink).join(', ')}`;
    const recipients=message.cc?.length
      ?`<details class="case-reader-recipients"><summary>${to}</summary><p><span class="mail-recipient-label">Cc:</span> ${caseCcLinks(message.cc)}</p></details>`
      :`<div class="case-reader-recipients">${to}</div>`;
    caseUi.caseReaderSender.innerHTML=`${emailSenderAvatar(message.sender,address)}
      <div class="case-reader-envelope">
        <div class="case-reader-from"><strong>${safeEmailPreview(caseEmployeeProfiles[address.toLowerCase()]?.[0]||message.sender)}</strong> <span>${address?caseEmailLink(address):''}</span></div>
        ${recipients}
      </div>`;
  }else{
    caseUi.caseReaderSender.textContent=message?`${message.id} · ${message.status}`:'';
  }
  if(original)caseUi.caseReaderBody.innerHTML=renderOriginalEmailBody(original.body,original,{showAddresses:false});
  else caseUi.caseReaderBody.textContent=message?.body||(!caseVisibleItems.length&&(query||filterCount)?'Try another search or filter.':'');
  if(previousMessages.length){
    const history=document.createElement('section');
    history.className='case-reader-history';
    history.setAttribute('aria-label','Previous messages');
    history.innerHTML=previousMessages.map(email=>{
      const date=emailRecordDate(email);
      const original=email.id===cancellationEmailId?email:undefined;
      return `<blockquote>
        <header><strong>${safeEmailPreview(mailSubject(email.title,email.origin))}</strong>
          <div>From: ${caseEmailLink(emailSenderAddress(email))} · <time datetime="${date.toISOString()}">${fullActivityDateFormat.format(date)} · ${emailTimeFormat.format(date)}</time></div>
        </header>
        ${renderOriginalEmailBody(email.body,original,{showAddresses:false})}
      </blockquote>`;
    }).join('');
    caseUi.caseReaderBody.append(history);
  }
  const readerAttachment=inbox&&emailAttachments.get(message?.id);
  mailReaderAttachment.hidden=!readerAttachment;
  if(readerAttachment){
    mailReaderAttachmentOpen.dataset.mailId=message.id;
    mailReaderAttachmentOpen.querySelector('span').textContent=readerAttachment.name;
  }
  caseUi.caseClassification.hidden=!inbox||!selected;
  if(inbox&&selected){
    const linkedCase=original?.linked===cancellationCaseId?caseSamples.find(item=>item.id===original.linked):null;
    const relatedEmails=linkedCase?inboxSamples.filter(email=>email.linked===linkedCase.id):[];
    const [category,subcategory]=linkedCase?caseTableClassification(linkedCase):classifyInboxItem(selected);
    renderAiSummaryTags(caseUi.caseClassificationFields,category,subcategory,relatedEmails[0]||selected);
  }
  caseUi.caseReaderNotice.textContent=notice;
}
caseUi.caseSearch.addEventListener('input',()=>renderCaseWorkspace());
caseUi.caseRefresh.addEventListener('click',()=>renderCaseWorkspace('List refreshed'));
caseUi.caseQueueItems.addEventListener('click',event=>{
  const attachmentButton=event.target.closest('[data-mail-attachment]');
  const summary=event.target.closest('details[data-thread] > summary');
  if(summary?.parentElement.open)return;
  if(summary)event.preventDefault();
  const item=attachmentButton?.parentElement.querySelector('[data-case-item]')||
    summary?.parentElement.previousElementSibling||event.target.closest('[data-case-item]');
  if(!item)return;
  const thread=item.nextElementSibling;
  const opensThread=thread instanceof HTMLDetailsElement;
  if(opensThread)thread.open=true;
  caseSelectedId=item.dataset.caseItem;
  caseSelectedMessage=opensThread?1:Number(item.dataset.message||0);
  if(compactMailLayout.matches)compactMailListScroll=caseUi.caseQueueItems.scrollTop;
  if(caseViewMode==='casebox'&&(activeMailFolder==='inbox'||activeMailFolder==='all')){
    const email=inboxSamples.find(email=>email.id===caseSelectedId);
    if(email?.status==='New')updateInboxEmail(email,{status:'Read'});
  }
  renderCaseWorkspace();
  if(attachmentButton&&openMailAttachment(attachmentButton.dataset.mailAttachment,attachmentButton))return;
  if(caseViewMode==='casebox'&&compactMailLayout.matches){
    caseboxView.querySelector('.case-reader-content').scrollTop=0;
    caseBackToMail.focus();
  }
  else caseUi.caseQueueItems.querySelector('[aria-current="true"]')?.focus({preventScroll:true});
});
mailAttachmentDialog.addEventListener('close',()=>{
  if(mailAttachmentUrl)URL.revokeObjectURL(mailAttachmentUrl);
  mailAttachmentUrl=undefined;
  mailAttachmentDownload.removeAttribute('href');
  const attachmentButton=mailAttachmentTrigger?.isConnected?mailAttachmentTrigger:
    caseUi.caseQueueItems.querySelector('[data-mail-attachment="'+openedMailAttachmentId+'"]');
  (attachmentButton?.getClientRects().length?attachmentButton:caseBackToMail).focus({preventScroll:true});
  mailAttachmentTrigger=undefined;
});
caseBackToMail.addEventListener('click',()=>{
  const id=caseSelectedId;
  const message=caseSelectedMessage;
  caseSelectedId='';
  caseSelectedMessage=0;
  renderCaseWorkspace();
  caseUi.caseQueueItems.scrollTop=compactMailListScroll;
  const previousRow=[...caseUi.caseQueueItems.querySelectorAll('[data-case-item]')].find(row=>
    row.dataset.caseItem===id&&row.dataset.message===String(message))||
    [...caseUi.caseQueueItems.querySelectorAll('[data-case-item]')].find(row=>row.dataset.caseItem===id);
  (previousRow||caseUi.caseSearch).focus({preventScroll:true});
});
caseUi.caseQueueItems.addEventListener('toggle',event=>{
  const thread=event.target;
  if(thread instanceof HTMLDetailsElement)thread.previousElementSibling?.setAttribute('aria-expanded',String(thread.open));
},true);
caseDetailBack.addEventListener('click',()=>{
  const destination=caseDetailReturn||{page:'cases'};
  caseDetailReturn=undefined;
  if(destination.page==='cases'){
    const caseId=activeCaseId;
    if(destination.useCurrentList)showCaseListView();
    else setupCasesList();
    (caseListRows.querySelector('[data-open-case="'+caseId+'"]')||caseListSearch).focus({preventScroll:true});
    return;
  }
  if(embeddedMode&&parent!==window){
    parent.postMessage({type:'intellibox:navigate',page:destination.page},location.origin);
    return;
  }
  if(destination.page==='casebox'){
    setupCaseWorkspace('casebox');
    caseUi.caseSearch.focus({preventScroll:true});
    return;
  }
  selectGlobalPage('dashboard');
  if(destination.page==='diagnostics')showView('diagnostics');
});
let caseQuickTrigger;
let caseQuickSentEmail;
let restoreCaseQuickDraft;
function closeCaseQuickView(restoreFocus=true){
  const sent=caseQuickSentEmail;
  caseQuickSentEmail=undefined;
  reviewingMailId=undefined;
  visibleMailAiDraft=undefined;
  renderSuggestedMailDraft();
  finishCaseAiWriting();
  caseAiWriteStatus.textContent='';
  caseQuickView.close();
  caseDetailWorkspace.hidden=true;
  caseWorkspaceHeading.append(caseDraftActions);
  casesWorkspace.after(caseDetailWorkspace);
  restoreCaseQuickDraft?.();
  restoreCaseQuickDraft=undefined;
  activeCaseId='';
  const trigger=caseQuickTrigger;
  caseQuickTrigger=null;
  if(!restoreFocus)return;
  if(sent?.sourceEmailId&&caseSelectedId===sent.sourceEmailId){
    caseUi.caseReaderTitle.focus({preventScroll:true});
    return;
  }
  (trigger?.getClientRects().length?trigger:caseUi.caseReaderTitle).focus({preventScroll:true});
}
function selectSentCaseReply(sent){
  if(!sent?.sourceEmailId||caseViewMode!=='casebox'||activeMailFolder!=='inbox')return false;
  const source=mailFolderItems().find(email=>email.id===sent.sourceEmailId);
  if(!source)return false;
  const replyIndex=sentThreadReplies(source).findIndex(reply=>reply.id===sent.id);
  if(replyIndex<0)return false;
  if(selectOriginalCaseEmail(source.id,replyIndex+1,{focus:false}))return true;
  caseUi.caseSearch.value='';
  resetEmailFilters();
  return selectOriginalCaseEmail(source.id,replyIndex+1,{focus:false});
}
function selectOriginalCaseEmail(id,messageIndex=0,{focus=true}={}){
  const item=mailFolderItems().find(email=>email.id===id);
  if(!item)return;
  caseSelectedId=item.id;
  caseSelectedMessage=messageIndex;
  renderCaseWorkspace();
  if(caseSelectedId!==id)return false;
  if(messageIndex){
    const thread=document.getElementById('thread-'+id);
    if(thread)thread.open=true;
  }
  caseUi.caseQueueItems.querySelector('[aria-current="true"]')?.scrollIntoView({block:'nearest'});
  if(focus)caseUi.caseReaderTitle.focus({preventScroll:true});
  return true;
}
function emptyCaseReplyDraft(item){
  const subject=linkedSourceEmail(item)?.title||item.title;
  return {subject:/^Re:/i.test(subject)?subject:'Re: '+subject,body:''};
}
function openCaseQuickView(id,trigger,draft){
  const item=caseSamples.find(entry=>entry.id===id);
  if(!item){showUnavailableCase();return}
  if(caseQuickView.open){caseWorkspaceTitle.focus();return}
  activeCaseId=id;
  caseQuickTrigger=trigger;
  caseAiWriteAttempts=0;
  caseAiWriteLabel.textContent='Draft with AI';
  if(draft?.mailAction||reviewingMailId){
    const previousDraft=caseDrafts.get(id);
    restoreCaseQuickDraft=()=>{
      if(previousDraft)caseDrafts.set(id,previousDraft);
      else caseDrafts.delete(id);
    };
  }
  caseDrafts.set(id,draft||emptyCaseReplyDraft(item));
  caseAuditVisible=false;
  caseQuickContent.append(caseDetailWorkspace);
  caseQuickActions.append(caseDraftActions);
  caseDetailWorkspace.hidden=false;
  caseQuickView.show();
  document.getElementById('caseSummaryWhy').open=false;
  if(cancellationDecision[draft?.intent])generatePreviewReply();
  renderCaseDetails(item);
  (visibleMailAiDraft||reviewingMailId?caseWorkspaceTitle:caseDraftBody).focus({preventScroll:true});
}
caseUi.viewLinkedCase.addEventListener('click',()=>{
  const id=caseUi.viewLinkedCase.textContent;
  if(id!==cancellationCaseId){showUnavailableCase();return}
  openCasebox(id,'cases');
});
document.getElementById('closeCaseQuickView').addEventListener('click',()=>closeCaseQuickView());
caseQuickView.addEventListener('cancel',event=>{event.preventDefault();closeCaseQuickView()});
document.getElementById('openCaseManagement').addEventListener('click',()=>{
  const id=activeCaseId;
  closeCaseQuickView(false);
  openCasebox(id===cancellationCaseId?id:'list:'+id,'cases');
});
originalCaseEmailButton.addEventListener('click',()=>{
  const item=caseSamples.find(entry=>entry.id===activeCaseId);
  const email=item&&linkedSourceEmail(item);
  if(!email)return;
  if(caseQuickView.open&&activeMailFolder==='inbox'){
    closeCaseQuickView(false);
    selectOriginalCaseEmail(email.id);
  }else{
    openCasebox(`mail:${email.id}`,'casebox');
  }
});
const caseQuickGutter=12;
const caseQuickHeader=caseQuickView.querySelector('.case-quick-header');
function positionCaseQuickView(left,top){
  const {width,height}=caseQuickView.getBoundingClientRect();
  const clamp=(value,size,viewport)=>Math.max(caseQuickGutter,Math.min(value,viewport-size-caseQuickGutter));
  caseQuickView.style.setProperty('--case-quick-left',clamp(left,width,innerWidth)+'px');
  caseQuickView.style.setProperty('--case-quick-top',clamp(top,height,innerHeight)+'px');
}
function setCaseQuickViewSize(width,height,right,bottom){
  const maxWidth=right-caseQuickGutter;
  const maxHeight=bottom-caseQuickGutter;
  const fit=(size,min,max)=>Math.max(Math.min(min,max),Math.min(size,max));
  const nextWidth=fit(width,380,maxWidth);
  const nextHeight=fit(height,320,maxHeight);
  caseQuickView.style.setProperty('--case-quick-width',nextWidth+'px');
  caseQuickView.style.setProperty('--case-quick-height',nextHeight+'px');
  positionCaseQuickView(right-nextWidth,bottom-nextHeight);
}
function resizeCaseQuickEdges(rect,x,y,direction){
  const west=direction.includes('w');
  const east=direction.includes('e');
  const north=direction.includes('n');
  const south=direction.includes('s');
  const axis=(start,end,delta,viewport,min,leading,trailing)=>{
    if(leading)return [Math.max(caseQuickGutter,Math.min(start+delta,end-Math.min(min,end-caseQuickGutter))),end];
    if(trailing)return [start,Math.min(viewport-caseQuickGutter,Math.max(end+delta,start+Math.min(min,viewport-caseQuickGutter-start)))];
    return [start,end];
  };
  const [left,right]=axis(rect.left,rect.right,x,innerWidth,380,west,east);
  const [top,bottom]=axis(rect.top,rect.bottom,y,innerHeight,320,north,south);
  caseQuickView.style.setProperty('--case-quick-width',(right-left)+'px');
  caseQuickView.style.setProperty('--case-quick-height',(bottom-top)+'px');
  positionCaseQuickView(left,top);
}
function bindCaseQuickDrag(handle,move){
  let drag;
  handle.addEventListener('pointerdown',event=>{
    if(!event.isPrimary||event.button!==0||(handle===caseQuickHeader&&event.target.closest('button')))return;
    drag={id:event.pointerId,x:event.clientX,y:event.clientY,rect:caseQuickView.getBoundingClientRect()};
    handle.setPointerCapture(event.pointerId);
  });
  handle.addEventListener('pointermove',event=>{
    if(drag?.id!==event.pointerId)return;
    move(drag.rect,event.clientX-drag.x,event.clientY-drag.y);
  });
  handle.addEventListener('lostpointercapture',()=>{drag=undefined});
}
for(const direction of ['n','s','e','w','ne','nw','se','sw']){
  const handle=document.createElement('span');
  handle.className='case-quick-edge';
  handle.dataset.edge=direction;
  handle.setAttribute('aria-hidden','true');
  caseQuickView.append(handle);
  bindCaseQuickDrag(handle,(rect,x,y)=>resizeCaseQuickEdges(rect,x,y,direction));
}
bindCaseQuickDrag(caseQuickHeader,(rect,x,y)=>positionCaseQuickView(rect.left+x,rect.top+y));
caseQuickResize.addEventListener('keydown',event=>{
  const increments={ArrowLeft:[24,0],ArrowRight:[-24,0],ArrowUp:[0,24],ArrowDown:[0,-24]};
  if(!Object.hasOwn(increments,event.key))return;
  event.preventDefault();
  const [x,y]=increments[event.key];
  const {width,height,right,bottom}=caseQuickView.getBoundingClientRect();
  setCaseQuickViewSize(width+x,height+y,right,bottom);
});
window.addEventListener('resize',()=>{
  if(!caseQuickView.open||!caseQuickView.style.getPropertyValue('--case-quick-left'))return;
  const {left,top}=caseQuickView.getBoundingClientRect();
  positionCaseQuickView(left,top);
});
document.getElementById('caseResend').addEventListener('click',()=>{
  if(activeMailFolder!=='bounced')return;
  const item=mailFolderItems().find(email=>email.id===caseSelectedId);
  if(!item)return;
  const email={id:`resend-${item.id}`,status:'Sent',recipient:item.recipient,subject:item.title,body:item.originalBody,savedAt:Date.now()};
  composedEmails.unshift(email);
  try{sessionStorage.setItem(composeStorageKey,JSON.stringify(composedEmails))}catch{}
  setupCaseWorkspace('casebox',undefined,'sent');
  caseSelectedId=email.id;
  renderCaseWorkspace();
  showCaseSnackbar('Email resent',true);
});
function buildMailResponse(item,action){
  const threadReply=caseSelectedMessage>0?sentThreadReplies(item)[caseSelectedMessage-1]:null;
  const sender=emailSenderAddress(threadReply||item);
  const subject=threadReply?.title||item.title;
  const forwarded=action==='forward';
  const recipients=forwarded?[]:[emailSenderAddress(item)];
  if(action==='reply-all')recipients.push(...(item.cc||[]).map(contact=>contact.address));
  let body=item.reply||'';
  if(forwarded)body='\n\n---------- Forwarded message ----------\nFrom: '+sender+'\nSubject: '+subject+'\n\n'+(threadReply?.body||item.body);
  if(cancellationDecision[action]){
    const firstName=item.sender.split(' ')[0];
    if(item.id!==cancellationEmailId){
      const outcome=action==='approve-cancellation'
        ? 'We’ve reviewed and approved your request to cancel the order.'
        : 'We’ve reviewed your request and are unable to approve the cancellation.';
      body='Hi '+firstName+',\n\n'+outcome+'\n\nBest,\n'+cancellationResponder.name;
    }else body=action==='approve-cancellation'
      ? 'Hi Joseph,\n\nWe’ve reviewed your request and cancelled trade order 132532327.\n\nBest,\n'+cancellationResponder.name
      : 'Hi Joseph,\n\nWe’ve reviewed your request to cancel trade order 132532327. We’re unable to approve the cancellation. Please contact us if you’d like to discuss the next steps.\n\nBest,\n'+cancellationResponder.name;
  }
  if(action==='ai'){
    body=item.id===cancellationEmailId&&!threadReply
      ? 'Hi Joseph,\n\nThank you for flagging order 132532327. We’ll verify the order status and confirm whether the remaining quantity can be cancelled. We’ll follow up once we have an update.\n\nBest,\n'+cancellationResponder.name
      : classifyInboxItem(item)[1]==='Instruction receipt'
        ? 'Hi '+item.sender.split(' ')[0]+',\n\nI can confirm that we received your instruction. We’ll let you know if we need any further information.\n\nBest,\n'+cancellationResponder.name
        : 'Hi,\n\nThank you for your email regarding '+item.title.replace(/[.!?]+$/,'')+'. We’ll review your message and follow up with an update.\n\nBest,\n'+cancellationResponder.name;
  }
  const id='compose-'+item.id+'-'+caseSelectedMessage+'-'+action;
  return {
    id,
    intent:action,
    sourceEmailId:forwarded?undefined:item.id,
    recipient:[...new Set(recipients)].join(', '),
    subject:forwarded?'Fwd: '+subject:/^Re: /i.test(subject)?subject:'Re: '+subject,
    body
  };
}
function cancellationDraftBody(response,attempt){
  if(response.sourceEmailId!==cancellationEmailId)return attempt%2?response.body.replace('We’ve reviewed','We reviewed').replace('Best,','Regards,'):response.body;
  const alternative=response.intent==='approve-cancellation'
    ? 'Hi Joseph,\n\nFollowing our review, we can confirm that trade order 132532327 has been cancelled as requested.\n\nRegards,\n'+cancellationResponder.name
    : 'Hi Joseph,\n\nWe’ve completed our review of trade order 132532327. The cancellation request was declined, and the order has not been cancelled.\n\nRegards,\n'+cancellationResponder.name;
  return attempt%2?alternative:response.body;
}
function fitMailDraftBody(){
  if(CSS.supports('field-sizing','content'))return;
  const editor=caseUi.mailAiDraftBody;
  if(!editor.clientWidth)return;
  editor.style.height='0';
  editor.style.height=editor.scrollHeight+'px';
}
function syncAdoptedMailDraft(body){
  const draft=caseDrafts.get(activeCaseId);
  if(draft)caseDrafts.set(activeCaseId,{...draft,body});
  caseDraftBody.value=body;
  updateCaseSendAvailability();
}
function renderSuggestedMailDraft(draft,retry=false){
  const {mailAiDraft:card,mailAiDraftBody:editor,mailAiDraftProgress:progress,mailAiRetry,mailAiUse}=caseUi;
  card.hidden=!draft;
  if(renderingMailAiDraftId===draft?.id)return;
  clearTimeout(mailAiDraftTimer);
  renderingMailAiDraftId=draft?.id;
  const alreadyAdopted=retry&&card.hasAttribute('data-adopted');
  if(!alreadyAdopted)card.removeAttribute('data-adopted');
  if(!retry)card.removeAttribute('data-plain');
  card.removeAttribute('data-generating');
  progress.hidden=true;
  if(!draft)return;

  const {body}=draft;
  function showDraft(){
    editor.value=body;
    fitMailDraftBody();
    editor.readOnly=false;
    card.removeAttribute('data-generating');
    progress.hidden=true;
    mailAiRetry.hidden=false;
    mailAiRetry.disabled=false;
    mailAiUse.hidden=alreadyAdopted;
    mailAiUse.disabled=!body.trim();
    if(alreadyAdopted)syncAdoptedMailDraft(body);
  }
  if(reducedEmailMotion.matches){
    showDraft();
    return;
  }

  editor.readOnly=true;
  mailAiUse.hidden=true;
  mailAiUse.disabled=true;
  progress.hidden=false;
  if(retry){
    mailAiRetry.disabled=true;
    card.dataset.generating='retry';
    progress.textContent='Rewriting reply…';
    mailAiDraftTimer=setTimeout(showDraft,1200);
    return;
  }

  editor.value='';
  mailAiRetry.hidden=true;
  card.dataset.generating='loading';
  progress.textContent='Drafting reply…';
  let index=0;
  function type(){
    index=Math.min(index+2,body.length);
    editor.value=body.slice(0,index);
    fitMailDraftBody();
    if(index<body.length){
      mailAiDraftTimer=setTimeout(type,24);
      return;
    }
    mailAiDraftTimer=setTimeout(()=>{
      mailAiRetry.hidden=false;
      mailAiRetry.disabled=false;
      mailAiDraftTimer=setTimeout(showDraft,220);
    },160);
  }
  mailAiDraftTimer=setTimeout(()=>{
    progress.hidden=true;
    card.dataset.generating='typing';
    type();
  },3500);
}
caseUi.mailAiDraftBody.addEventListener('input',()=>{
  if(!visibleMailAiDraft)return;
  fitMailDraftBody();
  const body=caseUi.mailAiDraftBody.value;
  caseUi.mailAiUse.disabled=!body.trim();
  if(caseUi.mailAiDraft.hasAttribute('data-adopted'))syncAdoptedMailDraft(body);
});
const draftEditor=caseUi.mailAiDraftBody;
const draftCaretLayer=draftEditor.nextElementSibling;
const draftCaretMirror=draftCaretLayer.firstElementChild;
const draftCaretMarker=document.createElement('span');
let composingMailDraft=false;
function renderMailDraftCaret(){
  const {selectionStart,selectionEnd,value,clientWidth,scrollTop}=draftEditor;
  draftCaretLayer.hidden=document.activeElement!==draftEditor||composingMailDraft||draftEditor.readOnly||selectionStart!==selectionEnd;
  if(draftCaretLayer.hidden)return;
  draftCaretMirror.style.width=clientWidth+'px';
  draftCaretMirror.style.transform='translateY('+(-scrollTop)+'px)';
  draftCaretMirror.replaceChildren(value.slice(0,selectionStart),draftCaretMarker,value.slice(selectionStart)||'\u200b');
  draftCaretMarker.getAnimations({subtree:true}).forEach(animation=>{animation.currentTime=0});
}
for(const event of ['focus','blur','input','scroll','selectionchange','click','keyup']){
  draftEditor.addEventListener(event,renderMailDraftCaret);
}
draftEditor.addEventListener('compositionstart',()=>{
  composingMailDraft=true;
  renderMailDraftCaret();
});
draftEditor.addEventListener('compositionend',()=>{
  composingMailDraft=false;
  renderMailDraftCaret();
});
let draftEditorWidth;
new ResizeObserver(()=>{
  if(draftEditor.clientWidth!==draftEditorWidth){
    draftEditorWidth=draftEditor.clientWidth;
    fitMailDraftBody();
  }
  renderMailDraftCaret();
}).observe(draftEditor);
function generatePreviewReply(retry=false){
  const item=caseSamples.find(entry=>entry.id===activeCaseId);
  const draft=caseDrafts.get(activeCaseId);
  const email=item&&(inboxSamples.find(source=>source.id===draft?.sourceEmailId)||linkedSourceEmail(item));
  const intent=draft?.intent;
  if(!email||!cancellationDecision[intent])return;
  const response=buildMailResponse(email,intent);
  const attempt=caseAiWriteAttempts++;
  visibleMailAiDraft={id:response.id+'-'+attempt,body:cancellationDraftBody(response,attempt)};
  syncAdoptedMailDraft('');
  renderSuggestedMailDraft(visibleMailAiDraft,retry);
}
function finishCaseAiWriting(){
  clearTimeout(caseAiWriteTimer);
  caseAiWriting=false;
  caseAiWrite.disabled=false;
  updateCaseSendAvailability();
  caseDraftBody.readOnly=false;
  caseDraftBody.closest('label').removeAttribute('data-ai-writing');
}
caseAiWrite.addEventListener('click',()=>{
  if(caseAiWriting||caseAiWrite.hidden)return;
  const draft=caseDrafts.get(activeCaseId);
  if(caseQuickView.open&&draft?.mailAction){
    const email=inboxSamples.find(item=>item.id===draft.sourceEmailId);
    if(!email)return;
    const response=buildMailResponse(email,'ai');
    caseDraftBody.value=response.body;
    caseDraftBody.dispatchEvent(new Event('input',{bubbles:true}));
    caseDraftBody.focus({preventScroll:true});
    return;
  }
  const intent=draft?.intent||'approve-cancellation';
  const item=caseSamples.find(entry=>entry.id===activeCaseId);
  const email=item&&linkedSourceEmail(item);
  if(!email||!cancellationDecision[intent])return;

  const response=buildMailResponse(email,intent);
  const body=cancellationDraftBody(response,caseAiWriteAttempts);
  caseAiWriting=true;
  caseAiWrite.disabled=true;
  updateCaseSendAvailability();
  caseDraftBody.readOnly=true;
  caseDraftBody.closest('label').dataset.aiWriting='';
  caseAiWriteStatus.textContent='Drafting reply…';
  let length=0;
  function type(){
    length=reducedEmailMotion.matches?body.length:Math.min(length+3,body.length);
    caseDraftBody.value=body.slice(0,length);
    if(length<body.length){
      caseAiWriteTimer=setTimeout(type,23);
      return;
    }
    if(!caseDraftSubject.value.trim())caseDraftSubject.value=response.subject;
    caseDrafts.set(activeCaseId,{...draft,intent,subject:caseDraftSubject.value,body});
    caseAiWriteAttempts+=1;
    caseAiWriteLabel.textContent='Try again';
    finishCaseAiWriting();
    caseAiWriteStatus.textContent='Draft ready to review';
    caseDraftBody.focus({preventScroll:true});
  }
  caseAiWriteTimer=setTimeout(type,reducedEmailMotion.matches?0:900);
});
function openMailResponse(action){
  document.getElementById('caseMoreActionsMenu').hidePopover();
  const item=caseVisibleItems.find(email=>email.id===caseSelectedId);
  if(!item)return;
  if(item.id.startsWith('compose-')){
    openCaseComposer(item);
    return;
  }
  const response=buildMailResponse(item,action);
  openCaseQuickView(item.linked,caseUi.caseReaderTitle,{...response,mailAction:action});
}
function openMailDecision(trigger,intent){
  if(trigger.hidden)return;
  const email=caseVisibleItems.find(item=>item.id===caseSelectedId);
  if(!email)return;
  const {subject}=buildMailResponse(email,intent);
  openCaseQuickView(email.linked,trigger,{subject,body:'',intent,sourceEmailId:email.id});
}
mailReviewAction.addEventListener('click',()=>{
  const item=caseVisibleItems.find(email=>email.id===caseSelectedId);
  if(!item||mailReviewAction.hidden)return;
  const [title,...checks]=mailReviewTypes[classifyInboxItem(item)[1]];
  reviewingMailId=item.id;
  document.getElementById('mailReviewTitle').textContent=title;
  document.getElementById('mailReviewChecklist').innerHTML='<legend>Manual checks</legend>'+checks.map(check=>
    '<label><input type="checkbox" required> '+safeEmailPreview(check)+'</label>'
  ).join('');
  openCaseQuickView(item.linked,mailReviewAction);
});
function updateMailReviewAvailability(){
  const checks=[...mailReviewForm.querySelectorAll('input[type="checkbox"]')];
  const ready=checks.length>0&&checks.every(check=>check.checked);
  for(const button of mailReviewActions.querySelectorAll('button'))button.disabled=!ready;
}
mailReviewForm.addEventListener('change',updateMailReviewAvailability);
mailReviewForm.addEventListener('submit',event=>{
  event.preventDefault();
  if(mailReviewForm.hidden||!mailReviewForm.reportValidity())return;
  const email=inboxSamples.find(item=>item.id===reviewingMailId);
  const item=caseSamples.find(entry=>entry.id===activeCaseId);
  if(!email||!item||!['approve','reject'].includes(event.submitter?.value))return;
  const approved=event.submitter.value==='approve';
  const changes={
    status:approved?'Resolved':'Resolved by rejection',
    decision:approved?'Manual review approved.':'Manual review rejected.',
    savedAt:Date.now()
  };
  updateInboxEmail(email,{manuallyReviewed:true});
  Object.assign(item,changes);
  caseDecisions[item.id]=changes;
  renderApprovalList();
  renderCaseDetails(item);
  renderCaseWorkspace(changes.decision);
  showCaseSnackbar(changes.decision,approved,'top');
  caseWorkspaceTitle.focus({preventScroll:true});
});
mailReplyAndSend.addEventListener('click',()=>{
  const item=caseVisibleItems.find(email=>email.id===caseSelectedId);
  if(!item)return;
  const response=buildMailResponse(item,'reply');
  openCaseQuickView(item.linked,mailReplyAndSend,{...response,body:'',mailAction:'reply'});
});
mailApproveAndSend.addEventListener('click',event=>openMailDecision(event.currentTarget,'approve-cancellation'));
mailRejectAndSend.addEventListener('click',event=>openMailDecision(event.currentTarget,'reject-cancellation'));
caseUi.mailAiRetry.addEventListener('click',()=>generatePreviewReply(true));
caseUi.mailAiUse.addEventListener('click',()=>{
  if(!visibleMailAiDraft||!caseQuickView.open)return;
  const body=caseUi.mailAiDraftBody.value;
  if(!body.trim())return;
  caseUi.mailAiDraft.dataset.adopted='';
  caseUi.mailAiDraft.dataset.plain='';
  caseUi.mailAiUse.hidden=true;
  syncAdoptedMailDraft(body);
  caseUi.mailAiDraftBody.focus({preventScroll:true});
});
caseUi.caseLinkAction.addEventListener('click',()=>{
  document.getElementById('caseMoreActionsMenu').hidePopover();
  const item=caseVisibleItems.find(item=>item.id===caseSelectedId);
  if(!item)return;
  if(item.linked||isArchivedEmail(item))return;
  caseLinkForm.reset();
  caseLinkId.setCustomValidity('');
  caseLinkDialog.showModal();
});
caseLinkId.addEventListener('input',()=>caseLinkId.setCustomValidity(''));
caseLinkForm.addEventListener('click',event=>{
  if(event.target.closest('[data-close-case-link]'))caseLinkDialog.close();
});
caseLinkForm.addEventListener('submit',event=>{
  event.preventDefault();
  const email=inboxSamples.find(item=>item.id===caseSelectedId);
  const caseId=caseLinkId.value.trim().toUpperCase();
  if(!email)return;
  if(!caseSamples.some(item=>item.id===caseId)){
    caseLinkId.setCustomValidity('Enter an existing Case ID.');
    caseLinkId.reportValidity();
    return;
  }
  updateEmailLink(email,caseId);
  caseLinkDialog.close();
  renderCaseWorkspace(`Email linked to ${caseId}`);
});
caseUi.caseArchive.addEventListener('click',()=>{
  document.getElementById('caseMoreActionsMenu').hidePopover();
  const item=inboxSamples.find(item=>item.id===caseSelectedId);
  if(!item)return;
  if(isArchivedEmail(item)){
    restoreArchivedEmail(item);
    if(lastArchivedEmail===item){lastArchivedEmail=undefined;caseUndoNotice.hidden=true}
    renderCaseWorkspace('Email restored');
    return;
  }
  if(caseQuickView.open&&item.linked===activeCaseId)closeCaseQuickView(false);
  updateInboxEmail(item,{archived:true,archivedLink:item.linked||''});
  item.linked='';
  lastArchivedEmail=item;
  renderCaseWorkspace();
  caseUndoNotice.hidden=false;
  document.getElementById('caseUndoArchive').focus({preventScroll:true});
});

renderApprovalList();
const requestedEmbeddedView=new URLSearchParams(location.search).get('view');
if(embeddedMode||requestedEmbeddedView){
  if(requestedEmbeddedView==='diagnostics'){
    showView('diagnostics');
    completeScan();
  }else if(['casebox','cases','case-detail'].includes(requestedEmbeddedView)){
    if(!embeddedMode)document.body.classList.add('embedded-mode','standalone-case-mode');
    const caseDetail=requestedEmbeddedView==='case-detail';
    const returnPage=window.frameElement?.dataset.caseReturnPage;
    if(returnPage)caseDetailReturn={page:returnPage};
    selectGlobalPage('casebox');
    openCaseWorkspaceDestination(caseDetail?'cases':requestedEmbeddedView,
      caseDetail?cancellationCaseId:window.frameElement?.dataset.caseboxCategory);
  }else if(requestedEmbeddedView==='about'){
    selectGlobalPage('dashboard');
    openAbout();
  }else{
    selectGlobalPage('dashboard');
  }
}
