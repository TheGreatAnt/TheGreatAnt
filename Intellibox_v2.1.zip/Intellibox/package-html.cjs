const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const read = name => fs.readFileSync(path.join(__dirname, name), 'utf8');
const write = (name, contents) => fs.writeFileSync(path.join(__dirname, name), contents);
const shellFile = 'sbproto_Intellibox.html';
const shell = read(shellFile);

function inlineAssets(source) {
  return source.replace(/(["'])(Icon\/[^"'\n]+\.svg|agentOS\.svg|avatar\/profile_[123]\.png)\1/g, (match, quote, name) => {
    const asset = fs.readFileSync(path.join(__dirname, name));
    const mime = name.endsWith('.png') ? 'image/png' : 'image/svg+xml';
    return quote + 'data:' + mime + ';base64,' + asset.toString('base64') + quote;
  });
}

const localFonts = /\s*<link[^>]+href="https:\/\/fonts\.(?:googleapis|gstatic)\.com[^"]*"[^>]*>/g;
const closeScript = source => source.replace(/<\/script/gi, '<\\/script');
const appCss = inlineAssets(read('styles.css'));
const appScript = inlineAssets(read('script.js'))
  .replace("const requestedEmbeddedView=new URLSearchParams(location.search).get('view');", 'const requestedEmbeddedView=window.intelliboxEntry;')
  .replace("const embeddedMode=new URLSearchParams(location.search).get('embedded')==='1';", 'const embeddedMode=window.intelliboxEmbedded;')
  .replaceAll('},location.origin);', "},location.origin==='null'?'*':location.origin);")
  .replace("if(event.origin===location.origin&&event.data?.type==='intellibox:open-about')", "if(event.source===parent&&event.origin===location.origin&&event.data?.type==='intellibox:open-about')")
  .replaceAll('location.origin', 'window.origin');
const app = inlineAssets(read('index.html'))
  .replace(/<script>if\(new URLSearchParams[^\n]+<\/script>/, '')
  .replace(localFonts, '')
  .replace(/<link rel="stylesheet" href="styles\.css[^"]*"\s*\/>/, () => '<style>\n' + appCss + '\n</style>')
  .replace(/<script src="(vendor\/lottie-light\.min\.js|inbox-email-animation\.js)"><\/script>/g,
    (_, name) => '<script>\n' + closeScript(read(name)) + '\n</script>')
  .replace(/<script src="script\.js[^"]*"><\/script>/, () => '<script>\n' + closeScript(appScript) + '\n</script>');

function makeApp(view, embedded, title) {
  const chrome = embedded ? '' : '<style>.global-header,.view-switch,.powered{display:none!important}body>main{padding-top:0}body.standalone-case-mode.casebox-mode>main{height:100dvh;min-height:0;padding-block:0}body.standalone-case-mode.casebox-mode .casebox-view{display:flex;flex-direction:column;height:100%}body.standalone-case-mode.casebox-mode :is(.case-list-workspace,.case-workspace){flex:1;min-height:0}</style>';
  const document = title ? app.replace(/<title>[^<]*<\/title>/, '<title>IntelliBox · ' + title + '</title>') : app;
  return document.replace('</head>', () =>
    chrome + '<script>window.intelliboxEntry=' + JSON.stringify(view) +
    ';window.intelliboxEmbedded=' + embedded + ';</script></head>'
  );
}

const bundleTag = /(<script id="intelliboxBundle" type="text\/plain">)[\s\S]*?(<\/script>)/;
if (!bundleTag.test(shell)) throw new Error('Shell bundle was not found');
const appBundle = makeApp('__INTELLIBOX_ENTRY__', true);
const finalShell = shell.replace(bundleTag, (_, open, close) =>
  open + appBundle.replace(/<\/script>/gi, '</script-BUNDLE>') + close
);

const outputs = {
  [shellFile]: finalShell,
  'intellibox-overview.html': makeApp('overview', false, 'Overview'),
  'intellibox-diagnostics.html': makeApp('diagnostics', false, 'Diagnostics'),
  'intellibox-inbox.html': makeApp('casebox', false, 'Inbox'),
  'intellibox-all-cases.html': makeApp('cases', false, 'All cases'),
  'intellibox-case-detail.html': makeApp('case-detail', false, 'Case FSS-2026-33')
};
for (const [name, html] of Object.entries(outputs)) {
  for (const match of html.matchAll(/<script([^>]*)>([\s\S]*?)<\/script>/gi)) {
    if (!match[1].includes('text/plain')) new vm.Script(match[2], {filename: name});
  }
}
for (const [name, html] of Object.entries(outputs)) write(name, html);
