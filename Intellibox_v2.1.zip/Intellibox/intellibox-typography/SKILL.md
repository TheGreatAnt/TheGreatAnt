---
name: intellibox-typography
description: Apply the approved IntelliBox title, hero-title, and paragraph type scale when creating or reviewing IntelliBox product UI. Use for CSS typography tokens, page and card headings, navigation, labels, helper text, tables, and responsive type audits in this project.
---

# IntelliBox Typography

Use this scale as the source of truth for font size and weight. IntelliBox UI uses SC Prosper Sans. Do not introduce an intermediate size when one of these roles fits.

## Tokens

### Title

Use 400 or 500 for titles according to the component role. Reserve 600 for numeric data.

| Token | rem | px |
|---|---:|---:|
| `title-1` | `2.1875rem` | 35px |
| `title-2` | `1.75rem` | 28px |
| `title-3` | `1.3125rem` | 21px |
| `title-4` | `1.09375rem` | 17.5px |
| `title-5` | `1.09375rem` | 17.5px |
| `title-6` | `0.875rem` | 14px |

### Hero title


| Token | rem | px |
|---|---:|---:|
| `hero-title-1` | `2.84375rem` | 45.5px |
| `hero-title-2` | `2.4rem` | 38.4px |
| `hero-title-3` | `1.75rem` | 28px |
| `hero-title-4` | `1.5rem` | 24px |
| `hero-title-5` | `1.5rem` | 24px |
| `hero-title-6` | `1rem` | 16px |

### Paragraph

All paragraph roles use 400. Overview and Diagnostics section titles use the paragraph-lg size with weight 500 because they are headings.

| Token | rem | px |
|---|---:|---:|
| `paragraph-lg` | `1rem` | 16px |
| `paragraph-md` | `0.875rem` | 14px |
| `paragraph-xs` | `0.75rem` | 12px |
| `paragraph-xxs` | `0.625rem` | 10px |

## Role mapping

- Use title tokens for page headings, section headings, card headings, and compact UI titles.
- Reserve hero-title tokens for prominent marketing or landing-page display text; ordinary dashboard headings are title roles.
- Use `paragraph-lg` for prominent body copy and large data labels.
- Use `paragraph-md` for default UI copy, controls, table cells, and legends. Use title-6 at 500 for the Dashboard, Case box, and About entries in the Shell navigation.
- Use `paragraph-xs` for helper text, metadata, timestamps, and compact status copy.
- Use `paragraph-xxs` only for dense secondary labels where 12px does not fit.
- Use the shared SC Prosper Sans font stack for UI text, including controls and charts. If SC Prosper Sans is unavailable, use the shared fallback stack. Verify the rendered face separately from the CSS family declaration.
- Keep UI states distinguishable through color, icons, and other component styling. Use a readable line height for wrapping text.

## Applying the scale

1. Define the complete scale as semantic CSS custom properties on `:root`.
2. Map components to roles instead of repeating literal pixel values.
3. When migrating an existing size, prefer the component's semantic role; otherwise select the nearest approved size.
4. Check wrapped labels and responsive breakpoints after migration. A type token must not cause clipping or horizontal overflow.
5. Audit computed styles for the approved size, weight, and font family.

## Intentional exceptions

Icon glyph dimensions and SVG artwork are not typography. Do not force icon sizes onto this scale. Native browser form rendering may also retain platform-specific internal metrics, but visible text must use an approved token.
