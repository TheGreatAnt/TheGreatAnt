# SC semantic color reference

## Extended primitive ramps

These source tokens were added from the supplied all-color-token screenshots. Use them for chart-series differentiation, illustrations, data categories, and non-status accents. Semantic status meaning still takes priority: do not replace success green, warning amber, error red, or information blue merely for variety.

Each ramp is ordered from 50 through 950 in steps of 50.

| Family | 50 → 500 | 550 → 950 |
|---|---|---|
| Magenta | #FDE7F2, #FCCFE5, #FAB8D7, #F8A0CA, #F788BD, #F570B0, #F358A3, #F14195, #F02988, #EE117B | #D60F6F, #BE0E62, #A70C56, #8F0A4A, #77093E, #5F0731, #470525, #300319, #18020C |
| Olive | #F7F9EB, #F0F3D7, #E8EEC3, #E1E8AF, #DAE39B, #D2DD87, #CBD773, #C3D25F, #BCCC4B, #B5C738 | #A2B332, #909F2C, #7E8B27, #6C7721, #5A631C, #484F16, #363B10, #24270B, #121305 |
| Violet | #EDEDF8, #DADAF2, #C8C8EB, #B6B6E5, #A3A3DE, #9191D7, #7F7FD1, #6D6DCA, #5A5AC4, #4848BD | #4141AA, #3A3A97, #323284, #2B2B71, #24245F, #1D1D4C, #161639, #0E0E26, #070713 |
| Orange | #FFF0E8, #FFEFE6, #FFDECD, #FFCEB4, #FFBE9C, #FFAD84, #FD9D6C, #F98C55, #F47B3D, #EF6923 | #D65E1F, #B9511B, #974216, #6B2F10, #7D330D, #64290A, #4B1F08, #321405, #190A03 |
| Maroon | #F7E9EE, #EFD3DE, #E6BDCD, #DEA7BD, #D690AC, #CE7A9C, #C6648B, #BD4E7B, #B5386B, #AD225A | #9C1F51, #8A1B48, #79183F, #681436, #57112D, #450E24, #340A1B, #230712, #110309 |
| Teal | #E8FAFC, #D1F6FA, #BAF2F7, #A3EDF5, #8CE9F2, #75E4EF, #5FE0ED, #48DCEA, #31D7E8, #1AD3E5 | #17BDCE, #15A9B7, #1294A0, #107F89, #0D6A73, #0A545C, #083F45, #052A2E, #031517 |
| Purple | #F2E8FF, #E5D2FE, #D8BBFE, #CBA5FD, #BE8EFD, #B277FD, #A561FC, #984AFC, #8B34FB, #7E1DFB | #711AE2, #6517C9, #5814B0, #4C1197, #3F0F7E, #320C64, #26094B, #190632, #0D0319 |

### Pairing guidance for extended families

- For a light tile, badge, or chart label, use a 50–150 background with a 650–800 foreground from the same family.
- For saturated chart marks on white, prefer 400–650; verify 3:1 contrast for meaningful graphics.
- Purple and violet suit AI, automation, or secondary categorical accents; teal suits sent/in-transit or auxiliary progress categories; magenta and maroon suit categorical emphasis, not error semantics.
- Olive and orange are non-semantic accents unless the product explicitly assigns them a meaning. Use Amber—not Orange—for warnings.


The values below were transcribed from the supplied Global Design System screenshots. Use semantic names in product code; primitive names are included only for traceability.

## Foundation and brand

| Semantic role | Light | Dark | Purpose |
|---|---:|---:|---|
| `surface-base` | `#FFFFFF` | `#1A1A1A` | Default application background |
| `surface-container` | `#FFFFFF` | `#262626` | Cards, menus, controls and elevated containers |
| `surface-inverse` | `#262626` | `#D9D9D9` | Inverse container |
| `border-divider` | `#CCCCCC` | `#666666` | Separators and strokes |
| `border-divider-inverse` | `#666666` | `#CCCCCC` | Dividers on inverse surfaces |
| `brand-grey` | `#595959` | `#A6A6A6` | Neutral brand grey |
| `brand-blue` | `#0473EA` | `#0473EA` | Primary interactive/brand blue |
| `brand-green` | `#38D200` | `#38D200` | Positive brand green |
| `brand-prosper-blue` | `#020B43` | `#012E5D` | Deep accent blue |
| `brand-prosper-blue-inverse` | `#FFFFFF` | `#020B43` | Contrast hierarchy for prosper blue |

## Content on base surfaces

| Semantic role | Light | Dark | Typical use |
|---|---:|---:|---|
| `text-header` | `#0D0D0D` | `#F2F2F2` | Page headings |
| `text-title` | `#262626` | `#D9D9D9` | Section and card titles |
| `text-body` | `#4D4D4D` | `#B2B2B2` | Body copy |
| `text-label` | `#4D4D4D` | `#B2B2B2` | Labels |
| `text-input` | `#333333` | `#CCCCCC` | User-entered content |
| `text-placeholder` | `#666666` | `#999999` | Placeholder text |
| `text-eyebrow` | `#808080` | `#808080` | Eyebrow/hint text |
| `text-disabled` | `#808080` | `#808080` | Disabled labels |
| `text-helper` | `#595959` | `#A6A6A6` | Supporting copy |
| `text-information` | `#035CBB` | `#368FEE` | Links and informational emphasis |
| `text-error` | `#E3232C` | `#E3232C` | Errors and destructive states |
| `text-alert` | `#96680C` | `#FDD689` | Warnings and approvals |
| `text-success` | `#207E00` | `#87E769` | Success and positive states |

## Content on inverse or colored layers

| Semantic role | Light mapping | Dark mapping |
|---|---:|---:|
| `text-header-layered` | `#F2F2F2` | `#000000` |
| `text-title-layered` | `#D9D9D9` | `#070707` |
| `text-body-layered` | `#B2B2B2` | `#0D0D0D` |
| `text-label-layered` | `#E5E5E5` | `#1A1A1A` |
| `text-input-layered` | `#CCCCCC` | `#333333` |
| `text-placeholder-layered` | `#999999` | `#666666` |
| `text-eyebrow-layered` | `#999999` | `#666666` |
| `text-disabled-layered` | `#999999` | `#666666` |
| `text-helper-layered` | `#A6A6A6` | `#D9D9D9` |
| `text-information-layered` | `#368FEE` | `#368FEE` |
| `text-alert-layered` | `#FAB52C` | `#FAB52C` |
| `text-success-layered` | `#38D200` | `#4BD81E` |

## Opacity tokens

Use these as overlays, expressed as CSS `rgb()` with alpha:

| Token | Light base overlay | Light layered overlay | Dark base overlay | Dark layered overlay |
|---|---|---|---|---|
| `opacity-20` | `rgb(255 255 255 / 20%)` | `rgb(26 26 26 / 20%)` | `rgb(26 26 26 / 20%)` | `rgb(255 255 255 / 20%)` |
| `opacity-40` | `rgb(255 255 255 / 40%)` | `rgb(26 26 26 / 40%)` | `rgb(26 26 26 / 40%)` | `rgb(255 255 255 / 40%)` |
| `opacity-60` | `rgb(255 255 255 / 60%)` | `rgb(26 26 26 / 60%)` | `rgb(26 26 26 / 60%)` | `rgb(255 255 255 / 60%)` |
| `opacity-80` | `rgb(255 255 255 / 80%)` | `rgb(26 26 26 / 80%)` | `rgb(26 26 26 / 80%)` | `rgb(255 255 255 / 80%)` |

## Recommended tinted status containers

The screenshots specify semantic foreground colors but not every pale container value at readable resolution. The following tints are derived UI companions, not source tokens; adjust them to meet contrast and product context.

| Family | Light container | Light foreground | Dark container | Dark foreground |
|---|---:|---:|---:|---:|
| Information | `#EAF4FF` | `#035CBB` | `#012E5D` | `#368FEE` |
| Success | `#E8FBE6` | `#207E00` | `#163D0D` | `#87E769` |
| Warning | `#FFF5DF` | `#96680C` | `#4A350A` | `#FDD689` |
| Error | `#FDE9EA` | `#E3232C` | `#4B171A` | `#FC6C73` |
| Neutral | `#F2F2F2` | `#595959` | `#333333` | `#D9D9D9` |

## CSS starter

```css
:root {
  color-scheme: light;
  --surface-base: #ffffff;
  --surface-container: #ffffff;
  --surface-inverse: #262626;
  --border-divider: #cccccc;
  --text-header: #0d0d0d;
  --text-title: #262626;
  --text-body: #4d4d4d;
  --text-helper: #595959;
  --brand-blue: #0473ea;
  --brand-green: #38d200;
  --status-info: #035cbb;
  --status-success: #207e00;
  --status-warning: #96680c;
  --status-error: #e3232c;
}

[data-theme="dark"] {
  color-scheme: dark;
  --surface-base: #1a1a1a;
  --surface-container: #262626;
  --surface-inverse: #d9d9d9;
  --border-divider: #666666;
  --text-header: #f2f2f2;
  --text-title: #d9d9d9;
  --text-body: #b2b2b2;
  --text-helper: #a6a6a6;
  --status-info: #368fee;
  --status-success: #87e769;
  --status-warning: #fdd689;
  --status-error: #e3232c;
}
```

## Source interpretation notes

- Values in the main tables are explicit semantic values visible in the supplied screenshots.
- The tall overview image contains additional primitive and component-specific tokens, but labels below readable resolution were not guessed.
- Treat the semantic mappings above as authoritative for new work; expand the reference only when higher-resolution source material makes additional values explicit.
