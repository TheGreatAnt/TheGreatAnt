---
name: sc-color-guidance
description: Apply the extracted Standard Chartered Global Design System color language to new interfaces, including semantic light/dark theme tokens, layered surfaces, status colors, text hierarchy, opacity, extended color families, and accessible color pairing. Use when creating or reviewing product UI palettes, design tokens, CSS variables, dashboards, components, charts, or themes. Do not use for reproducing Standard Chartered logos or unrelated brand assets.
---

# SC Color Guidance

Use this system as a semantic color framework, not merely as a list of swatches. Preserve the hierarchy and contrast relationships while adapting the palette to the product being built.

Read [references/palette.md](references/palette.md) whenever exact hex values, CSS variables, dark-theme mappings, opacity recipes, or extended primitive ramps are needed.

## Core decisions

1. Define semantic tokens before styling components. Components should consume semantic roles, never raw palette names.
2. Use neutral surfaces for most of the interface. Reserve blue for information, green for success, amber for warning, and red for error states.
3. Pair pale tinted containers with a darker color from the same hue family.
4. Treat light and dark themes as separate semantic mappings. Do not mechanically invert colors.
5. Use layered tokens on inverse, brand-colored, or dark containers.
6. Keep charts legible by combining hue, label, and shape. Never rely on hue alone.

## Visual hierarchy

- Base canvas: surface-base.
- Cards and controls: surface-container.
- Inverse regions: surface-inverse with layered text tokens.
- Headings: text-header or text-title.
- Main copy: text-body; metadata: text-helper or text-placeholder.
- Dividers: border-divider.
- Primary interaction: brand-blue; positive brand accent: brand-green.

## Status pairing

- Information: blue foreground on a very light blue tint.
- Success: dark green foreground on a pale green tint.
- Warning/approval: dark amber foreground on a pale amber tint.
- Error/attention: red foreground on a pale red tint.
- Neutral: grey foreground on a pale grey tint.

Foreground and background must share the same semantic family.

## Extended color families

The source palette also includes Magenta, Olive, Violet, Orange, Maroon, Teal, and Purple ramps from 50 through 950. Read the extended primitive ramps in references/palette.md when a design needs categorical variety beyond the core semantic colors.

- Preserve semantic priority: blue/information, green/success, amber/warning, and red/error remain authoritative for states.
- Use purple or violet for AI and automation accents when the reference design calls for them.
- Use teal for sent, in-transit, secondary progress, or mint-like categorical accents.
- Use magenta, maroon, olive, and orange mainly for charts, data categories, and decorative emphasis unless the product defines an explicit meaning.
- Pair pale 50–150 containers with 650–800 foregrounds from the same family; use 400–650 for chart marks on white after contrast verification.

## Opacity and overlays

- Use the supplied 20%, 40%, 60%, and 80% overlay steps.
- In light mode, white overlays reveal content beneath; layered contrast overlays use #1A1A1A.
- In dark mode, base overlays use #1A1A1A; layered contrast overlays use white.
- Prefer a semantic solid token when an overlay is not revealing content beneath it.

## Accessibility checks

- Target WCAG AA: 4.5:1 for normal text and 3:1 for large text or meaningful UI graphics.
- Never use placeholder, disabled, or helper colors for essential body content.
- Status must remain understandable without color through text, icons, or patterns.
- Verify both themes independently.

## Deliverables

When creating a palette for a project, provide semantic tokens, target-platform variables, same-hue component examples, and a short note for intentional deviations.
