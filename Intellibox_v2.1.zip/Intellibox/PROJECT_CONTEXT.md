# IntelliBox — Project context

Last updated: 2026-11-24 | Owner perspective: UX design | Status: evolving design, not an engineering specification

## 1. Purpose
IntelliBox is an AI-powered intelligent mailbox and service-processing product within the bank's Service Bench (SB) ecosystem. It receives incoming emails, analyzes and classifies them, supports intelligent replies, and can automate supported case-processing activities. It is not a general workflow orchestration product. The productization initiative aims to make the relationship between IntelliBox and its application-specific instances understandable, discoverable and consistent.

## 2. Product model
- IntelliBox is the parent product, not simply the name of an individual plugin.
- Different business applications can adopt IntelliBox and create one or more instances. Examples discussed include FSS Servicing Agent and CLSG (Client Servicing Group); exact formal names should be verified.
- An instance has its own operational context and monitoring experience. Do not assume that data, permissions, configuration or metrics are shared across instances.
- Service Bench is the platform through which users discover products and access relevant plugins/instances.
- CaseBox has been discussed in connection with intelligent email and case handling. Its exact technical relationship to IntelliBox is not established in this context; ask before defining it as a subsystem.

```text
Service Bench
  └─ IntelliBox (parent product / discovery)
       ├─ FSS Servicing Agent (example instance)
       └─ CLSG (example instance)
            ├─ Dashboard
            ├─ System heartbeat (proposed separation)
            └─ Process diagnostics
```
This is a conceptual IA, not a confirmed backend hierarchy.

## 3. Original experience and problem statement
The original experience presents multiple instances with very similar screens and IntelliBox branding in plugin headers. For an owner familiar with the system this may be understandable, but other users cannot easily tell why the plugins look alike, how they relate, or whether IntelliBox itself is searchable. Searching the parent product previously returned no result in the scenario discussed.

The original long dashboard also mixed business outcomes, technical health and process diagnostics. Some metrics lacked definitions, some visualizations repeated status cards, and sections such as “How the agent replied” and “What customers asked for” were not self-explanatory. The result was a crowded experience that made it harder to identify what matters and what requires action.

## 4. Productization goals and user journey
Proposed end-to-end journey:
1. Discover IntelliBox from Service Bench search or product discovery.
2. Understand what the product does and its key capabilities.
3. Discover or access relevant instances, subject to actual access rules.
4. Open an instance and monitor its business activity and technical health.
5. Investigate exceptions using diagnostics rather than cluttering the overview.
6. For prospective adopters, provide a clear onboarding/contact path.

A landing-page banner for new users should explain the value and offer a contact-team CTA. Do not invent a self-service provisioning flow unless confirmed.

Suggested capability labels (copy proposals, not verified feature contracts): Intelligent email intake; Automated classification; AI-assisted replies; Case automation; Operational monitoring; Exception diagnostics.

## 5. Instance information architecture
The design direction explored separating Dashboard and Process diagnostics into tabs. A distinct System heartbeat area/tab has also been explored to separate technical metrics from business metrics. The latest approved tab structure is not established; preserve the two-tab design if that is the supplied baseline, and treat a third tab as a proposal rather than a decision.

### Dashboard — business overview
Primary questions: What is happening? How much work is being handled? What needs human attention? How effectively is the agent responding?

Candidate sections:
- KPI cards for intake, processing and response outcomes (exact fields and calculations must match real data).
- Status breakdown: distribution of current processing outcomes; avoid repeating existing KPI cards without adding useful insight.
- Waiting on a human: items that require human intervention, review or input; clarify whether this is a current queue or period total.
- Agent response insights: replace vague “How the agent replied” with a clear breakdown tied to actual response categories and denominators.
- Customer request insights: show meaningful request categories when data exists; provide an informative empty state otherwise.
- Trends and configurable widgets have been explored; do not imply configuration has shipped.

Dispatch rate has been discussed as a response-rate indicator, with higher generally interpreted as better. Confirm numerator, denominator and time window with the product owner. A rate alone does not prove faster response time; use a separate latency metric if needed.

### System heartbeat — technical health
Primary question: Is the instance operating normally? Separate health indicators from business effectiveness. Candidate information includes component/service health, connectivity, errors, processing delays and recent incidents only where telemetry is available. Avoid inventing thresholds or health signals. If the baseline combines this with Dashboard, retain a concise technical-health summary and offer deeper detail only where appropriate.

### Process diagnostics — investigation
Primary questions: What went wrong? Where? Which items are affected? What can the user do next?

Use diagnostic summaries, affected-item lists, filters, error details and drill-downs as supported by the actual system. Candidate columns: item reference, timestamp, processing stage, status, issue and available action. These are design suggestions, not existing API fields. Avoid repeating the entire dashboard. Do not introduce workflow-instance recovery actions (rerun node, skip gateway, etc.) from the separate Workflow Admin project without a verified IntelliBox use case.

## 6. Design principles and visual direction
- Prioritize product comprehension and end-to-end navigation over superficial visual polish.
- Make parent product versus instance identity explicit; avoid implying every instance is a separate unrelated product.
- Organize information by user intent: overview, technical health, investigation.
- Use meaningful chart titles, legends, denominators, time ranges and empty states.
- Aim for a professional enterprise interface that is not excessively clinical or pale. Use controlled color, restrained illustrations and visual hierarchy without ornamental clutter.
- Gmail and Zoho have been discussed as visual/interaction references, not specifications.
- Use existing Service Bench/WebKit/GDS/ODS patterns where applicable. Confirm actual component availability.
- Sentence case for UI headings, tabs, labels and microcopy. Primary actions on the right; primary button rightmost in action groups.
- Do not use custom gradients for standard tabs or controls; decorative banners/illustrations are a separate context.

## 7. UX writing examples (proposals)
- Status breakdown — See how incoming items are distributed across processing statuses.
- Waiting on a human — Review items that require human input before processing can continue.
- System health — Monitor the operational health of this IntelliBox instance.
- Onboarding banner — Get started with IntelliBox / Discover how IntelliBox can help automate email and case handling for your application. Contact our team to get started.
- Empty insight — No request insights available for the selected period.

Keep copy concise, plain and action-oriented; avoid promising capabilities that are not verified.

## 8. Stakeholders and delivery context
The UX designer is shaping productization and the complete discovery-to-instance journey, not just individual screens. The concept has been discussed internally. A concern raised was that a shift toward a business-driven platform direction could affect the proposed journey. Treat alignment with the broader platform strategy as an open dependency. No formal sign-off, engineering completion or release date is established here.

## 9. Open questions
- Final product/instance naming and search indexing behavior.
- Access model and whether instances are visible before access is granted.
- Final tab structure and navigation entry points.
- Metric definitions, response categories, data freshness and diagnostic data availability.
- Supported user actions, permissions, and escalation paths.
- Widget customization scope and persistence.
- Onboarding ownership and the contact route.
- Alignment with the evolving business-driven Service Bench journey.

## 10. Instructions for the receiving AI
Read this alongside AI_COLLABORATION.md. Treat the latest user-provided screenshot, requirement or correction as authoritative over this historical summary. Distinguish observed behavior, user-confirmed product facts, design proposals and unknowns. Never invent API fields, shipped capabilities, stakeholder approval or access to original Figma files. Ask focused questions only when a missing detail materially changes the design; otherwise proceed with clearly labeled assumptions. When reviewing a redesign, explain the before/after improvement in terms of user intent, information architecture, cognitive load and operational usability.

Source: prior user discussions and design iterations, primarily November 2026. Original screenshots and Figma source are not embedded in this file.
