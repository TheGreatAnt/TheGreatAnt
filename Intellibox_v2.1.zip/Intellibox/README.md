# Intellibox Client Service Group Dashboard

Zero-dependency responsive HTML/CSS/JavaScript implementation of the supplied dashboard screenshot.

## Run locally

From this folder, run:

```bash
python3 -m http.server 8080
```

Then open <http://localhost:8080>.

No build step or package installation is required.
