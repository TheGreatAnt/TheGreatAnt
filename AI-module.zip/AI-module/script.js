if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

function resetPageScroll() {
  window.scrollTo({ top: 0, left: 0, behavior: 'auto' });
}

window.addEventListener('beforeunload', resetPageScroll);
window.addEventListener('pageshow', () => {
  resetPageScroll();
  window.requestAnimationFrame(resetPageScroll);
});

document.querySelectorAll('[data-placeholder-link]').forEach((link) => {
  link.addEventListener('click', (event) => event.preventDefault());
});

const stageOrder = ['build', 'deploy', 'register', 'run', 'discover'];
const stages = {
  build: { title: 'Build powerful AI agents without the complexity', description: 'It’s easier to configure now than ever with agentOS.', images: ['assets/slides/build.png'], alt: 'Agent build workflow in Developer Studio' },
  deploy: { title: 'Easily deploy the agents to test on Service Bench', description: 'Deploy your agents through automated CI/CD pipelines across DEV, STG for lower environments testing on Service Bench.', images: ['assets/slides/deploy-1.png', 'assets/slides/deploy-2.png', 'assets/slides/deploy-3.png'], alt: 'Agent deployment workflow in Developer Studio' },
  register: { title: 'Connect your agents to your business logic', description: 'Browse, discover and integrate APIs at Integration Hub. Once you find an API that fits your use case, register via ADO', images: ['assets/slides/resgister.png'], alt: 'API registration workflow in Integration Hub' },
  run: { title: 'Execute tasks reliably. Full-stack observability and step-by-step reasoning traces.', description: 'Service Bench Agentic Terminal provides a highly available, scalable runtime environment designed for AI agents.', images: ['assets/slides/run.png'], alt: 'Agent activity and reasoning trace' },
  discover: { title: 'What can you build within agentOS', description: 'Browse reusable AI agents created across the organisation. Preview capabilities, chat with agents before adoption, compare use cases, and install solutions that best fit your team’s needs.', images: ['assets/slides/discover.png'], alt: 'Agent discovery gallery and agent overview' },
};

const preloadedStageImages = new Map();
Object.values(stages).flatMap((stage) => stage.images).forEach((src) => {
  const image = new Image();
  const entry = {
    image,
    ready: false,
    promise: null,
  };
  image.src = src;
  entry.promise = image.decode().then(() => {
    entry.ready = true;
  }).catch(() => {
    entry.ready = true;
  });
  preloadedStageImages.set(src, entry);
});

const hero = document.querySelector('.hero-section');
const stageViewport = document.querySelector('#stage-viewport');
const stageMedia = document.querySelector('#stage-media');
const stageImage = document.querySelector('#stage-image');
const liveBuildDemo = document.querySelector('#live-build-demo');
const liveDiscoverDemo = document.querySelector('#live-discover-demo');
const liveRunDemo = document.querySelector('#live-run-demo');
const runTaskBar = document.querySelector('#run-task-bar');
const runTaskLabel = document.querySelector('#run-task-label');
const runTaskCount = document.querySelector('#run-task-count');
const runReasoningSteps = [...document.querySelectorAll('#run-reasoning li')];
const runCursor = document.querySelector('#run-cursor');
const runAgentOption = document.querySelector('.run-agent-options img:first-child');
const systemPrompt = document.querySelector('#system-prompt');
const yamlOutput = document.querySelector('#yaml-output');
const stageTitle = document.querySelector('#stage-title');
const stageDescription = document.querySelector('#stage-description');
const mediaPagination = document.querySelector('#media-pagination');
const buildStepsFrame = document.querySelector('.build-steps-frame');
const tabs = [...document.querySelectorAll('.workflow-switcher button')];
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let activeStage = 'build';
let activeMedia = 0;
let touchStartX = 0;
let touchStartY = 0;
let transitionTimer;
let imageChangeToken = 0;
let autoplayTimer;
let isAutoplaying = false;
let runSequenceToken = 0;

function renderPagination(stage) {
  const hasMultipleImages = stage.images.length > 1;
  mediaPagination.classList.toggle('is-visible', hasMultipleImages);
  if (!hasMultipleImages) {
    mediaPagination.replaceChildren();
    return;
  }

  const existingDots = [...mediaPagination.querySelectorAll('.media-dot')];
  if (existingDots.length === stage.images.length) {
    existingDots.forEach((dot, index) => dot.classList.toggle('is-active', index === activeMedia));
    const existingPlayback = mediaPagination.querySelector('.media-playback');
    existingPlayback?.classList.toggle('is-playing', isAutoplaying);
    existingPlayback?.setAttribute('aria-label', isAutoplaying ? 'Pause slideshow' : 'Play slideshow');
    return;
  }

  mediaPagination.replaceChildren();
  const dotsGroup = document.createElement('div');
  dotsGroup.className = 'media-dots';
  stage.images.forEach((_, index) => {
    const dot = document.createElement('button');
    dot.type = 'button';
    dot.className = `media-dot${index === activeMedia ? ' is-active' : ''}`;
    dot.setAttribute('aria-label', `Show deployment screenshot ${index + 1}`);
    dot.addEventListener('click', () => setMedia(index));
    dotsGroup.append(dot);
  });
  if (stage.images.length > 1) {
    mediaPagination.append(dotsGroup);
    const playback = document.createElement('button');
    playback.type = 'button';
    playback.className = `media-playback${isAutoplaying ? ' is-playing' : ''}`;
    playback.setAttribute('aria-label', isAutoplaying ? 'Pause slideshow' : 'Play slideshow');
    playback.addEventListener('click', toggleAutoplay);
    mediaPagination.append(playback);
  }
}

function scheduleAutoplay() {
  window.clearInterval(autoplayTimer);
  if (!isAutoplaying || activeStage !== 'deploy') return;
  autoplayTimer = window.setInterval(() => {
    setMedia((activeMedia + 1) % stages.deploy.images.length);
  }, 3000);
}

function toggleAutoplay() {
  if (isAutoplaying) {
    stopAutoplay();
    renderPagination(stages[activeStage]);
    return;
  }
  isAutoplaying = true;
  renderPagination(stages[activeStage]);
  setMedia((activeMedia + 1) % stages.deploy.images.length);
}

function stopAutoplay() {
  isAutoplaying = false;
  window.clearInterval(autoplayTimer);
}

function waitForRunSequence(duration) {
  return new Promise((resolve) => window.setTimeout(resolve, duration));
}

function resetRunSequence() {
  liveRunDemo?.classList.remove('is-agent-moving', 'is-agent-selected', 'is-running', 'is-resetting');
  runCursor?.classList.remove('is-visible', 'is-clicking');
  runTaskBar?.classList.remove('is-complete');
  if (runTaskLabel) runTaskLabel.textContent = 'Running workflow activities';
  if (runTaskCount) runTaskCount.textContent = `0 / ${runReasoningSteps.length}`;
  runReasoningSteps.forEach((step) => step.classList.remove('is-visible', 'is-active', 'is-complete'));
}

function stopRunSequence() {
  runSequenceToken += 1;
  resetRunSequence();
}

async function moveRunCursor(target, duration, token) {
  if (token !== runSequenceToken || !target || !runCursor || !liveRunDemo) return false;
  const demoRect = liveRunDemo.getBoundingClientRect();
  const targetRect = target.getBoundingClientRect();
  const x = targetRect.left - demoRect.left + targetRect.width * .5;
  const y = targetRect.top - demoRect.top + targetRect.height * .5;
  runCursor.style.transitionDuration = `${duration}ms, 220ms`;
  runCursor.style.transform = `translate(${x}px, ${y}px)`;
  await waitForRunSequence(duration + 40);
  return token === runSequenceToken;
}

async function clickRunCursor(token) {
  if (token !== runSequenceToken || !runCursor) return false;
  runCursor.classList.remove('is-clicking');
  void runCursor.offsetWidth;
  runCursor.classList.add('is-clicking');
  await waitForRunSequence(340);
  runCursor.classList.remove('is-clicking');
  return token === runSequenceToken;
}

async function startRunSequence() {
  if (activeStage !== 'run') return;
  stopRunSequence();
  const token = runSequenceToken;

  if (reducedMotion) {
    liveRunDemo?.classList.add('is-agent-moving', 'is-agent-selected', 'is-running');
    runReasoningSteps.forEach((step) => step.classList.add('is-visible', 'is-complete'));
    runTaskBar?.classList.add('is-complete');
    if (runTaskLabel) runTaskLabel.textContent = 'Workflow completed';
    if (runTaskCount) runTaskCount.textContent = `${runReasoningSteps.length} / ${runReasoningSteps.length}`;
    return;
  }

  if (runCursor && liveRunDemo) {
    runCursor.style.transitionDuration = '0ms, 180ms';
    runCursor.style.transform = `translate(-28px, ${Math.max(260, liveRunDemo.clientHeight - 18)}px)`;
  }
  await waitForRunSequence(520);
  if (token !== runSequenceToken || activeStage !== 'run') return;
  runCursor?.classList.add('is-visible');
  await waitForRunSequence(30);
  if (!(await moveRunCursor(runAgentOption, 720, token))) return;
  if (!(await clickRunCursor(token))) return;

  liveRunDemo?.classList.add('is-agent-moving');
  void liveRunDemo?.offsetWidth;
  await waitForRunSequence(40);
  if (token !== runSequenceToken || activeStage !== 'run') return;
  liveRunDemo?.classList.add('is-agent-selected');
  await waitForRunSequence(920);
  if (token !== runSequenceToken || activeStage !== 'run') return;
  runCursor?.classList.remove('is-visible');
  liveRunDemo?.classList.add('is-running');
  await waitForRunSequence(540);

  for (let index = 0; index < runReasoningSteps.length; index += 1) {
    if (token !== runSequenceToken || activeStage !== 'run') return;
    const step = runReasoningSteps[index];
    const title = step.querySelector('strong')?.textContent || 'Running activity';
    step.classList.add('is-visible', 'is-active');
    if (runTaskLabel) runTaskLabel.textContent = title;
    if (runTaskCount) runTaskCount.textContent = `${index + 1} / ${runReasoningSteps.length}`;
    await waitForRunSequence(1050);
    if (token !== runSequenceToken || activeStage !== 'run') return;
    step.classList.remove('is-active');
    step.classList.add('is-complete');
  }

  runTaskBar?.classList.add('is-complete');
  if (runTaskLabel) runTaskLabel.textContent = 'Workflow completed';
  await waitForRunSequence(1450);
  if (token !== runSequenceToken || activeStage !== 'run') return;
  liveRunDemo?.classList.add('is-resetting');
  liveRunDemo?.classList.remove('is-running');
  await waitForRunSequence(520);
  if (token !== runSequenceToken || activeStage !== 'run') return;
  resetRunSequence();
  await waitForRunSequence(680);
  if (token === runSequenceToken && activeStage === 'run') startRunSequence();
}

function changeImage(stage, direction) {
  clearTimeout(transitionTimer);
  const changeToken = ++imageChangeToken;
  const showLiveBuild = activeStage === 'build';
  const showLiveRun = activeStage === 'run';
  const showLiveDiscover = activeStage === 'discover';
  const showStaticImage = !showLiveBuild && !showLiveRun && !showLiveDiscover;
  const leavingLiveBuild = !showLiveBuild && !liveBuildDemo.classList.contains('is-hidden');
  const leavingLiveRun = !showLiveRun && !liveRunDemo.classList.contains('is-hidden');
  const leavingLiveDiscover = !showLiveDiscover && !liveDiscoverDemo.classList.contains('is-hidden');
  if (reducedMotion) {
    stageImage.src = stage.images[activeMedia];
    stageImage.alt = stage.alt;
    stageImage.dataset.visualStage = activeStage;
    stageImage.dataset.mediaIndex = String(activeMedia);
    stageImage.classList.toggle('is-hidden', !showStaticImage);
    liveBuildDemo.classList.toggle('is-hidden', !showLiveBuild);
    liveRunDemo.classList.toggle('is-hidden', !showLiveRun);
    liveDiscoverDemo.classList.toggle('is-hidden', !showLiveDiscover);
    buildStepsFrame.classList.toggle('is-stage-hidden', !showLiveBuild);
    if (showLiveDiscover) startDiscoverSequence();
    else stopDiscoverSequence();
    if (showLiveRun) startRunSequence();
    else stopRunSequence();
    renderPagination(stage);
    return;
  }
  if (leavingLiveBuild) liveBuildDemo.classList.add('is-leaving');
  if (leavingLiveRun) liveRunDemo.classList.add('is-leaving');
  if (leavingLiveDiscover) liveDiscoverDemo.classList.add('is-leaving');
  stageMedia.className = `stage-media is-exiting-${direction}`;
  const nextSrc = showStaticImage ? stage.images[activeMedia] : null;
  const imageEntry = nextSrc ? preloadedStageImages.get(nextSrc) : null;
  const applySwap = () => {
    if (changeToken !== imageChangeToken) return;
    if (nextSrc) {
      stageImage.src = imageEntry?.image?.currentSrc || nextSrc;
      stageImage.alt = stage.alt;
      stageImage.dataset.visualStage = activeStage;
      stageImage.dataset.mediaIndex = String(activeMedia);
    }
    stageImage.classList.toggle('is-hidden', !showStaticImage);
    liveBuildDemo.classList.toggle('is-hidden', !showLiveBuild);
    liveRunDemo.classList.toggle('is-hidden', !showLiveRun);
    liveDiscoverDemo.classList.toggle('is-hidden', !showLiveDiscover);
    liveBuildDemo.classList.remove('is-leaving');
    liveRunDemo.classList.remove('is-leaving');
    liveDiscoverDemo.classList.remove('is-leaving');
    buildStepsFrame.classList.toggle('is-stage-hidden', !showLiveBuild);
    if (showLiveBuild) {
      liveBuildDemo.classList.add('is-entering');
      window.setTimeout(() => liveBuildDemo.classList.remove('is-entering'), 380);
    }
    if (showLiveRun) {
      resetRunSequence();
      liveRunDemo.classList.add('is-entering');
      window.setTimeout(() => liveRunDemo.classList.remove('is-entering'), 470);
      window.setTimeout(startRunSequence, 420);
    }
    if (showLiveDiscover) {
      resetDiscoverDemo();
      liveDiscoverDemo.classList.add('is-entering');
      window.setTimeout(() => liveDiscoverDemo.classList.remove('is-entering'), 430);
      window.setTimeout(startDiscoverSequence, 460);
    }
    stageMedia.className = `stage-media is-entering-${direction}`;
    renderPagination(stage);
    window.setTimeout(() => {
      if (changeToken === imageChangeToken) stageMedia.className = 'stage-media';
    }, 720);
  };
  transitionTimer = window.setTimeout(() => {
    if (imageEntry && !imageEntry.ready) {
      imageEntry.promise.then(applySwap);
      return;
    }
    applySwap();
  }, leavingLiveBuild || leavingLiveRun || leavingLiveDiscover ? 90 : 420);
}

function setMedia(index) {
  const stage = stages[activeStage];
  if (index === activeMedia || index < 0 || index >= stage.images.length) return;
  const direction = index > activeMedia ? 'left' : 'right';
  activeMedia = index;
  scheduleAutoplay();
  changeImage(stage, direction);
}

function setStage(nextStage) {
  if (!stages[nextStage] || nextStage === activeStage) return;
  const nextIndex = stageOrder.indexOf(nextStage);
  const direction = nextIndex > stageOrder.indexOf(activeStage) ? 'left' : 'right';
  const stage = stages[nextStage];
  if (nextStage !== 'deploy') stopAutoplay();
  if (nextStage !== 'run') stopRunSequence();
  if (nextStage !== 'discover') stopDiscoverSequence();
  if (nextStage !== 'build') buildStepsFrame.classList.add('is-stage-hidden');
  activeStage = nextStage;
  activeMedia = 0;
  hero.dataset.stage = nextStage;
  requestHeroScrollEffect();
  hero.classList.add('is-changing');
  tabs.forEach((tab) => {
    const isActive = tab.dataset.stage === nextStage;
    tab.classList.toggle('is-active', isActive);
    tab.setAttribute('aria-selected', String(isActive));
  });
  applyWorkflowJelly(nextIndex);
  window.setTimeout(() => {
    stageTitle.textContent = stage.title;
    stageDescription.textContent = stage.description;
    hero.classList.remove('is-changing');
  }, reducedMotion ? 0 : 180);
  changeImage(stage, direction);
}

tabs.forEach((tab) => tab.addEventListener('click', () => setStage(tab.dataset.stage)));

function applyWorkflowJelly(selectedIndex, instant = false) {
  if (reducedMotion) return;
  const selectedWidth = tabs[selectedIndex]?.offsetWidth || 105;
  const push = selectedWidth * 0.075 + 5;
  tabs.forEach((tab, index) => {
    const distance = Math.abs(index - selectedIndex);
    const direction = Math.sign(index - selectedIndex);
    const isSelected = index === selectedIndex;
    tab.style.setProperty('--jelly-x', `${isSelected ? 0 : direction * push}px`);
    tab.style.setProperty('--jelly-sx', String(isSelected ? 1.15 : 0.975));
    tab.style.setProperty('--jelly-sy', String(isSelected ? 1.075 : 0.975));
    tab.style.setProperty('--jelly-delay', instant ? '0ms' : `${distance * 24}ms`);
  });
}

applyWorkflowJelly(0, true);

const categoryButtons = [...document.querySelectorAll('.discover-categories button')];
const discoverCategories = document.querySelector('.discover-categories');
const agentButtons = [...document.querySelectorAll('.discover-agents button')];
const discoverAgents = document.querySelector('#discover-agents');
const agentDetail = document.querySelector('#agent-detail');
const detailAvatar = document.querySelector('#detail-avatar');
const detailName = document.querySelector('#detail-name');
const detailRole = document.querySelector('#detail-role');
const detailStatus = document.querySelector('#detail-status');
const detailCopy = document.querySelector('#detail-copy');
const discoverCursor = document.querySelector('#discover-cursor');
const agentProfiles = {
  x: { name: 'Agent X', role: 'Outward Payment Operations Agent', copy: "You are the Projects Portfolio Owner Agent for Carlsson Chee's Workspace. Your goal is to act like a vigilant portfolio manager, scanning for risks, delays, and workload issues, and surfacing clear, actionable summaries.", avatar: 'assets/slides/discover/Agent 1.png' },
  y: { name: 'Agent Y', role: 'Real time translate', copy: 'Translates service conversations and context in real time.', avatar: 'assets/slides/discover/Agent 2.png' },
  z: { name: 'Agent Z', role: 'Deep research and retrieval', copy: 'Finds, compares, and synthesises knowledge from connected sources.', avatar: 'assets/slides/discover/Agent 3.png' },
};
let discoverUnlockTimer;

[...categoryButtons, ...agentButtons].forEach((button) => {
  button.tabIndex = -1;
  button.setAttribute('aria-disabled', 'true');
});

function resetDiscoverDemo() {
  window.clearTimeout(discoverUnlockTimer);
  liveDiscoverDemo.classList.remove('is-intro-playing');
  discoverCategories.classList.remove('has-divider');
  categoryButtons.forEach((button) => button.classList.remove('is-selected'));
  agentButtons.forEach((button) => button.classList.remove('is-selected'));
  discoverAgents.classList.add('is-locked');
  agentDetail.classList.add('is-locked');
  agentDetail.scrollTop = 0;
}

categoryButtons.forEach((button) => {
  button.addEventListener('click', () => {
    window.clearTimeout(discoverUnlockTimer);
    categoryButtons.forEach((item) => item.classList.toggle('is-selected', item === button));
    agentButtons.forEach((item) => item.classList.remove('is-selected'));
    agentDetail.classList.add('is-locked');
    if (button.dataset.category === 'agents') {
      discoverCategories.classList.add('has-divider');
      discoverAgents.classList.add('is-locked');
      discoverUnlockTimer = window.setTimeout(() => discoverAgents.classList.remove('is-locked'), 0);
    } else {
      discoverCategories.classList.remove('has-divider');
      discoverAgents.classList.add('is-locked');
    }
  });
});

agentButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const profile = agentProfiles[button.dataset.agent];
    if (!profile) return;
    agentButtons.forEach((item) => item.classList.toggle('is-selected', item === button));
    detailAvatar.src = profile.avatar;
    detailAvatar.alt = `${profile.name} avatar`;
    detailName.textContent = profile.name;
    detailRole.textContent = profile.role;
    detailStatus.textContent = `Ready to run ${profile.name}`;
    detailCopy.textContent = profile.copy;
    agentDetail.classList.remove('is-locked');
  });
});

let discoverSequenceToken = 0;

function waitForDiscover(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function stopDiscoverSequence() {
  discoverSequenceToken += 1;
  discoverCursor?.classList.remove('is-visible', 'is-clicking');
}

async function moveDiscoverCursor(target, duration, token) {
  if (token !== discoverSequenceToken || !target) return false;
  const demoRect = liveDiscoverDemo.getBoundingClientRect();
  const targetRect = target.getBoundingClientRect();
  const x = targetRect.left - demoRect.left + Math.min(34, targetRect.width * .28);
  const y = targetRect.top - demoRect.top + targetRect.height * .52;
  discoverCursor.style.transitionDuration = `${duration}ms, 250ms`;
  discoverCursor.style.transform = `translate(${x}px, ${y}px)`;
  await waitForDiscover(duration + 60);
  return token === discoverSequenceToken;
}

async function clickDiscoverCursor(token) {
  if (token !== discoverSequenceToken) return false;
  discoverCursor.classList.remove('is-clicking');
  void discoverCursor.offsetWidth;
  discoverCursor.classList.add('is-clicking');
  await waitForDiscover(360);
  discoverCursor.classList.remove('is-clicking');
  return token === discoverSequenceToken;
}

async function scrollDiscoverPanel(token, duration = 1400) {
  const start = agentDetail.scrollTop;
  const end = Math.max(0, agentDetail.scrollHeight - agentDetail.clientHeight);
  if (end <= start) {
    await waitForDiscover(400);
    return token === discoverSequenceToken;
  }
  const startedAt = performance.now();
  await new Promise((resolve) => {
    const tick = (now) => {
      if (token !== discoverSequenceToken) {
        resolve();
        return;
      }
      const t = Math.min(1, (now - startedAt) / duration);
      const eased = 1 - (1 - t) ** 3;
      agentDetail.scrollTop = start + (end - start) * eased;
      if (t < 1) requestAnimationFrame(tick);
      else resolve();
    };
    requestAnimationFrame(tick);
  });
  return token === discoverSequenceToken;
}

async function startDiscoverSequence() {
  stopDiscoverSequence();
  const token = discoverSequenceToken;
  resetDiscoverDemo();

  if (reducedMotion) {
    categoryButtons[1]?.click();
    agentButtons[0]?.click();
    return;
  }

  void liveDiscoverDemo.offsetWidth;
  liveDiscoverDemo.classList.add('is-intro-playing');

  discoverCursor.style.transitionDuration = '0ms, 200ms';
  discoverCursor.style.transform = `translate(-24px, ${Math.max(240, liveDiscoverDemo.clientHeight - 28)}px)`;
  await waitForDiscover(780);
  if (token !== discoverSequenceToken) return;
  discoverCursor.classList.add('is-visible');
  await waitForDiscover(15);
  if (!(await moveDiscoverCursor(categoryButtons[1], 650, token))) return;
  categoryButtons[1]?.click();
  if (!(await clickDiscoverCursor(token))) return;
  if (!(await moveDiscoverCursor(agentButtons[0], 700, token))) return;
  agentButtons[0]?.click();
  if (!(await clickDiscoverCursor(token))) return;
  await waitForDiscover(520);
  if (!(await moveDiscoverCursor(agentDetail.querySelector('.agent-status'), 620, token))) return;
  if (!(await scrollDiscoverPanel(token))) return;
  await waitForDiscover(420);
  if (token !== discoverSequenceToken) return;
  discoverCursor.classList.remove('is-visible');
  await waitForDiscover(650);
  if (token !== discoverSequenceToken || activeStage !== 'discover') return;
  resetDiscoverDemo();
  await waitForDiscover(650);
  if (token === discoverSequenceToken && activeStage === 'discover') startDiscoverSequence();
}

stageViewport.addEventListener('touchstart', (event) => {
  touchStartX = event.changedTouches[0].clientX;
  touchStartY = event.changedTouches[0].clientY;
}, { passive: true });

stageViewport.addEventListener('touchend', (event) => {
  const deltaX = event.changedTouches[0].clientX - touchStartX;
  const deltaY = event.changedTouches[0].clientY - touchStartY;
  if (Math.abs(deltaX) < 55 || Math.abs(deltaX) <= Math.abs(deltaY)) return;
  const currentIndex = stageOrder.indexOf(activeStage);
  const nextIndex = deltaX < 0 ? currentIndex + 1 : currentIndex - 1;
  if (stageOrder[nextIndex]) setStage(stageOrder[nextIndex]);
}, { passive: true });

document.querySelector('.workflow-switcher').addEventListener('keydown', (event) => {
  if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
  event.preventDefault();
  const currentIndex = stageOrder.indexOf(activeStage);
  const offset = event.key === 'ArrowRight' ? 1 : -1;
  const nextIndex = (currentIndex + offset + stageOrder.length) % stageOrder.length;
  setStage(stageOrder[nextIndex]);
  tabs[nextIndex].focus();
});

renderPagination(stages.build);

const stepsFrame = document.querySelector('.build-steps-frame');
const stepCards = [...document.querySelectorAll('.build-steps li')];

function syncStepChecks() {
  if (!reducedMotion) {
    const frameRect = stepsFrame.getBoundingClientRect();
    const activationInset = Math.min(110, frameRect.width * 0.13);
    stepCards.forEach((card) => {
      const cardRect = card.getBoundingClientRect();
      const hasEntered = cardRect.left < frameRect.right - activationInset;
      const hasNotExited = cardRect.right > frameRect.left + activationInset;
      card.classList.toggle('is-checked', hasEntered && hasNotExited);
    });
    window.requestAnimationFrame(syncStepChecks);
  } else {
    stepCards.forEach((card) => card.classList.add('is-checked'));
  }
}

syncStepChecks();

let scrollFrameRequested = false;
function updateHeroScrollEffect() {
  scrollFrameRequested = false;
  if (reducedMotion) return;
  const heroTop = hero.offsetTop;
  const isBuildStage = activeStage === 'build';
  const fadeStart = heroTop + (isBuildStage ? -8 : 12);
  const fadeDistance = isBuildStage ? 125 : 165;
  const progress = Math.min(1, Math.max(0, (window.scrollY - fadeStart) / fadeDistance));
  const easedProgress = progress * progress * (3 - 2 * progress);
  hero.style.setProperty('--hero-copy-opacity', String(1 - easedProgress));
  hero.style.setProperty('--hero-copy-blur', `${easedProgress * 7}px`);
  hero.style.setProperty('--hero-copy-shift', `${easedProgress * -16}px`);
}

function requestHeroScrollEffect() {
  if (scrollFrameRequested) return;
  scrollFrameRequested = true;
  window.requestAnimationFrame(updateHeroScrollEffect);
}

window.addEventListener('scroll', requestHeroScrollEffect, { passive: true });
window.addEventListener('resize', requestHeroScrollEffect);
updateHeroScrollEffect();

const productNavigation = document.querySelector('.top-navigation');
let previousNavigationScrollY = window.scrollY;
let navigationFrameRequested = false;

function updateProductNavigation() {
  navigationFrameRequested = false;
  if (!productNavigation) return;

  const currentScrollY = Math.max(0, window.scrollY);
  const scrollDelta = currentScrollY - previousNavigationScrollY;

  if (currentScrollY <= 48) {
    productNavigation.classList.remove('is-scroll-hidden');
  } else if (scrollDelta > 4 && currentScrollY > 112) {
    productNavigation.classList.add('is-scroll-hidden');
  }

  previousNavigationScrollY = currentScrollY;
}

function requestProductNavigationUpdate() {
  if (navigationFrameRequested) return;
  navigationFrameRequested = true;
  window.requestAnimationFrame(updateProductNavigation);
}

window.addEventListener('scroll', requestProductNavigationUpdate, { passive: true });

const demoPrompt = `# Metadata
- **Name:** Doctor Strange-ish Agent Soul
- **Description:** Apply the persona of the Sorcerer Supreme of Snacks, Sparkles, and Slight Clumsiness to all interactions and responses.

## Overview
You are a wildly dramatic, fabulously sassy, but secretly soft-hearted wizard.`;

function updateYaml() {
  const promptLines = systemPrompt.innerText.split('\n').map((line) => `    ${line}`).join('\n');
  yamlOutput.textContent = `agentId: interactive-agent\nname: Doctor Strange-ish Agent\nagentType: interactive\ndescription: "AI agent configured in Developer Studio"\navatar:\n  id: avatar-1\nrole:\n  metadata:\n${promptLines || '    Start typing a system prompt…'}\n\npermissions:\n  scope: workspace`;
}

let typingIndex = 0;
let typingTimer;
let userInteractedWithPrompt = false;
function typeDemoPrompt() {
  if (userInteractedWithPrompt || document.activeElement === systemPrompt) return;
  if (typingIndex >= demoPrompt.length) {
    typingTimer = window.setTimeout(() => {
      if (userInteractedWithPrompt) return;
      typingIndex = 0;
      systemPrompt.textContent = '';
      updateYaml();
      typingTimer = window.setTimeout(typeDemoPrompt, 500);
    }, 1600);
    return;
  }
  systemPrompt.textContent += demoPrompt[typingIndex];
  typingIndex += 1;
  updateYaml();
  systemPrompt.scrollTop = systemPrompt.scrollHeight;
  typingTimer = window.setTimeout(typeDemoPrompt, typingIndex % 24 === 0 ? 160 : 20 + Math.random() * 24);
}

systemPrompt.addEventListener('input', () => {
  userInteractedWithPrompt = true;
  systemPrompt.classList.remove('is-auto-typing');
  window.clearTimeout(typingTimer);
  updateYaml();
});
systemPrompt.addEventListener('focus', () => {
  userInteractedWithPrompt = true;
  systemPrompt.classList.remove('is-auto-typing');
  window.clearTimeout(typingTimer);
});

if (reducedMotion) {
  systemPrompt.textContent = demoPrompt;
  systemPrompt.classList.remove('is-auto-typing');
  updateYaml();
} else {
  updateYaml();
  window.setTimeout(typeDemoPrompt, 700);
}

if (!reducedMotion && 'IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.14 });
  document.querySelectorAll('.reveal').forEach((section) => observer.observe(section));
} else {
  document.querySelectorAll('.reveal').forEach((section) => section.classList.add('is-visible'));
}

function initStrandsHorizon() {
  const canvas = document.querySelector('#strands-canvas');
  const container = canvas?.parentElement;
  if (!canvas || !container) return;

  const gl = canvas.getContext('webgl2', {
    alpha: true,
    antialias: true,
    premultipliedAlpha: true,
    powerPreference: 'high-performance'
  });
  if (!gl) return;

  const vertexSource = `#version 300 es
    in vec2 position;
    void main() { gl_Position = vec4(position, 0.0, 1.0); }
  `;
  const fragmentSource = `#version 300 es
    precision highp float;
    uniform float uTime;
    uniform vec2 uResolution;
    uniform vec3 uColors[8];
    uniform int uColorCount;
    uniform int uStrandCount;
    uniform float uSpeed;
    uniform float uAmplitude;
    uniform float uWaviness;
    uniform float uThickness;
    uniform float uGlow;
    uniform float uTaper;
    uniform float uSpread;
    uniform float uIntensity;
    uniform float uOpacity;
    uniform float uScale;
    uniform float uSaturation;
    out vec4 fragColor;
    const float PI = 3.14159265;

    vec3 samplePalette(float t) {
      t = fract(t);
      float scaled = t * float(uColorCount);
      int index = int(floor(scaled));
      float blend = fract(scaled);
      int nextIndex = index + 1;
      if (nextIndex >= uColorCount) nextIndex = 0;
      return mix(uColors[index], uColors[nextIndex], blend);
    }

    void main() {
      vec2 uv = (gl_FragCoord.xy - .5 * uResolution) / uResolution.y;
      uv.x /= max(uScale, .0001);
      uv.y /= 1.82;
      float energy = .06 + uIntensity * .94;
      float envelope = pow(max(cos(uv.x * PI * 1.3), 0.0), uTaper);
      vec3 color = vec3(0.0);

      for (int i = 0; i < 12; i++) {
        if (i >= uStrandCount) break;
        float fi = float(i);
        float phase = fi * 1.7 * uSpread;
        float frequency = (2.0 + fi * .35) * uWaviness;
        float strandSpeed = 1.4 + fi * 1.2;
        float time = uTime * uSpeed;
        float wave = sin(uv.x * frequency + time * strandSpeed + phase) * .60
          + sin(uv.x * frequency * 1.1 - time * strandSpeed * .7 + phase * 1.7) * .40;
        float amplitude = (.1 + .02 * energy) * envelope * uAmplitude;
        float distanceToStrand = abs(uv.y - wave * amplitude);
        float thickness = (.001 + .05 * energy) * (.35 + envelope) * uThickness;
        float light = thickness / (distanceToStrand + thickness * .45);
        light *= light;
        float hue = fi / float(uStrandCount) + uv.x * .30 + uTime * .04;
        color += samplePalette(hue) * light * envelope;
      }

      color *= .45 + .7 * energy;
      color = 1.0 - exp(-color * uGlow);
      float gray = dot(color, vec3(.2126, .7152, .0722));
      color = max(mix(vec3(gray), color, uSaturation), 0.0);
      float luminance = max(max(color.r, color.g), color.b);
      float alpha = clamp(luminance, 0.0, 1.0) * uOpacity;
      fragColor = vec4(color * uOpacity, alpha);
    }
  `;

  function compileShader(type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const message = gl.getShaderInfoLog(shader);
      gl.deleteShader(shader);
      throw new Error(message || 'Unable to compile Strands shader');
    }
    return shader;
  }

  let program;
  try {
    program = gl.createProgram();
    gl.attachShader(program, compileShader(gl.VERTEX_SHADER, vertexSource));
    gl.attachShader(program, compileShader(gl.FRAGMENT_SHADER, fragmentSource));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
  } catch (error) {
    console.warn('Strands horizon could not be initialized.', error);
    return;
  }

  const vertices = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, vertices);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const position = gl.getAttribLocation(program, 'position');
  gl.enableVertexAttribArray(position);
  gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
  gl.useProgram(program);
  gl.enable(gl.BLEND);
  gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  gl.clearColor(0, 0, 0, 0);

  const uniform = (name) => gl.getUniformLocation(program, name);
  const uniforms = {
    time: uniform('uTime'),
    resolution: uniform('uResolution'),
    colors: uniform('uColors[0]'),
    colorCount: uniform('uColorCount'),
    strandCount: uniform('uStrandCount'),
    speed: uniform('uSpeed'),
    amplitude: uniform('uAmplitude'),
    waviness: uniform('uWaviness'),
    thickness: uniform('uThickness'),
    glow: uniform('uGlow'),
    taper: uniform('uTaper'),
    spread: uniform('uSpread'),
    intensity: uniform('uIntensity'),
    opacity: uniform('uOpacity'),
    scale: uniform('uScale'),
    saturation: uniform('uSaturation')
  };
  const palette = [
    .42, .75, 1.0,
    .18, .39, 1.0,
    .52, .45, 1.0,
    .42, .75, 1.0,
    .42, .75, 1.0,
    .42, .75, 1.0,
    .42, .75, 1.0,
    .42, .75, 1.0
  ];

  gl.uniform3fv(uniforms.colors, new Float32Array(palette));
  gl.uniform1i(uniforms.colorCount, 3);
  gl.uniform1i(uniforms.strandCount, 1);
  gl.uniform1f(uniforms.speed, .34);
  gl.uniform1f(uniforms.amplitude, .92);
  gl.uniform1f(uniforms.waviness, .82);
  gl.uniform1f(uniforms.thickness, .7);
  gl.uniform1f(uniforms.glow, 2.7);
  gl.uniform1f(uniforms.taper, 3.2);
  gl.uniform1f(uniforms.spread, .88);
  gl.uniform1f(uniforms.intensity, .52);
  gl.uniform1f(uniforms.opacity, .84);
  gl.uniform1f(uniforms.scale, 3.3);
  gl.uniform1f(uniforms.saturation, 1.18);

  function resizeStrands() {
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(container.clientWidth * pixelRatio));
    const height = Math.max(1, Math.round(container.clientHeight * pixelRatio));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
      gl.viewport(0, 0, width, height);
      gl.uniform2f(uniforms.resolution, width, height);
    }
  }

  function renderStrands(time = 0) {
    resizeStrands();
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(uniforms.time, time * .001);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }

  let animationFrame = 0;
  let isRunning = false;
  function animateStrands(time) {
    if (!isRunning) return;
    renderStrands(time);
    animationFrame = window.requestAnimationFrame(animateStrands);
  }
  function startStrands() {
    if (isRunning || reducedMotion) return;
    isRunning = true;
    animationFrame = window.requestAnimationFrame(animateStrands);
  }
  function stopStrands() {
    isRunning = false;
    window.cancelAnimationFrame(animationFrame);
  }

  new ResizeObserver(() => renderStrands(performance.now())).observe(container);
  if (reducedMotion) {
    renderStrands(0);
  } else if ('IntersectionObserver' in window) {
    const strandsObserver = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) startStrands();
      else stopStrands();
    }, { rootMargin: '160px 0px' });
    strandsObserver.observe(container);
  } else {
    startStrands();
  }
}

initStrandsHorizon();

function initSpecularButton() {
  const button = document.querySelector('.specular-button');
  const canvas = document.querySelector('#specular-button-canvas');
  if (!button || !canvas) return;

  const gl = canvas.getContext('webgl2', { alpha: true, antialias: true, premultipliedAlpha: true });
  if (!gl) return;

  const vertexSource = `#version 300 es
    in vec2 position;
    void main() { gl_Position = vec4(position, 0.0, 1.0); }
  `;
  const fragmentSource = `#version 300 es
    precision highp float;
    uniform vec2 uCenter;
    uniform vec2 uHalfSize;
    uniform float uRadius;
    uniform float uAngle;
    uniform float uPx;
    uniform vec3 uLineColor;
    uniform vec3 uBaseColor;
    uniform float uIntensity;
    uniform float uShineSize;
    uniform float uShineFade;
    uniform float uThickness;
    uniform float uBaseWidth;
    out vec4 fragColor;

    float roundedRect(vec2 point, vec2 bounds, float radius) {
      vec2 q = abs(point) - bounds + radius;
      return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
    }
    float gaussianLine(float distance, float sigma) {
      float x = distance / (sigma + 1e-6);
      float curve = mix(1.0, 1.6, smoothstep(0.0, 1.5, x));
      return exp(-curve * x * x);
    }
    void main() {
      vec2 point = gl_FragCoord.xy - uCenter;
      float distance = roundedRect(point, uHalfSize, uRadius);
      vec2 lightDirection = vec2(cos(uAngle), sin(uAngle));
      float base = (1.0 - smoothstep(0.0, uBaseWidth, abs(distance))) * .45;
      vec2 normal = normalize(point / (uHalfSize * uHalfSize) + 1e-6);
      float phi = acos(clamp(abs(dot(normal, lightDirection)), 0.0, 1.0));
      float rim = 1.0 - smoothstep(uShineSize - uShineFade, uShineSize + uShineFade + 1e-4, phi);
      float line = gaussianLine(distance, uThickness);
      float edgeClamp = 1.0 - smoothstep(.5 * uPx, 3.0 * uPx, abs(distance));
      float highlight = line * rim * edgeClamp * uIntensity;
      vec3 color = uBaseColor * base + uLineColor * highlight;
      float alpha = clamp(base + highlight, 0.0, 1.0);
      fragColor = vec4(color, alpha);
    }
  `;

  function compile(type, source) {
    const shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader));
    return shader;
  }

  let program;
  try {
    program = gl.createProgram();
    gl.attachShader(program, compile(gl.VERTEX_SHADER, vertexSource));
    gl.attachShader(program, compile(gl.FRAGMENT_SHADER, fragmentSource));
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
  } catch (error) {
    console.warn('Specular button could not be initialized.', error);
    return;
  }

  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const position = gl.getAttribLocation(program, 'position');
  gl.enableVertexAttribArray(position);
  gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);
  gl.useProgram(program);
  gl.enable(gl.BLEND);
  gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
  gl.clearColor(0, 0, 0, 0);

  const location = (name) => gl.getUniformLocation(program, name);
  const uniforms = {
    center: location('uCenter'), halfSize: location('uHalfSize'), radius: location('uRadius'),
    angle: location('uAngle'), pixel: location('uPx'), lineColor: location('uLineColor'),
    baseColor: location('uBaseColor'), intensity: location('uIntensity'), shineSize: location('uShineSize'),
    shineFade: location('uShineFade'), thickness: location('uThickness'), baseWidth: location('uBaseWidth')
  };
  const padding = 20;
  const size = { width: 1, height: 1, ratio: 1 };

  function resizeButtonEffect() {
    const rect = button.getBoundingClientRect();
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    size.width = rect.width;
    size.height = rect.height;
    size.ratio = ratio;
    canvas.width = Math.max(1, Math.round((rect.width + padding * 2) * ratio));
    canvas.height = Math.max(1, Math.round((rect.height + padding * 2) * ratio));
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.uniform2f(uniforms.center, (padding + rect.width / 2) * ratio, (padding + rect.height / 2) * ratio);
    gl.uniform2f(uniforms.halfSize, rect.width / 2 * ratio, rect.height / 2 * ratio);
    gl.uniform1f(uniforms.radius, rect.height / 2 * ratio);
    gl.uniform1f(uniforms.pixel, ratio);
    gl.uniform1f(uniforms.thickness, ratio);
    gl.uniform1f(uniforms.baseWidth, ratio);
  }

  let pointerAngle = 2.4;
  let hasPointer = false;
  let proximity = 0;
  function updatePointer(event) {
    const rect = button.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const dx = Math.max(rect.left - event.clientX, 0, event.clientX - rect.right);
    const dy = Math.max(rect.top - event.clientY, 0, event.clientY - rect.bottom);
    const distance = Math.hypot(dx, dy);
    if (distance === 0) {
      const normalizedX = (event.clientX - centerX) / (rect.width / 2);
      const normalizedY = (centerY - event.clientY) / (rect.height / 2);
      pointerAngle = Math.atan2(2 / rect.height, -2 / rect.width) + normalizedX * .3 + normalizedY * .15;
    } else {
      pointerAngle = Math.atan2(centerY - event.clientY, event.clientX - centerX);
    }
    const amount = Math.max(0, 1 - distance / 250);
    proximity = amount * amount * (3 - 2 * amount);
    hasPointer = true;
  }
  window.addEventListener('pointermove', updatePointer, { passive: true });

  let angle = 2.4;
  let brightness = 0;
  let previousTime = performance.now();
  let animationFrame = 0;
  let running = true;

  function renderButtonEffect(time) {
    const delta = Math.min((time - previousTime) / 1000, .05);
    previousTime = time;
    if (hasPointer) {
      const difference = ((pointerAngle - angle + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
      angle += difference * (1 - Math.exp(-delta * 7));
    }
    const brightnessTarget = reducedMotion ? 0 : proximity;
    brightness += (brightnessTarget - brightness) * (1 - Math.exp(-delta * 8));

    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.uniform1f(uniforms.angle, angle);
    gl.uniform3f(uniforms.lineColor, 1, 1, 1);
    gl.uniform3f(uniforms.baseColor, .32, .32, .32);
    gl.uniform1f(uniforms.intensity, brightness);
    gl.uniform1f(uniforms.shineSize, 10 * Math.PI / 180);
    gl.uniform1f(uniforms.shineFade, 40 * Math.PI / 180);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    if (running && !reducedMotion) animationFrame = window.requestAnimationFrame(renderButtonEffect);
  }

  resizeButtonEffect();
  renderButtonEffect(performance.now());
  new ResizeObserver(resizeButtonEffect).observe(button);
  document.addEventListener('visibilitychange', () => {
    running = !document.hidden;
    window.cancelAnimationFrame(animationFrame);
    if (running && !reducedMotion) {
      previousTime = performance.now();
      animationFrame = window.requestAnimationFrame(renderButtonEffect);
    }
  });
}

initSpecularButton();
